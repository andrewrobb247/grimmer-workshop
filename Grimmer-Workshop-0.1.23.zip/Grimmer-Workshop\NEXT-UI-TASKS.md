# Current state and next tasks

- Crafting coverage pass complete in 0.1.22 candidate: 630 routes and 18 deliberate non-wildcard exclusions, with wildcard scrapping excluded too.
- Continue live tests from PLAYTEST-CHECKLIST.md, especially Construction awards/persistence/bonus, preparation, ammo, attachment practice and new fixture/manufacturing routes.
- Use normal play feedback for rate changes; retain recipe unlock requirements and existing progress.
- Resume broader equipment choices, vehicle inspection/restoration and farming/defence gameplay roadmap. Enemy candidates and permissions are recorded in Source/ENEMY-RESEARCH.md.
