# 0.1.23 release candidate

Two new tool mods and two new practice routes; all 630 earlier routes unchanged. Tool definitions, stat displays/localization, recipes, included/excluded families, original melee preservation and older-generator persistence checked. 2,627 regressions, 34 layout checks and game compilation pass. Live tool checks pending.
