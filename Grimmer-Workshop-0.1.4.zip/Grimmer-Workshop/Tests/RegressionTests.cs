using System;
using System.Collections.Generic;
using System.Linq;
using GrimmerWorkshop;

public static class RegressionTests
{
    static int checks;
    static void Check(bool okay, string message) { checks++; if(!okay) throw new Exception(message); }
    static ItemStack Stack(int type, int count) { return new ItemStack(new ItemValue(type,false),count); }
    static TileEntityComposite Setup(int bagSlots=3, int storageSlots=3)
    {
        Workshop.Current=new EntityPlayerLocal { bag=new Bag(bagSlots) };
        var tile=new TileEntityComposite { Storage=new TEFeatureStorage { ItemGrid=new ItemStackGrid(storageSlots) }, Position=new Vector3i {x=2,y=1,z=2} };
        Workshop.Current.world.Chunk.Tiles.list.Add(tile);
        return tile;
    }
    static string Snapshot(ItemStackGrid grid)
    {
        return String.Join("|",grid.Slots.Select(s=>s.itemValue.type+":"+s.count+":"+s.itemValue.Variant));
    }
    static Dictionary<int,int> Totals(params ItemStackGrid[] grids)
    {
        return grids.SelectMany(g=>g.Slots).Where(s=>!s.IsEmpty()).GroupBy(s=>s.itemValue.type).ToDictionary(g=>g.Key,g=>g.Sum(s=>s.count));
    }
    public static void Main()
    {
        var budget = new ActivityBudget();
        Check(budget.Take("tools",2,10)==2, "Activity budget accepts normal rewards");
        Check(budget.Take("tools",2,10.1)==1, "Repeated events capped at three practice per second");
        Check(budget.Take("tools",2,10.2)==0, "Activity spam gives no extra practice");
        Check(budget.Take("medicine",1,10.2)==1, "Different skills keep separate budgets");
        Check(budget.Take("tools",2,11)==2, "Activity budget refreshes after one second");
        Check(budget.Take("tools",2,1)==2, "Timer reset safely refreshes budget");
        Check(budget.Take("invalid",double.NaN,1)==0 && budget.Take("invalid",double.PositiveInfinity,1)==0 && budget.Take("invalid",-5,1)==0, "Invalid practice cannot corrupt progress");
        double[] quality = { 1, 1, 1.25, 1.5, 1.75, 2, 2.5 };
        for (int q = 0; q <= 6; q++) {
            Check(PracticeMath.QualityMultiplier(q) == quality[q], "Quality " + q + " multiplier");
            double craft = PracticeMath.Credit(1,1,1,1,14,10) * quality[q];
            Check(craft * 0.1 < craft * 0.25 && craft * 0.25 < craft, "Scrap rewards below craft rewards");
            Check(PracticeMath.Credit(3,1,1,1,14,10) * quality[q] == craft * 3, "Quality batch conservation");
        }
        Check(PracticeMath.Credit(20,10,1,1,10,10)==20,"Batch credit must normalize to recipe output");
        Check(PracticeMath.Credit(10,10,1,1,10,10)*2==PracticeMath.Credit(20,10,1,1,10,10),"Split and combined batches must match");
        Check(PracticeMath.Credit(1,1,26,26,60,10)>PracticeMath.Credit(1,1,1,26,14,10),"New tools must teach more than outdated tools");
        Check(PracticeMath.Credit(0,1,1,1,10,10)==0,"No output gives no practice");
        Check(PracticeMath.Required(1,40,0.5)==40 && PracticeMath.Required(11,40,0.5)==45,"Learning costs");
        Check(PracticeMath.MoveCount(50,90,100)==10 && PracticeMath.MoveCount(50,110,100)==0,"Stack capacity and oversized legacy stacks");

        var tile=Setup(); var bag=Workshop.Current.bag.ItemGrid; var chest=tile.Storage.ItemGrid;
        chest.Slots[0]=Stack(1,30); chest.Slots[1]=Stack(2,20);
        string failure;
        Check(Storage.Gather(new[]{Stack(1,5),Stack(2,4)},2,out failure),"Gather two ingredients");
        Check(bag.Slots.Sum(s=>s.count)==18 && chest.Slots.Sum(s=>s.count)==32,"Exact required amounts");
        Check(Storage.Gather(new[]{Stack(1,5)},2,out failure) && bag.Slots.Sum(s=>s.count)==18,"Repeated gather uses existing backpack supplies");

        tile=Setup(1,2);bag=Workshop.Current.bag.ItemGrid;chest=tile.Storage.ItemGrid;
        bag.Slots[0]=Stack(3,100);chest.Slots[0]=Stack(1,20);
        string beforeBag=Snapshot(bag), beforeChest=Snapshot(chest);
        Check(!Storage.Gather(new[]{Stack(1,5)},1,out failure),"A full backpack rejects gather");
        Check(Snapshot(bag)==beforeBag && Snapshot(chest)==beforeChest,"Rejected gather moves nothing");

        tile=Setup();bag=Workshop.Current.bag.ItemGrid;chest=tile.Storage.ItemGrid;
        chest.Slots[0]=Stack(1,5);
        Check(!Storage.Gather(new[]{Stack(1,4),Stack(1,4)},1,out failure),"Duplicate ingredient requirements aggregate");
        Check(chest.Slots[0].count==5 && bag.Slots.All(s=>s.IsEmpty()),"Failed aggregate leaves all supplies intact");
        chest.Locks.Add(0);
        Check(!Storage.Gather(new[]{Stack(1,1)},1,out failure),"Protected storage slot is excluded");
        tile.LocalPlayerIsOwner=false;Check(Storage.Nearby().Count==0,"Other owners excluded");
        tile.LocalPlayerIsOwner=true;tile.PlayerPlaced=false;Check(Storage.Nearby().Count==0,"Unplaced POI loot excluded");
        tile.PlayerPlaced=true;tile.Accessing=true;Check(Storage.Nearby().Count==0,"Open containers excluded");

        tile=Setup();bag=Workshop.Current.bag.ItemGrid;chest=tile.Storage.ItemGrid;
        bag.Slots[0]=Stack(1,60);bag.Locks.Add(0);chest.Slots[0]=Stack(1,70);
        Check(Storage.Transfer(false)==0,"Deposit protects backpack slot");
        Check(Storage.Transfer(true)==40 && bag.Slots[0].count==100 && chest.Slots[0].count==30,"Refill respects capacity");

        tile=Setup();bag=Workshop.Current.bag.ItemGrid;chest=tile.Storage.ItemGrid;
        bag.Slots[0]=Stack(1,60);chest.Slots[0]=Stack(1,90);
        chest.FailNextWrite=true;beforeBag=Snapshot(bag);beforeChest=Snapshot(chest);
        try { Storage.Transfer(false);throw new Exception("Expected injected failure"); } catch(Exception e) { Check(e.Message=="Injected write failure","Write failure surfaced"); }
        Check(beforeBag==Snapshot(bag) && beforeChest==Snapshot(chest),"Write failure rolls back transfer");

        var random=new Random(17);
        for(int iteration=0;iteration<500;iteration++)
        {
            tile=Setup(8,8);bag=Workshop.Current.bag.ItemGrid;chest=tile.Storage.ItemGrid;
            for(int slot=0;slot<8;slot++)
            {
                bag.Slots[slot]=Stack(random.Next(1,5),random.Next(0,101));
                chest.Slots[slot]=Stack(random.Next(1,5),random.Next(0,101));
                if(random.Next(3)==0)bag.Locks.Add(slot);
                if(random.Next(3)==0)chest.Locks.Add(slot);
            }
            var totals=Totals(bag,chest);
            var protectedBag=bag.Locks.ToDictionary(i=>i,i=>bag.Slots[i].count);
            var protectedChest=chest.Locks.ToDictionary(i=>i,i=>chest.Slots[i].count);
            Storage.Transfer(false);
            Check(protectedBag.All(p=>bag.Slots[p.Key].count==p.Value),"Random deposit changed locked inventory");
            Storage.Transfer(true);
            var after=Totals(bag,chest);
            Check(totals.Count==after.Count && totals.All(p=>after[p.Key]==p.Value),"Random transfers lost or duplicated items");
            Check(protectedChest.All(p=>chest.Slots[p.Key].count==p.Value),"Random transfer changed protected storage");
            Check(bag.Slots.Concat(chest.Slots).All(s=>s.count>=0 && s.count<=100),"Random transfer exceeded stack limits");
        }
        tile=Setup();bag=Workshop.Current.bag.ItemGrid;chest=tile.Storage.ItemGrid;
        chest.Slots[0]=Stack(1,20);
        UnityEngine.Time.realtimeSinceStartup=100;
        var group=new XUiWindowGroup { Controller=new XUiController() };
        var list=new XUiC_RecipeList { WindowGroup=group };
        var original=new List<ItemStack> {Stack(1,3)};
        var combined=original;
        RecipeAvailabilityPatch.Prefix(list,ref combined);
        Check(original.Count==1 && combined.Sum(s=>s.count)==23,"Recipe availability includes chest supplies without changing the original list");
        int revision=RecipeSuppliesCache.Revision;
        chest.Slots[0].count=12;
        UnityEngine.Time.realtimeSinceStartup+=0.6f;
        Check(RecipeSuppliesCache.Revision!=revision,"Chest quantity changes refresh recipe supply revision");
        Check(RecipeSuppliesCache.Stacks.Sum(s=>s.count)==12,"UI cache uses fresh chest counts");
        bool resort=false;
        RecipeListRefreshPatch.Prefix(list,ref resort);
        Check(resort && list.IsDirty,"Recipe list resorts after supplies change");
        list.IsDirty=false;resort=false;
        RecipeListRefreshPatch.Prefix(list,ref resort);
        Check(!resort && !list.IsDirty,"Stable chest supplies do not rebuild every frame");
        var ingredientEntry=new XUiC_IngredientEntry { WindowGroup=group };
        IngredientRefreshPatch.Prefix(ingredientEntry);
        Check(ingredientEntry.IsDirty,"Ingredient counters refresh when supplies change");
        var quantityEntry=new XUiC_RecipeCraftCount { WindowGroup=group };
        CraftQuantityRefreshPatch.Prefix(quantityEntry);
        Check(quantityEntry.RefreshCalls==1,"Maximum craft quantity refreshes with nearby supplies");
        chest.Locks.Add(0);
        UnityEngine.Time.realtimeSinceStartup+=0.6f;
        Check(RecipeSuppliesCache.Stacks.Count==0,"UI excludes locked storage slots");
        chest.Locks.Clear();
        Workshop.Current.position=new UnityEngine.Vector3(90,1,90);
        UnityEngine.Time.realtimeSinceStartup+=0.6f;
        Check(RecipeSuppliesCache.Stacks.Count==0,"UI drops supplies when leaving storage range");
        Workshop.Current.position=new UnityEngine.Vector3(1,1,1);
        UnityEngine.Time.realtimeSinceStartup+=0.6f;
        Check(RecipeSuppliesCache.Stacks.Sum(s=>s.count)==12,"UI restores supplies when returning to range");
        group.Controller.Input=new XUiC_WorkstationMaterialInputGrid();
        combined=original;
        RecipeAvailabilityPatch.Prefix(list,ref combined);
        Check(Object.ReferenceEquals(combined,original),"Forge input grids keep vanilla ingredient availability");
        group.Controller.Input=null;
        Workshop.NearbyCrafting=false;
        UnityEngine.Time.realtimeSinceStartup+=0.6f;
        Check(RecipeSuppliesCache.Stacks.Count==0,"Disabling nearby crafting clears its UI supplies");
        Console.WriteLine("Passed "+checks+" regression checks against production storage, practice and recipe UI code.");
    }
}
