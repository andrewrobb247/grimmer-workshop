# 0.1.19 release candidate

Preparation audit passes: all 430 previous routes unchanged; 12 preparation routes plus four secondary campfire routes. 2,619 regressions and 34 layout checks pass. Live preparation tests pending.
