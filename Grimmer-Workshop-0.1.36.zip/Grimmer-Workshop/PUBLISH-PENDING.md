# Publication status

0.1.36 built and tested for normal testing launcher delivery. Display settings opens directly as an owned modal dialog; hidden child process removed; failures appear in launcher. Windows PowerShell 5.1 preview/save/reload, XML generation, modal ownership/return, spaced paths and corrupt/missing-file cases pass. Full regression suite passes. Hosted verification/channel activation follows payload publication. Personal HUD settings remain default-only, preserved on update. Reopen launcher after install. Includes all 0.1.35 audit repairs.
