param([string]$PreviewOutputDirectory)
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot
. (Join-Path $project 'Update-Core.ps1')
$root=Join-Path ([IO.Path]::GetTempPath()) ('Workshop display test '+[guid]::NewGuid().ToString('N'))
$directory=Join-Path $root 'Profile\Mods\ZZZ_GrimmerHUD'
New-Item -ItemType Directory -Path $directory -Force|Out-Null
foreach($name in @('Configure.ps1','Settings.json')){Copy-Item -LiteralPath (Join-Path $project ('Profile\Mods\ZZZ_GrimmerHUD\'+$name)) -Destination (Join-Path $directory $name)}
$before=Get-FileHash (Join-Path $project 'Profile\Mods\ZZZ_GrimmerHUD\Settings.json')
Show-WorkshopDisplaySettings $root $null -PreviewTest
$settings=Get-Content (Join-Path $directory 'Settings.json') -Raw|ConvertFrom-Json
if($settings.BarWidth -ne 500 -or $settings.BarHeight -ne 42 -or $settings.NameSize -ne 26 -or $settings.HealthSize -ne 24 -or -not $settings.ShowNames){throw 'Settings did not persist from preview controls'}
$xml=New-Object Xml.XmlDocument;$xml.Load((Join-Path $directory 'Config\XUi_InGame\windows.xml'))
if($xml.SelectSingleNode('/configs/set[contains(@xpath,"@width")]').InnerText -ne '500'){throw 'HUD patch did not use saved display width'}
foreach($file in @('preview-test.png','preview-large-test.png')){if((Get-Item (Join-Path $root ('Profile\Mods\'+$file))).Length -lt 1000){throw 'Preview failed to render'}}
if($PreviewOutputDirectory) {
    New-Item -ItemType Directory -Path $PreviewOutputDirectory -Force|Out-Null
    Copy-Item -LiteralPath (Join-Path $root 'Profile\Mods\preview-large-test.png') -Destination (Join-Path $PreviewOutputDirectory 'display-fixed-preview.png') -Force
}
& (Join-Path $directory 'Configure.ps1') -GenerateOnly
if((Get-Content (Join-Path $directory 'Settings.json') -Raw|ConvertFrom-Json).BarWidth -ne 500){throw 'Reload lost saved width'}
if((Get-FileHash (Join-Path $project 'Profile\Mods\ZZZ_GrimmerHUD\Settings.json')).Hash -ne $before.Hash){throw 'Test changed real defaults'}
$owner=New-Object Windows.Forms.Form
$owner.StartPosition='Manual';$owner.Location=New-Object Drawing.Point(-3000,-3000);$owner.ShowInTaskbar=$false
$owner.Show()
$timer=New-Object Windows.Forms.Timer
$timer.Interval=100
$timer.Tag=@{Owner=$owner;Opened=$false;Failure=''}
$timer.Add_Tick({
    param($sender,$eventArgs)
    $child=@([Windows.Forms.Application]::OpenForms|Where-Object Text -eq 'Grimmer Workshop - Display Preview')|Select-Object -First 1
    if($null -eq $child){return}
    $sender.Stop()
    $sender.Tag.Opened=$true
    if($child.Owner -ne $sender.Tag.Owner -or -not $child.Modal){$sender.Tag.Failure='Display dialog did not retain its modal launcher owner'}
    $child.Close()
})
try {
    $timer.Start()
    Show-WorkshopDisplaySettings $root $owner
    if(-not $timer.Tag.Opened -or $timer.Tag.Failure){throw ('Owned display dialog failed: '+$timer.Tag.Failure)}
    if(-not $owner.Enabled){throw 'Launcher was not reenabled after closing display settings'}
} finally {$timer.Stop();$timer.Dispose();$owner.Close();$owner.Dispose()}
$failed=$false
try {Show-WorkshopDisplaySettings (Join-Path $root 'missing') $null}catch{$failed=$_.Exception.Message -like 'Display settings file is missing*'}
if(-not $failed){throw 'Missing configurator failure was hidden'}
[IO.File]::WriteAllText((Join-Path $directory 'Settings.json'),'invalid fixture')
$failed=$false
try{Show-WorkshopDisplaySettings $root $null -PreviewTest}catch{$failed=$true}
if(-not $failed){throw 'Invalid settings failure was hidden'}
Write-Host 'PASS: display opens/renders in-process, spaced path, save/reload/XML, original settings untouched and missing/corrupt errors propagate.'
Write-Host ('Preview fixtures: '+$root)
