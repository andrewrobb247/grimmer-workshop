# Publication status

0.1.34 farming/wildlife/pack-status candidate prepared; publication and actual local installation pending. Wildlife original staged unchanged.
