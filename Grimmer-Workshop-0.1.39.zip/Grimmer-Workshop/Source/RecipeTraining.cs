using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace GrimmerWorkshop
{
    public static class RecipeTraining
    {
        sealed class Snapshot { public float Next; public string Text; }
        static readonly ConditionalWeakTable<XUiController, Snapshot> snapshots=new ConditionalWeakTable<XUiController, Snapshot>();
        sealed class Reward { public string Label, Icon; }
        static List<Reward> Rewards(Recipe recipe)
        {
            var entries=new List<Reward>();
            var player=Workshop.Player();
            if(player==null || recipe==null || Workshop.Speed<=0)return entries;
            var output=recipe.GetOutputItemClass();
            List<PracticeRule> rules;
            if(output==null || !Workshop.Rules.TryGetValue(output.GetItemName(),out rules))return entries;
            var seen=new HashSet<string>();
            foreach(var rule in rules) {
                var skill=player.Progression.GetProgressionValue(rule.Skill);
                if(skill==null || rule.Credit<=0)continue;
                int cap=Math.Min(rule.Cap,skill.ProgressionClass.MaxLevel);
                if(skill.Level>=cap || !seen.Add(rule.Skill))continue;
                entries.Add(new Reward {
                    Label=Localization.Get(skill.ProgressionClass.NameKey,false)+" (up to level "+cap+")",
                    Icon=String.IsNullOrEmpty(skill.ProgressionClass.Icon) ? "ui_game_symbol_skills" : skill.ProgressionClass.Icon
                });
            }
            return entries;
        }
        public static string Tooltip(Recipe recipe)
        {
            var entries=Rewards(recipe);
            return entries.Count==0 ? "" : "Crafting trains: "+String.Join("; ",entries.Select(e=>e.Label).ToArray());
        }
        public static string Icon(Recipe recipe,int slot)
        {
            var entries=Rewards(recipe);
            return slot>=0 && slot<entries.Count ? entries[slot].Icon : "";
        }
        public static bool Changed(XUiController controller, Recipe recipe)
        {
            if(controller.WindowGroup==null || !controller.WindowGroup.isShowing) return false;
            var snapshot=snapshots.GetOrCreateValue(controller);
            float now=Time.realtimeSinceStartup;
            if(now<snapshot.Next && now>=snapshot.Next-0.5f) return false;
            snapshot.Next=now+0.5f;
            string text=Tooltip(recipe)+"|"+Icon(recipe,0)+"|"+Icon(recipe,1);
            if(snapshot.Text==text) return false;
            snapshot.Text=text;
            return true;
        }
    }
    [HarmonyPatch(typeof(XUiC_RecipeEntry),"GetBindingValueInternal")]
    public static class RecipeTrainingBindingsPatch
    {
        public static bool Prefix(XUiC_RecipeEntry __instance, ref string __0, string __1, ref bool __result)
        {
            if(__1=="gw_recipe_icon_0" || __1=="gw_recipe_icon_1" || __1=="gw_recipe_show_0" || __1=="gw_recipe_show_1") {
                string icon=RecipeTraining.Icon(__instance.Recipe,__1.EndsWith("0") ? 0 : 1);
                __0=__1.StartsWith("gw_recipe_show_") ? (icon.Length>0 ? "true" : "false") : icon;
            } else if(__1=="gw_recipe_trains" || __1=="gw_recipe_training") {
                string text=RecipeTraining.Tooltip(__instance.Recipe);
                __0=__1=="gw_recipe_trains" ? (text.Length>0 ? "true" : "false") : text;
            } else return true;
            __result=true; return false;
        }
    }
    [HarmonyPatch(typeof(XUiC_RecipeList),"Update")]
    public static class RecipeTrainingRefreshPatch
    {
        public static void Prefix(XUiC_RecipeList __instance)
        {
            foreach(var entry in __instance.GetChildrenByType<XUiC_RecipeEntry>())
                if(RecipeTraining.Changed(entry,entry.Recipe)) entry.IsDirty=true;
        }
    }
}
