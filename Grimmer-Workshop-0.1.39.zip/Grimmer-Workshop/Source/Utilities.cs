using System;
using HarmonyLib;

namespace GrimmerWorkshop
{
    public static class Utilities
    {
        public static bool Station(string name)
        {
            switch(name) {
                case "workbench": case "cementMixer": case "chemistryStation":
                case "grimmerRestoredWorkbench": case "grimmerRestoredMixer": case "grimmerRestoredChemistry":
                case "grimmerGunsmithBench": return true;
                default: return false;
            }
        }
        // No guessed offline electrical uptime: long catch-up intervals get native processing.
        public static float Assisted(float seconds, bool powered)
        {
            return powered && seconds > 0 && seconds <= 2 && !float.IsNaN(seconds) ? seconds * 1.25f : seconds;
        }
        public static bool Powered(WorldBase world, Vector3i position, string name)
        {
            var block=world.GetBlock(position).Block;
            if(block==null || block.GetBlockName()!=name)return false;
            var tile=world.GetTileEntity(position) as TileEntityPowered;
            return tile!=null && tile.IsPowered;
        }
        public static bool Drive(WorldBase world, Vector3i position)
        {
            for(int x=-2;x<=2;x++)for(int y=-2;y<=2;y++)for(int z=-2;z<=2;z++) {
                var p=new Vector3i(position.x+x,position.y+y,position.z+z);
                if(Powered(world,p,"grimmerWorkshopDrive"))return true;
            }
            return false;
        }
        public static bool Irrigated(WorldBase world,Vector3i soil)
        {
            for(int x=-3;x<=3;x++)for(int y=-1;y<=1;y++)for(int z=-3;z<=3;z++) {
                var p=new Vector3i(soil.x+x,soil.y+y,soil.z+z);
                if(!Powered(world,p,"grimmerIrrigationController"))continue;
                foreach(var offset in new[]{new Vector3i(1,0,0),new Vector3i(-1,0,0),new Vector3i(0,1,0),new Vector3i(0,-1,0),new Vector3i(0,0,1),new Vector3i(0,0,-1)})
                    if(world.IsWater(new Vector3i(p.x+offset.x,p.y+offset.y,p.z+offset.z)))return true;
            }
            return false;
        }
    }
    [HarmonyPatch(typeof(TileEntityWorkstation),"HandleRecipeQueue")]
    public static class PoweredQueuePatch
    {
        public static void Prefix(TileEntityWorkstation __instance,ref float __0)
        {
            try {
                var player=Workshop.Player();
                if(player==null || __0<=0 || __0>2)return;
                var position=__instance.ToWorldPos();
                var block=player.world.GetBlock(position).Block;
                if(block!=null && Utilities.Station(block.GetBlockName()))
                    __0=Utilities.Assisted(__0,Utilities.Drive(player.world,position));
            } catch(Exception error) {Log.Error("[Grimmer Workshop] Powered queue: "+error.Message);}
        }
    }
}
