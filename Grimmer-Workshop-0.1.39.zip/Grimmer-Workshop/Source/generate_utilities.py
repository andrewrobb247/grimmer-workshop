"""Generate native-relay utility definitions; no external models or extra runtime files."""
import copy,csv,io,sys
from pathlib import Path
import xml.etree.ElementTree as E
game,project=map(Path,sys.argv[1:]);native=E.parse(game/'Data/Config/blocks.xml').getroot()
blocks=E.Element('configs');a=E.SubElement(blocks,'append',xpath='/blocks');progress=E.Element('configs')
entries=[('grimmerWorkshopDrive','Workshop Drive',35,20,'C8944E','Powered workshop aid. Draws 20 W while connected. Within 2 blocks in each direction of the station base, eligible workbenches, mixers, chemistry stations and Gunsmith Benches process recipe queues 25% faster while loaded and powered. Native tools and fuel remain required; forge smelting and composting are unchanged. Drives do not stack. Long offline catch-up receives no guessed power bonus. Uses the vanilla relay model.'),('grimmerIrrigationController','Irrigation Controller',25,10,'4DAFC7','Draws 10 W and requires a water block touching one face of the controller. Covers cultivated soil within 3 blocks horizontally and 1 vertically. Newly scheduled planted-crop stage intervals are 10% shorter after the cultivated-bed bonus (about 28% shorter combined). Sunlight, yields and ordinary crops stay normal. Water is a reusable source, not consumed inventory; no pipe simulation or drought deaths. Conditions are checked when each stage is scheduled; already pending ticks are unchanged. Uses the vanilla relay model.')]
for name,title,level,watts,tint,desc in entries:
 b=copy.deepcopy(native.find("block[@name='electricwirerelay']"));b.set('name',name);a.append(b)
 for key,val in dict(DescriptionKey=name+'Desc',RequiredPower=str(watts),CustomIcon='electricwirerelay',CustomIconTint=tint,UnlockedBy='craftingElectrician',SellableToTrader='false',EconomicValue='100').items():
  prop=b.find(f"property[@name='{key}']")
  if prop is None:prop=E.SubElement(b,'property',name=key)
  prop.set('value',val)
 effect=E.SubElement(progress,'append',xpath="/progression/crafting_skills/crafting_skill[@name='craftingElectrician']/effect_group")
 E.SubElement(effect,'passive_effect',name='RecipeTagUnlocked',operation='base_set',level=f'{level},100',value='1',tags=name)
text=io.StringIO(newline='');w=csv.writer(text,lineterminator='\n');w.writerow(['Key','File','Type','UsedInMainMenu','NoTranslate','KeepLoaded','english'])
for name,title,level,watts,tint,desc in entries:
 w.writerow([name,'blocks','Block','','','',title]);w.writerow([name+'Desc','blocks','Block','','','',desc])
info='<xml><Name value="ZZZ_GrimmerUtilities"/><DisplayName value="Workshop Powered Utilities"/><Version value="0.1.0"/><Description value="Native relay models for workshop assistance and irrigation. Retain while saves contain these blocks."/><Author value="Grimmer Workshop"/></xml>'
values={'blocks.xml':E.tostring(blocks,encoding='unicode'),'progression.xml':E.tostring(progress,encoding='unicode'),'Localization.csv':text.getvalue(),'../ModInfo.xml':info}
lines=['# BEGIN GENERATED UTILITIES','function Write-WorkshopUtilities([string]$Root) {',"    $directory=Join-Path $Root 'Profile\\Mods\\ZZZ_GrimmerUtilities\\Config'",'    Assert-WorkshopPlainPath $directory','    New-Item -ItemType Directory -Path $directory -Force|Out-Null']
for file,value in values.items():
 lines += ["    $value=@'",value,"'@",f"    $destination=Join-Path $directory '{file}'",'    Assert-WorkshopPlainPath $destination;Assert-WorkshopPlainPath ($destination+\'.tmp\')',"    [IO.File]::WriteAllText(($destination+'.tmp'),$value,(New-Object Text.UTF8Encoding($false)))","    Move-Item -LiteralPath ($destination+'.tmp') -Destination $destination -Force"]
lines+=['}','# END GENERATED UTILITIES']
p=project/'Update-Core.ps1';s=p.read_text(encoding='utf-8-sig');start,end='# BEGIN GENERATED UTILITIES','# END GENERATED UTILITIES'
if start in s:
 before,rest=s.split(start,1);_,after=rest.split(end,1);s=before+'\n'.join(lines)+after
else:s+='\n'+'\n'.join(lines)+'\n'
p.write_text(s,encoding='utf-8');print('Embedded two native powered utility blocks and Electrical unlocks.')
