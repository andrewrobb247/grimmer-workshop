using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using UnityEngine;

namespace GrimmerWorkshop
{
    public sealed class ActionSkillDefinition
    {
        public string Id, Name, Attribute, Action, WeaponSkill, Items;
    }

    // Tracking-only: counters live in player custom vars and are never passed to Workshop.Grant.
    public static class ActionSkillPreview
    {
        static readonly Dictionary<string, ActionSkillDefinition> definitions = new Dictionary<string, ActionSkillDefinition>(StringComparer.OrdinalIgnoreCase);
        static readonly ActionPreviewFrameBudget attributeFrames = new ActionPreviewFrameBudget();
        public static bool Enabled = false;
        public static double LearningSpeed = 1;

        public static void Load(string root, bool enabled, double speed)
        {
            Enabled = enabled;
            LearningSpeed = speed;
            definitions.Clear();
            foreach (XElement entry in XDocument.Load(Path.Combine(root, "ActionSkillPreview.xml")).Root.Elements("skill"))
            {
                var definition = new ActionSkillDefinition {
                    Id = (string)entry.Attribute("id"), Name = (string)entry.Attribute("name"),
                    Attribute = (string)entry.Attribute("attribute"), Action = (string)entry.Attribute("action"),
                    WeaponSkill = (string)entry.Attribute("weaponSkill"), Items = (string)entry.Attribute("items")
                };
                definitions.Add(definition.Id, definition);
            }
        }

        public static ActionSkillDefinition Find(string id)
        {
            ActionSkillDefinition result;
            return id != null && definitions.TryGetValue(id, out result) ? result : null;
        }

        static ActionSkillDefinition ForWeaponSkill(string skill)
        {
            return definitions.Values.FirstOrDefault(x => String.Equals(x.WeaponSkill, skill, StringComparison.OrdinalIgnoreCase));
        }

        public static void RecordWeaponDamage(EntityPlayerLocal player, ItemValue item, int damage, bool headshot)
        {
            if (!Enabled || player == null || item == null || item.IsEmpty() || damage <= 0) return;
            string itemName = item.ItemClass.GetItemName();
            ActionSkillDefinition definition = null;
            List<PracticeRule> rules;
            if (Workshop.Rules.TryGetValue(itemName, out rules))
                foreach (var rule in rules) { definition = ForWeaponSkill(rule.Skill); if (definition != null) break; }
            if (definition == null)
                definition = definitions.Values.FirstOrDefault(x => !String.IsNullOrEmpty(x.Items) &&
                    x.Items.Split(',').Any(name => String.Equals(name.Trim(), itemName, StringComparison.OrdinalIgnoreCase)));
            if (definition != null) RecordDamage(player, definition.Id, damage, headshot);
        }

        public static bool IsActionSkill(string skill) { return Find(skill) != null; }

        public static string Description(string skill)
        {
            var d = Find(skill);
            if (d == null) return null;
            bool precision = d.Id == "perkDeadEye" || d.Id == "perkArchery";
            string tracked = precision ? "base damage and confirmed headshots" : "base damage";
            if (d.WeaponSkill == null && String.IsNullOrEmpty(d.Items))
                return "Practice preview (not recorded yet): " + d.Action + " No perk ranks or skill points change in this preview.";
            double parentPractice = Read(d.Attribute, "base");
            return "Practice preview: records " + tracked + " for " + d.Name + ". " +
                "This preview does not change perk ranks, attributes or skill points. Other listed actions are not recorded yet. " +
                "Recorded: " + Read(skill, "base").ToString("0.#") + " base / " + Read(skill, "bonus").ToString("0.#") +
                " bonus; " + d.Attribute + " " + parentPractice.ToString("0.#") + " parent practice.";
        }

        public static double Read(string skill, string kind)
        {
            var player = Workshop.Player();
            if (player == null) return 0;
            return Math.Max(0, player.Buffs.GetCustomVar(Key(skill, kind)));
        }

        static string Key(string skill, string kind) { return "grimmerActionPreview_" + skill + "_" + kind; }

        static void Add(EntityPlayerLocal player, string skill, string kind, double amount)
        {
            if (amount <= 0 || double.IsNaN(amount) || double.IsInfinity(amount)) return;
            string key = Key(skill, kind);
            player.Buffs.SetCustomVar(key, (float)(player.Buffs.GetCustomVar(key) + amount), true, CVarOperation.set, false);
        }

        static void RecordDamage(EntityPlayerLocal player, string skillId, int damage, bool headshot)
        {
            var d = Find(skillId);
            if (!Enabled || player == null || d == null || damage <= 0) return;

            // Damage is capped by the caller to health actually removed. Equal 25 HP steps keep
            // each hit small while making all real damage useful from rank zero.
            double basePractice = ActionPreviewMath.BaseDamage(damage, LearningSpeed);
            Add(player, d.Id, "base", basePractice);

            // Headshots are confirmed by native hit-region data and add a bounded specialty bonus.
            if (headshot && (d.Id == "perkDeadEye" || d.Id == "perkArchery"))
                Add(player, d.Id, "bonus", ActionPreviewMath.HeadshotBonus(basePractice));

            // Attribute contribution is budgeted once per weapon action frame, so shotgun pellets,
            // multi-target melee and similar multi-hit callbacks cannot multiply the parent award.
            string frameKey = d.Attribute + "_" + (d.WeaponSkill ?? d.Id);
            if (attributeFrames.Take(frameKey, Time.frameCount)) Add(player, d.Attribute, "base", basePractice);
        }
    }
}
