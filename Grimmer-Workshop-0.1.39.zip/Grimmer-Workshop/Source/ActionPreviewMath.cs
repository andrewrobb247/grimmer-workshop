using System;
using System.Collections.Generic;

namespace GrimmerWorkshop
{
    public static class ActionPreviewMath
    {
        public static double BaseDamage(int damage, double speed)
        {
            if (damage <= 0 || speed <= 0 || double.IsNaN(speed) || double.IsInfinity(speed)) return 0;
            return Math.Min(3, damage / 25.0) * Math.Min(10, speed);
        }
        public static double HeadshotBonus(double basePractice)
        {
            return basePractice <= 0 || double.IsNaN(basePractice) || double.IsInfinity(basePractice) ? 0 : basePractice * 0.25;
        }
    }

    public sealed class ActionPreviewFrameBudget
    {
        readonly Dictionary<string, int> lastFrame = new Dictionary<string, int>(StringComparer.Ordinal);
        public bool Take(string key, int frame)
        {
            if (String.IsNullOrEmpty(key)) return false;
            int previous;
            if (lastFrame.TryGetValue(key, out previous) && previous == frame) return false;
            lastFrame[key] = frame;
            return true;
        }
    }
}
