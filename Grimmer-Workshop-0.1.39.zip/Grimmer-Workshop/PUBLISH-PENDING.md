# Publication status

0.1.38 recipe skill icons built for normal testing updater delivery. Actual ProgressionClass.Icon is used, including Construction's custom skill; two active routes display two icons. Tooltip and live cap refresh retained. No recipe/rate/point changes. Hosted verification and channel activation pending. Full regression suite includes native icon selection, dual-route display, independent caps and binding pass-through.
