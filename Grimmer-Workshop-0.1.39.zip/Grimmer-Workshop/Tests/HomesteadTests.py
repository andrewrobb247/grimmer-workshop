"""Check generated launch definitions against native data and prior release.

Run Write-WorkshopHomestead into the supplied probe before this test.
"""
from pathlib import Path
import csv
import math
import sys
import xml.etree.ElementTree as E

game, project, probe, baseline = map(Path, sys.argv[1:])
native = E.parse(game/'Data/Config/blocks.xml').getroot()
native_recipes = E.parse(game/'Data/Config/recipes.xml').getroot()
config = probe/'Profile/Mods/ZZZ_GrimmerHomestead/Config'
blocks = E.parse(config/'blocks.xml').getroot()
items = E.parse(config/'items.xml').getroot()
recipes = E.parse(project/'Profile/Mods/GrimmerWorkshop/Config/recipes.xml').getroot()
rules = E.parse(project/'Profile/Mods/GrimmerWorkshop/PracticeRules.xml').getroot()
checks = 0
def check(value, message):
    global checks
    checks += 1
    assert value, message
def prop(node,name):
    return node.find(f"property[@name='{name}']").get('value')
def ingredients(node):
    return {i.get('name'):int(i.get('count')) for i in node.findall('ingredient')}
bin_block = blocks.find("append/block[@name='grimmerCompostBin']")
check(prop(bin_block,'Class')=='Workstation','Native workstation class')
check(prop(bin_block,'WorkstationWindow')=='workstation_workbench','Native queue UI')
check(prop(bin_block.find("property[@class='Workstation']"),'Modules')=='output','No fuel/input/tool module or storage duplication')
check(prop(bin_block.find("property[@class='Workstation']"),'CraftingAreaRecipes')=='grimmerCompostBin','Dedicated recipe area')
check(prop(bin_block,'Model')==prop(native.find("block[@name='cntWoodWritableCrate']"),'Model'),'Real native crate model')
check(bin_block.find("property[@name='MultiBlockDim']") is None,'One-block footprint')
check(prop(bin_block,'HeatMapStrength')=='0','No heat-generating compost fire')
check(bin_block.find("property[@class='CompositeFeatures']") is None,'No independent storage behind queue')
compost = recipes.find("append/recipe[@name='grimmerCompost']")
check(ingredients(compost)=={'foodRottingFlesh':5,'resourceYuccaFibers':20},'Compost cost')
check(compost.get('craft_time')=='120' and compost.get('craft_area')=='grimmerCompostBin','Compost duration and station')
check(compost.get('count')=='1' and compost.get('always_unlocked')=='true','Explicit output and no magazine gate')
check(prop(items.find("append/item[@name='grimmerCompost']"),'Material')=='MresourceYuccaFibers','Organic input cannot become scrap iron')
plot = next(r for r in recipes.findall('append/recipe') if 'grimmerCompostPlot' in r.get('tags','').split(','))
source = native_recipes.find("recipe[@name='farmPlotBlockVariantHelper']")
check(plot.get('name')==source.get('name'),'Returns real selectable farm plot')
check(ingredients(plot)=={'resourceWood':4,'grimmerCompost':2,'resourcePotassiumNitratePowder':10,'resourceClayLump':100},'Nitrate-saving farm plot cost')
def structure(node):
    return node.tag,node.attrib,[structure(c) for c in node]
check(structure(plot.find('effect_group'))==structure(source.find('effect_group')),'Original farming perk modifiers retained')
for station,item,restored in [('forge','grimmerForgeSalvage','grimmerRestoredForge'),('workbench','grimmerBenchSalvage','grimmerRestoredWorkbench'),('cementMixer','grimmerMixerSalvage','grimmerRestoredMixer'),('chemistryStation','grimmerChemistrySalvage','grimmerRestoredChemistry')]:
    rebuild = next(r for r in recipes.findall('append/recipe') if r.get('name')==restored and 'grimmerStationRestoration' in r.get('tags','').split(','))
    original = native_recipes.find(f"recipe[@name='{station}']")
    check(set(original.get('tags','').split(',')).issubset(set(rebuild.get('tags','').split(','))),station+' retains unlock/perk tags')
    check(rebuild.get('craft_area')==original.get('craft_area'),station+' retains crafting area')
    expected = {n:max(1,math.ceil(c*.7)) for n,c in ingredients(original).items()}
    expected[item]=1
    check(ingredients(rebuild)==expected,station+' exact rebuild cost including scarce single items')
    check(items.find(f"append/item[@name='{item}']") is not None,station+' defines its component')
    restored_block=blocks.find(f"append/block[@name='{restored}']")
    original_block=native.find(f"block[@name='{station}']")
    original_data={p.get('name'):p.get('value') for p in original_block.find("property[@class='Workstation']")}
    original_data.setdefault('CraftingAreaRecipes',station)
    restored_data={p.get('name'):p.get('value') for p in restored_block.find("property[@class='Workstation']")}
    check(restored_data==original_data,station+' original modules and explicit/default recipe areas retained')
    check(prop(restored_block,'Model')==prop(original_block,'Model'),station+' native model retained')
    check(prop(restored_block,'WorkstationWindow')=='workstation_'+station,station+' opens native station UI')
for patch in blocks.findall('append'):
    for drop in patch.findall('drop'):
        check(drop.get('event')=='Destroy' and drop.get('count')=='1' and drop.get('prob')=='0.5','Single destruction chance, no per-hit exploit')
        check(drop.get('tool_category') is None,'No false tool restriction on native Destroy drops')
        name = patch.get('xpath').split("[@name='")[1].split("']")[0]
        check(native.find(f"block[@name='{name}']") is not None,'Ruined block exists')
check(len(blocks.findall('append'))==6,'One new block and five additive wreck patches; native harvest/drop definitions untouched')
old = E.parse(baseline/'Profile/Mods/GrimmerWorkshop/PracticeRules.xml').getroot()
current = {(r.get('item'),r.get('skill')):r.attrib for r in rules}
for rule in old:
    check(current.get((rule.get('item'),rule.get('skill')))==rule.attrib,'Previous practice route changed')
allowed_new={('grimmerCompostBin','craftingConstruction'),('grimmerCompost','craftingSeeds'),
             ('grimmerRestoredForge','craftingWorkstations'),('grimmerRestoredWorkbench','craftingWorkstations'),
             ('grimmerRestoredMixer','craftingWorkstations'),('grimmerRestoredChemistry','craftingWorkstations'),
             ('grimmerCultivatedPlot','craftingConstruction'),('grimmerCultivatedPlot','craftingSeeds'),('grimmerWorkshopDrive','craftingElectrician'),('grimmerWorkshopDrive','craftingWorkstations'),('grimmerIrrigationController','craftingElectrician'),('grimmerIrrigationController','craftingSeeds')}
old_keys={(r.get('item'),r.get('skill')) for r in old}
check(set(current)-old_keys==allowed_new-old_keys,'Only documented new routes; no existing route changes')
check(current['grimmerCompost','craftingSeeds']['credit']=='0.5','Small Seeds award')
check(current['grimmerCompost','craftingSeeds']['cap']=='20','Native Seeds cap')
with (config/'Localization.csv').open(encoding='utf-8-sig',newline='') as f:
    localized={row['Key']:row['english'] for row in csv.DictReader(f)}
for item in items.findall('append/item'):
    check(bool(localized.get(item.get('name'))) and bool(localized.get(item.get('name')+'Desc')),'Name and description')
progress=E.parse(config/'progression.xml').getroot()
for effect in progress.findall('append/passive_effect'):
    skill='craftingSeeds' if effect.get('tags')=='grimmerCultivatedPlot' else 'craftingWorkstations'
    rule=current[effect.get('tags'),skill]
    check(rule['unlock']==effect.get('level').split(',')[0],'Restored station unlock matches practice and original gate')
plot=blocks.find("append/block[@name='grimmerCultivatedPlot']")
check([n.get('name') for n in blocks.findall('append/block')][:5]==['grimmerCompostBin','grimmerRestoredForge','grimmerRestoredWorkbench','grimmerRestoredMixer','grimmerRestoredChemistry'],'Existing companion block order preserved')
check(prop(plot,'Material')==prop(native.find("block[@name='farmPlotBlock']"),'Material'),'Original fertile soil material retained')
check(prop(plot,'Model')==prop(native.find("block[@name='farmPlotBlock']"),'Model'),'Original crop bed model retained')
check(current['grimmerCultivatedPlot','craftingSeeds']['unlock']=='5','Enriched bed unlock at Seeds 5')
print(f'PASS: {checks} homestead/native-data/prior-route checks.')
