using System;
using System.Collections.Generic;
using GrimmerWorkshop;
namespace HarmonyLib{public class HarmonyPatch:Attribute{public HarmonyPatch(Type t,string n){}}}
public struct Vector3i{public int x,y,z;public Vector3i(int a,int b,int c){x=a;y=b;z=c;}}
public class Block{public string name;public string GetBlockName(){return name;}}
public struct BlockValue{public Block Block;}
public class TileEntity{}
public class TileEntityPowered:TileEntity{public bool IsPowered;}
public class TileEntityWorkstation:TileEntity{public Vector3i position;public Vector3i ToWorldPos(){return position;}}
public class WorldBase{
 public Dictionary<string,Block> blocks=new Dictionary<string,Block>();public Dictionary<string,TileEntity> tiles=new Dictionary<string,TileEntity>();public HashSet<string> water=new HashSet<string>();
 public string Key(Vector3i p){return p.x+","+p.y+","+p.z;}
 public BlockValue GetBlock(Vector3i p){Block b;return new BlockValue{Block=blocks.TryGetValue(Key(p),out b)?b:new Block{name="air"}};}
 public TileEntity GetTileEntity(Vector3i p){TileEntity t;return tiles.TryGetValue(Key(p),out t)?t:null;}
 public bool IsWater(Vector3i p){return water.Contains(Key(p));}
 public void Add(int x,int y,int z,string name,bool powered){var p=new Vector3i(x,y,z);blocks[Key(p)]=new Block{name=name};tiles[Key(p)]=new TileEntityPowered{IsPowered=powered};}
}
public class Player{public WorldBase world;}
public static class Log{public static void Error(string s){throw new Exception(s);}}
namespace GrimmerWorkshop{public static class Workshop{public static Player player;public static Player Player(){return player;}}}
class UtilitiesTests{
 static int n;static void Check(bool v,string s){n++;if(!v)throw new Exception(s);}
 static void Main(){
  foreach(var s in new[]{"workbench","cementMixer","chemistryStation","grimmerRestoredWorkbench","grimmerRestoredMixer","grimmerRestoredChemistry","grimmerGunsmithBench"})Check(Utilities.Station(s),"Eligible station "+s);
  foreach(var s in new[]{"forge","grimmerRestoredForge","campfire","grimmerCompostBin","otherModStation",null})Check(!Utilities.Station(s),"Excluded station");
  Check(Utilities.Assisted(1,true)==1.25f&&Utilities.Assisted(2,true)==2.5f,"Bounded powered tick bonus");
  foreach(float f in new[]{0,-1,3,3600,float.PositiveInfinity})Check(Utilities.Assisted(f,true)==f,"No offline/invalid-time boost");
  Check(float.IsNaN(Utilities.Assisted(float.NaN,true)),"No NaN amplification");Check(Utilities.Assisted(1,false)==1,"Power outage native time");
  var w=new WorldBase();var origin=new Vector3i(0,0,0);Check(!Utilities.Drive(w,origin),"Missing drive no bonus");w.Add(2,2,2,"grimmerWorkshopDrive",false);Check(!Utilities.Drive(w,origin),"Unpowered drive no bonus");w.Add(2,2,2,"grimmerWorkshopDrive",true);Check(Utilities.Drive(w,origin),"Radius2 inclusive");Check(!Utilities.Drive(w,new Vector3i(-1,0,0)),"Radius3 excluded");
  w.Add(-2,-2,-2,"grimmerWorkshopDrive",true);Check(Utilities.Assisted(1,Utilities.Drive(w,origin))==1.25f,"Multiple drives never stack");
  w=new WorldBase();w.Add(0,0,0,"grimmerIrrigationController",true);Check(!Utilities.Irrigated(w,origin),"No water no irrigation");w.water.Add(w.Key(new Vector3i(1,0,1)));Check(!Utilities.Irrigated(w,origin),"Diagonal water not connected");w.water.Add(w.Key(new Vector3i(0,-1,0)));Check(Utilities.Irrigated(w,new Vector3i(3,1,3)),"Water and powered pump range inclusive");Check(!Utilities.Irrigated(w,new Vector3i(4,0,0)),"Horizontal range4 excluded");Check(!Utilities.Irrigated(w,new Vector3i(0,2,0)),"Vertical range2 excluded");w.Add(0,0,0,"grimmerIrrigationController",false);Check(!Utilities.Irrigated(w,origin),"Power outage stops future irrigation bonus");
  w=new WorldBase();w.Add(1,0,0,"grimmerWorkshopDrive",true);w.blocks[w.Key(origin)]=new Block{name="workbench"};var tile=new TileEntityWorkstation{position=origin};Workshop.player=new Player{world=w};float delta=1;PoweredQueuePatch.Prefix(tile,ref delta);Check(delta==1.25f,"Actual prefix assists supported station");w.blocks[w.Key(origin)].name="forge";delta=1;PoweredQueuePatch.Prefix(tile,ref delta);Check(delta==1,"Actual prefix excludes forge");w.blocks[w.Key(origin)].name="workbench";Workshop.player=null;delta=1;PoweredQueuePatch.Prefix(tile,ref delta);Check(delta==1,"Actual prefix respects solo player scope");
  Console.WriteLine("PASS: "+n+" utilities power/range/queue/irrigation boundary checks.");
 }
}
