using System;
using System.Linq;
using System.Xml.Linq;

class ActionSkillPreviewTests
{
    static void Check(bool value, string message) { if (!value) throw new Exception(message); }
    static void Equal(double expected, double actual, string message) { Check(Math.Abs(expected-actual)<0.00001, message); }

    static int Main(string[] args)
    {
        try {
            var xml = XDocument.Load(args[0]);
            var source = System.IO.File.ReadAllText(args[1]);
            var practiceRules = new System.Collections.Generic.HashSet<string>(xml.Root.Elements("rule").Select(x => (string)x.Attribute("skill")), StringComparer.OrdinalIgnoreCase);
            var nativeItems = System.IO.File.ReadAllText(args[2]);
            var skills = xml.Root.Elements("actionSkill").ToList();
            Check(skills.Count == 57, "The preview config must describe all 57 perks.");
            Check(skills.Select(x => (string)x.Attribute("id")).Distinct(StringComparer.OrdinalIgnoreCase).Count() == 57, "Perk IDs must be unique.");
            Check(skills.Count(x => x.Attribute("weaponSkill") != null) == 7 && skills.Count(x => x.Attribute("items") != null) == 1, "The preview must have seven route-backed families and one native-item family.");
            Check(skills.Where(x => x.Attribute("weaponSkill") != null).All(x => practiceRules.Contains((string)x.Attribute("weaponSkill"))), "Each route-backed preview family must match an installed practice route.");
            Check(skills.Where(x => x.Attribute("items") != null).SelectMany(x => ((string)x.Attribute("items")).Split(',')).All(name => nativeItems.Contains("<item name=\"" + name.Trim() + "\">")), "Directly mapped weapons must exist in native items.xml.");
            Check(skills.All(x => source.Contains("\"id\": \"" + (string)x.Attribute("id") + "\"")), "Preview IDs must exist in proposal map.");

            Equal(0, GrimmerWorkshop.ActionPreviewMath.BaseDamage(0,1), "Misses earn no practice.");
            Equal(0, GrimmerWorkshop.ActionPreviewMath.BaseDamage(30,0), "A zero learning rate earns no practice.");
            Equal(1, GrimmerWorkshop.ActionPreviewMath.BaseDamage(25,1), "Damage converts to base practice.");
            Equal(3, GrimmerWorkshop.ActionPreviewMath.BaseDamage(250,1), "One callback is capped.");
            Equal(6, GrimmerWorkshop.ActionPreviewMath.BaseDamage(250,2), "Preview speed scales practice.");
            Equal(0.25, GrimmerWorkshop.ActionPreviewMath.HeadshotBonus(1), "Headshot bonus is supplemental.");
            Equal(0, GrimmerWorkshop.ActionPreviewMath.HeadshotBonus(0), "No bonus without base damage.");

            var budget = new GrimmerWorkshop.ActionPreviewFrameBudget();
            Check(budget.Take("attPerception_craftingRifles",10), "First parent action is recorded.");
            Check(!budget.Take("attPerception_craftingRifles",10), "Pellets or multi-target callbacks in one action frame cannot duplicate parent credit.");
            Check(budget.Take("attPerception_craftingRifles",11), "A later action can train the parent again.");
            Check(budget.Take("attStrength_craftingShotguns",10), "Different parent families have independent budgets.");
            Check(!budget.Take("",10), "Invalid keys are rejected.");
            Console.WriteLine("All action preview checks passed.");
            return 0;
        } catch(Exception error) { Console.Error.WriteLine(error); return 1; }
    }
}