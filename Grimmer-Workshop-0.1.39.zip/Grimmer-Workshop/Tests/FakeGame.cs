// A small test harness for the original storage algorithm. Production builds
// reference the real game assemblies instead of these in-memory fixtures.
using System;
using System.Collections.Generic;
using System.Linq;

namespace UnityEngine
{
    public static class Time { public static float realtimeSinceStartup; }
    public struct Vector3
    {
        public float x, y, z;
        public Vector3(float a, float b, float c) { x = a; y = b; z = c; }
        public static Vector3 operator -(Vector3 a, Vector3 b) { return new Vector3(a.x-b.x, a.y-b.y, a.z-b.z); }
        public float sqrMagnitude { get { return x*x + y*y + z*z; } }
    }
}
public struct Vector3i { public int x, y, z; }
public class DataItem { public int Value = 100; }
public class ItemClass { public DataItem Stacknumber = new DataItem(); public string Name; public string GetItemName() { return Name; } }
public class ItemValue
{
    public int type;
    public bool HasQuality;
    public int Quality, Condition;
    public string ModTag="";
    public string Variant = "";
    public ItemClass ItemClass = new ItemClass();
    public ItemValue(int id, bool ignored) { type = id; }
    public ItemValue Clone() { return new ItemValue(type, false) { HasQuality = HasQuality, Quality = Quality, Condition = Condition, ModTag = ModTag, Variant = Variant, ItemClass = ItemClass }; }
}
public class ItemStack
{
    public ItemValue itemValue;
    public int count;
    public static ItemStack Empty { get { return new ItemStack(new ItemValue(0, false), 0); } }
    public ItemStack(ItemValue value, int amount) { itemValue=value; count=amount; }
    public bool IsEmpty() { return count <= 0 || itemValue.type == 0; }
    public ItemStack Clone() { return new ItemStack(itemValue.Clone(), count); }
    public bool CanStackWith(ItemStack other, bool ignored) { return itemValue.type == other.itemValue.type && itemValue.Variant == other.itemValue.Variant && itemValue.Quality == other.itemValue.Quality && itemValue.Condition == other.itemValue.Condition && itemValue.ModTag == other.itemValue.ModTag; }
}
public class ItemStackGrid
{
    public ItemStack[] Slots;
    public HashSet<int> Locks = new HashSet<int>();
    public bool FailNextWrite;
    public ItemStackGrid(int count) { Slots=Enumerable.Range(0,count).Select(i=>ItemStack.Empty).ToArray(); }
    public int Length { get { return Slots.Length; } }
    public ItemStack this[int i] { get { return Slots[i]; } }
    public bool IsSlotLocked(int i) { return Locks.Contains(i); }
    public ItemStack[] CloneItems() { return Slots.Select(s=>s.Clone()).ToArray(); }
    public void SetItems(ItemStack[] items, bool ignored)
    {
        if (FailNextWrite) { FailNextWrite=false; throw new Exception("Injected write failure"); }
        Slots=items.Select(s=>s.Clone()).ToArray();
    }
}
public class Bag
{
    public ItemStackGrid ItemGrid;
    public Bag(int size) { ItemGrid=new ItemStackGrid(size); }
    public int GetItemCount(ItemValue value, int a, int b, bool c) { return ItemGrid.Slots.Where(s=>s.itemValue.type==value.type).Sum(s=>s.count); }
}
public class Inventory
{
    public int GetItemCount(ItemValue value, bool a, int b, int c, bool d) { return 0; }
}
public class TileEntity { public virtual void setModified() {} }
public class TEFeatureStorage { public ItemStackGrid ItemGrid; }
public class TileEntityComposite : TileEntity
{
    public bool PlayerPlaced=true, LocalPlayerIsOwner=true, Accessing;
    public TEFeatureStorage Storage;
    public Vector3i Position;
    public bool IsUserAccessing() { return Accessing; }
    public Vector3i ToWorldPos() { return Position; }
    public T GetFeature<T>() where T:class { return Storage as T; }
}
public class TileList { public List<TileEntity> list=new List<TileEntity>(); }
public class Chunk { public TileList Tiles=new TileList(); public TileList GetTileEntities() { return Tiles; } }
public class World
{
    public Chunk Chunk=new Chunk();
    public object GetChunkFromWorldPos(int x,int z) { return x == 0 && z == 0 ? Chunk : null; }
}
public class EntityPlayerLocal
{
    public TestProgression Progression = new TestProgression();
    public EntityBuffs Buffs = new EntityBuffs();
    public UnityEngine.Vector3 position=new UnityEngine.Vector3(1,1,1);
    public Bag bag;
    public Inventory inventory=new Inventory();
    public World world=new World();
}
namespace GrimmerWorkshop
{
    public static class Workshop
    {
        public static double Cost=40, Growth=0.5, ActivitySpeed=1, Speed=1;
        public static Dictionary<string,List<PracticeRule>> Rules=new Dictionary<string,List<PracticeRule>>();
        public static HashSet<string> Skills=new HashSet<string> {"craftingHarvestingTools"};
        public static int Range=20;
        public static bool NearbyCrafting=true;
        public static EntityPlayerLocal Current;
        public static EntityPlayerLocal Player() { return Current; }
    }
}
namespace HarmonyLib
{
    public class HarmonyPatch : Attribute { public HarmonyPatch(Type type,string name) {} }
}
public class XUiWindowGroup { public bool isShowing=true; public XUiController Controller; }
public class XUiController
{
    public XUiWindowGroup WindowGroup;
    public bool IsDirty;
    public XUiC_WorkstationInputGrid Input;
    public T GetChildByType<T>() where T:class { return Input as T; }
    public List<XUiController> Children=new List<XUiController>();
    public T[] GetChildrenByType<T>(List<T> unused=null) where T:class { return Children.OfType<T>().ToArray(); }
}
public class XUiC_RecipeList : XUiController {}
public class XUiC_IngredientEntry : XUiController {}
public class XUiC_RecipeCraftCount : XUiController
{
    public int RefreshCalls;
    public void RefreshCounts() { RefreshCalls++; }
}
public class XUiC_WorkstationInputGrid : XUiController {}
public class XUiC_WorkstationMaterialInputGrid : XUiC_WorkstationInputGrid {}
public static class XUiM_Recipes { public static bool DisableSmelter; }
public class EntityBuffs
{
    public Dictionary<string,float> Values=new Dictionary<string,float>();
    public float GetCustomVar(string name) { float value; return Values.TryGetValue(name,out value) ? value : 0; }
}
public class ProgressionValue
{
    public string Name;
    public int Level;
    public ProgressionClass ProgressionClass=new ProgressionClass();
}
public class ProgressionClass
{
    public string NameKey;
    public string Icon;
    public int MaxLevel=100;
    public List<DisplayData> DisplayDataList=new List<DisplayData>();
    public class DisplayData
    {
        public bool Enabled=true, HasQuality=true;
        public string Label="Stone Tools";
        public string[] Labels;
        public int[] Levels=new[]{1,2,4,6,8,10};
        public int GetNextPoints(int level) { return Levels.FirstOrDefault(n=>n>level); }
        public string GetName(int level) { int index=GetQualityLevel(level); return Labels==null ? Label : Labels[index<Labels.Length ? index : 0]; }
        public int GetQualityLevel(int level) { return Levels.Count(n=>n<=level); }
    }
}
public static class Localization { public static string Get(string name,bool unused) { return name; } }
public class XUiC_SkillCraftingInfoWindow : XUiController { public ProgressionValue CurrentSkill; }
public class XUiC_SkillEntry : XUiController { public ProgressionValue Skill; }

public class Recipe { public ItemClass Output; public ItemClass GetOutputItemClass() { return Output; } }
public class XUiC_RecipeEntry : XUiController { public Recipe Recipe; }
public class TestProgression {
 public Dictionary<string,ProgressionValue> Values=new Dictionary<string,ProgressionValue>(StringComparer.OrdinalIgnoreCase);
 public ProgressionValue GetProgressionValue(string key) { ProgressionValue value;return Values.TryGetValue(key,out value) ? value : null; }
}
namespace GrimmerWorkshop { public sealed class PracticeRule { public string Item,Skill;public int Output,Unlock,Until,Cap;public double Credit; } }
