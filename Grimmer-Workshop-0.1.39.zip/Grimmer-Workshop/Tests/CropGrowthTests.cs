using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using GrimmerWorkshop;
namespace HarmonyLib {
 public class HarmonyPatch:Attribute{public HarmonyPatch(Type t,string n){}}
 public class CodeInstruction{public OpCode opcode;public object operand;public List<Label> labels=new List<Label>();public List<object> blocks=new List<object>();public CodeInstruction(OpCode op,object value=null){opcode=op;operand=value;}}
 public static class AccessTools{public static MethodInfo Method(Type t,string n){return t.GetMethod(n);}}
}
public class Block{public string name;public ulong ticks=1200;public virtual ulong GetTickRate(){return ticks;}public string GetBlockName(){return name;}}
public class BlockPlantGrowing:Block{}
public struct Vector3i{public int x,y,z;}
public struct BlockValue{public Block Block;}
public class WorldBase{public Block soil;public int checkedY;public BlockValue GetBlock(Vector3i p){checkedY=p.y;return new BlockValue{Block=soil};}}
namespace GrimmerWorkshop{public static class Workshop{public static object player=new object();public static object Player(){return player;}}}
namespace GrimmerWorkshop{public static class Utilities{public static bool watered;public static bool Irrigated(WorldBase w,Vector3i p){return watered;}}}
class CropGrowthTests{
 static int n;static void Check(bool v,string s){n++;if(!v)throw new Exception(s);}
 static void Main(){
  var crop=new BlockPlantGrowing{name="plantedCorn1"};var w=new WorldBase{soil=new Block{name="farmPlotBlock"}};var p=new Vector3i{y=50};
  Check(CropGrowth.Ticks(crop,w,p)==1200,"Native plot unchanged");w.soil.name="grimmerCultivatedPlot";
  Check(CropGrowth.Ticks(crop,w,p)==960&&w.checkedY==49,"Only soil immediately below plant gives 20 percent shorter interval");
  Check(p.y==50,"Original crop position not modified");Workshop.player=null;Check(CropGrowth.Ticks(crop,w,p)==1200,"Solo scope");Workshop.player=new object();
  Utilities.watered=true;Check(CropGrowth.Ticks(crop,w,p)==864,"Powered irrigation combines 80 and 90 percent intervals");Utilities.watered=false;
  crop.name="treeOak";Check(CropGrowth.Ticks(crop,w,p)==1200,"Non-crop growth excluded");crop.name="plantedCorn1";
  Check(CropGrowth.Scale(0)==0&&CropGrowth.Scale(1)==1,"Small/zero intervals safe");
  Check(CropGrowth.Scale(ulong.MaxValue)>0&&CropGrowth.Scale(ulong.MaxValue)<ulong.MaxValue,"Integer scaling cannot overflow");
  var call=typeof(Block).GetMethod("GetTickRate");var src=new[]{new HarmonyLib.CodeInstruction(OpCodes.Callvirt,call),new HarmonyLib.CodeInstruction(OpCodes.Callvirt,call)};
  var output=new List<HarmonyLib.CodeInstruction>(CropGrowth.Transpiler(src));Check(output.Count==6,"Both native schedule branches routed with world/position");
  Check(output[0].opcode==OpCodes.Ldarg_1&&output[1].opcode==OpCodes.Ldarg_2&&((MethodInfo)output[2].operand).Name=="Ticks","Evaluation stack passes native block then world and position");
  bool bad=false;try{new List<HarmonyLib.CodeInstruction>(CropGrowth.Transpiler(new HarmonyLib.CodeInstruction[0]));}catch(InvalidOperationException){bad=true;}Check(bad,"Changed game IL fails closed");
  Console.WriteLine("PASS: "+n+" crop scope/scaling/transpiler checks.");
 }
}
