param([string]$ArsenalDirectory, [string]$HomesteadBaselineDirectory, [string]$GuppyDirectory, [string]$BdubDirectory, [string]$DecorDirectory, [string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$testDirectory = Join-Path $PSScriptRoot '..\work\workshop-tests'
if ($HomesteadBaselineDirectory) {
    . (Join-Path $PSScriptRoot 'Update-Core.ps1')
    $homesteadProbe = Join-Path $testDirectory 'homestead-probe'
    Write-WorkshopHomestead $homesteadProbe $GameDirectory
    & python (Join-Path $PSScriptRoot 'Tests\HomesteadTests.py') $GameDirectory $PSScriptRoot $homesteadProbe $HomesteadBaselineDirectory
    if ($LASTEXITCODE -ne 0) { throw 'Homestead native-data checks failed.' }
}
New-Item -ItemType Directory -Path $testDirectory -Force | Out-Null
if ($BdubDirectory) {
    $vehiclePackTests=Join-Path $testDirectory 'VehiclePackRulesTests.exe'
    & $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:"+$vehiclePackTests) (Join-Path $PSScriptRoot 'Source\VehiclePackRules.cs') (Join-Path $PSScriptRoot 'Tests\VehiclePackRulesTests.cs')
    if($LASTEXITCODE -ne 0){throw 'Vehicle pack test compilation failed.'}
    & $vehiclePackTests $BdubDirectory (Join-Path $PSScriptRoot 'Profile\Mods\GrimmerWorkshop\PracticeRules.xml') (Join-Path $GameDirectory 'Data\Config\items.xml') (Join-Path $GameDirectory 'Data\Config\items.xml')
    if($LASTEXITCODE -ne 0){throw 'Vehicle pack practice checks failed.'}
}
if ($GuppyDirectory) {
    . (Join-Path $PSScriptRoot 'Update-Core.ps1')
    $enemyProbe=Join-Path $testDirectory 'enemy-probe'
    $packProbe=Join-Path $enemyProbe 'Profile\Mods\Guppy_Zombies_V3'
    New-Item -ItemType Directory -Path (Join-Path $packProbe 'Config') -Force | Out-Null
    Copy-Item -LiteralPath (Join-Path $GuppyDirectory 'ModInfo.xml') -Destination (Join-Path $packProbe 'ModInfo.xml')
    foreach($file in @('entityclasses.xml','entitygroups.xml')) {
        Copy-Item -LiteralPath (Join-Path $GuppyDirectory ('Config\'+$file)) -Destination (Join-Path $packProbe ('Config\'+$file))
    }
    Write-WorkshopEnemyBalance $enemyProbe $GameDirectory
    & python (Join-Path $PSScriptRoot 'Tests\EnemyBalanceTests.py') (Join-Path $GameDirectory 'Data\Config') $GuppyDirectory (Join-Path $enemyProbe 'Profile\Mods\ZZZ_GrimmerEnemies')
    if ($LASTEXITCODE -ne 0) { throw 'Optional zombie native/spawn checks failed.' }
}
$actionPreviewTests = Join-Path $testDirectory 'ActionSkillPreviewTests.exe'
& $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:" + $actionPreviewTests) (Join-Path $PSScriptRoot 'Source\ActionPreviewMath.cs') (Join-Path $PSScriptRoot 'Tests\ActionSkillPreviewTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Action preview test compilation failed.' }
& $actionPreviewTests (Join-Path $PSScriptRoot 'Profile\Mods\GrimmerWorkshop\PracticeRules.xml') (Join-Path $PSScriptRoot 'Source\ACTION-SKILL-MAP.json') (Join-Path $GameDirectory 'Data\Config\items.xml')
if ($LASTEXITCODE -ne 0) { throw 'Action preview checks failed.' }

$testExecutable = Join-Path $testDirectory 'RegressionTests.exe'
& $compiler /nologo /target:exe ("/out:" + $testExecutable) (Join-Path $PSScriptRoot 'Source\Storage.cs') (Join-Path $PSScriptRoot 'Source\PracticeMath.cs') (Join-Path $PSScriptRoot 'Source\ActivityBudget.cs') (Join-Path $PSScriptRoot 'Source\SkillScreenText.cs') (Join-Path $PSScriptRoot 'Source\SkillScreen.cs') (Join-Path $PSScriptRoot 'Source\CraftingUi.cs') (Join-Path $PSScriptRoot 'Source\RecipeTraining.cs') (Join-Path $PSScriptRoot 'Tests\FakeGame.cs') (Join-Path $PSScriptRoot 'Tests\RegressionTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Regression test compilation failed.' }
& $testExecutable
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed.' }
$buttonTests = Join-Path $testDirectory 'StorageButtonTests.exe'
& $compiler /nologo /target:exe ("/out:" + $buttonTests) (Join-Path $PSScriptRoot 'Source\StorageButtons.cs') (Join-Path $PSScriptRoot 'Tests\StorageButtonTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Storage button test compilation failed.' }
& $buttonTests
if ($LASTEXITCODE -ne 0) { throw 'Storage button tests failed.' }




$creditTests = Join-Path $testDirectory 'WorkstationCreditTests.exe'
& $compiler /nologo /target:exe ("/out:" + $creditTests) (Join-Path $PSScriptRoot 'Source\WorkstationCredit.cs') (Join-Path $PSScriptRoot 'Tests\WorkstationCreditTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Workstation credit test compilation failed.' }
& $creditTests
if ($LASTEXITCODE -ne 0) { throw 'Workstation credit tests failed.' }
$vehicleTests = Join-Path $testDirectory 'VehicleInspectionTests.exe'
& $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:" + $vehicleTests) (Join-Path $PSScriptRoot 'Source\VehicleInspectionState.cs') (Join-Path $PSScriptRoot 'Tests\VehicleInspectionTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Vehicle inspection test compilation failed.' }
& $vehicleTests $testDirectory
if ($LASTEXITCODE -ne 0) { throw 'Vehicle inspection tests failed.' }
$vehicleIntegration = Join-Path $testDirectory 'VehicleInspectionIntegrationTests.exe'
& $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:" + $vehicleIntegration) (Join-Path $PSScriptRoot 'Source\VehicleInspectionState.cs') (Join-Path $PSScriptRoot 'Source\VehicleInspection.cs') (Join-Path $PSScriptRoot 'Tests\VehicleInspectionIntegrationTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Vehicle interaction test compilation failed.' }
& $vehicleIntegration $testDirectory
if ($LASTEXITCODE -ne 0) { throw 'Vehicle interaction tests failed.' }
$pickupTests = Join-Path $testDirectory 'StoragePickupTests.exe'
& $compiler /nologo /target:exe /main:StoragePickupTests /reference:System.Xml.Linq.dll ("/out:" + $pickupTests) (Join-Path $PSScriptRoot 'Source\VehicleInspectionState.cs') (Join-Path $PSScriptRoot 'Source\VehicleInspection.cs') (Join-Path $PSScriptRoot 'Source\StoragePickup.cs') (Join-Path $PSScriptRoot 'Tests\VehicleInspectionIntegrationTests.cs') (Join-Path $PSScriptRoot 'Tests\StoragePickupTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Storage pickup test compilation failed.' }
& $pickupTests
if ($LASTEXITCODE -ne 0) { throw 'Storage pickup tests failed.' }
$gunsmithTests = Join-Path $testDirectory 'GunsmithTimeTests.exe'
& $compiler /nologo /target:exe ("/out:" + $gunsmithTests) (Join-Path $PSScriptRoot 'Source\Gunsmith.cs') (Join-Path $PSScriptRoot 'Tests\GunsmithTimeTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Gunsmith timing test compilation failed.' }
& $gunsmithTests
if ($LASTEXITCODE -ne 0) { throw 'Gunsmith timing tests failed.' }
$variantTests = Join-Path $testDirectory 'RecipeVariantsTests.exe'
& $compiler /nologo /target:exe ("/out:" + $variantTests) (Join-Path $PSScriptRoot 'Source\RecipeVariants.cs') (Join-Path $PSScriptRoot 'Tests\RecipeVariantsTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Recipe variant test compilation failed.' }
& $variantTests
if ($LASTEXITCODE -ne 0) { throw 'Recipe variant display tests failed.' }
if ($ArsenalDirectory) {
    $arsenalTests = Join-Path $testDirectory 'ArsenalRulesTests.exe'
    & $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:" + $arsenalTests) (Join-Path $PSScriptRoot 'Source\ArsenalRules.cs') (Join-Path $PSScriptRoot 'Tests\ArsenalRulesTests.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Arsenal test compilation failed.' }
    & $arsenalTests $ArsenalDirectory
    if ($LASTEXITCODE -ne 0) { throw 'Arsenal practice tests failed.' }
}

if($DecorDirectory) {
    $decorTests=Join-Path $testDirectory 'DecorRulesTests.exe'
    & $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:"+$decorTests) (Join-Path $PSScriptRoot 'Source\DecorRules.cs') (Join-Path $PSScriptRoot 'Tests\DecorRulesTests.cs')
    if($LASTEXITCODE -ne 0){throw 'Decor tests compilation failed.'}
    & $decorTests $DecorDirectory
    if($LASTEXITCODE -ne 0){throw 'Decor recipe/practice checks failed.'}
    $decorTimeTests=Join-Path $testDirectory 'DecorTimeTests.exe'
    & $compiler /nologo /target:exe /main:DecorTimeTests /reference:System.Xml.Linq.dll ("/out:"+$decorTimeTests) (Join-Path $PSScriptRoot 'Source\DecorRules.cs') (Join-Path $PSScriptRoot 'Source\DecorTime.cs') (Join-Path $PSScriptRoot 'Tests\DecorRulesTests.cs') (Join-Path $PSScriptRoot 'Tests\DecorTimeTests.cs')
    if($LASTEXITCODE -ne 0){throw 'Decor timing tests compilation failed.'}
    & $decorTimeTests
    if($LASTEXITCODE -ne 0){throw 'Decor craft-time integration checks failed.'}
}
$cropTests=Join-Path $testDirectory 'CropGrowthTests.exe'
& $compiler /nologo /target:exe ("/out:"+$cropTests) (Join-Path $PSScriptRoot 'Source\CropGrowth.cs') (Join-Path $PSScriptRoot 'Tests\CropGrowthTests.cs')
if($LASTEXITCODE -ne 0){throw 'Crop tests compilation failed.'}
& $cropTests
if($LASTEXITCODE -ne 0){throw 'Crop growth checks failed.'}
& (Join-Path $PSScriptRoot 'Tests\PackStatusTests.ps1')

& (Join-Path $PSScriptRoot 'Tests\GeneratedConfigTests.ps1') -GuppyDirectory $GuppyDirectory -GameDirectory $GameDirectory

powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File (Join-Path $PSScriptRoot 'Tests\DisplaySettingsTests.ps1')
if ($LASTEXITCODE -ne 0) { throw 'Display settings checks failed.' }

$utilityTests=Join-Path $testDirectory 'UtilitiesTests.exe'
& $compiler /nologo /target:exe ("/out:"+$utilityTests) (Join-Path $PSScriptRoot 'Source\Utilities.cs') (Join-Path $PSScriptRoot 'Tests\UtilitiesTests.cs')
if($LASTEXITCODE -ne 0){throw 'Utilities test compilation failed.'}
& $utilityTests
if($LASTEXITCODE -ne 0){throw 'Utilities boundary checks failed.'}
