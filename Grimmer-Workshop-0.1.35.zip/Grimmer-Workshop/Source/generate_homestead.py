"""Embed original homestead definitions in the Windows launch helper.

No Python dependency on the player's machine; native assets only.
"""
import copy
import sys
from pathlib import Path
import xml.etree.ElementTree as E

game, project = map(Path, sys.argv[1:])
native = E.parse(game / 'Data/Config/blocks.xml').getroot()
blocks = E.Element('configs')
append = E.SubElement(blocks, 'append', xpath='/blocks')
bin_block = copy.deepcopy(native.find("block[@name='workbench']"))
bin_block.set('name', 'grimmerCompostBin')
append.append(bin_block)
for prop in list(bin_block.findall('property')):
    if prop.get('name') in {'MultiBlockDim', 'ModelOffset', 'HeatMapStrength', 'HeatMapTime', 'HeatMapFrequency', 'UnlockedBy', 'TraderStageTemplate'}:
        bin_block.remove(prop)

def setprop(node, name, value):
    prop = node.find(f"property[@name='{name}']")
    if prop is None:
        prop = E.SubElement(node, 'property', name=name)
    prop.set('value', value)

model = native.find("block[@name='cntWoodWritableCrate']/property[@name='Model']").get('value')
for name, value in dict(DescriptionKey='grimmerCompostBinDesc', Model=model, ModelOffset='0,0,0',
    Material='MwoodReinforced', CustomIcon='cntWoodWritableCrate', CustomIconTint='88A66B',
    MaxDamage='500', EconomicValue='30', WorkstationWindow='workstation_workbench',
    WorkstationIcon='ui_game_symbol_workbench', HeatMapStrength='0', Group='Food/Cooking,Building',
    FilterTags='MC_outdoor,SC_crops', SellableToTrader='false').items():
    setprop(bin_block, name, value)
ws = bin_block.find("property[@class='Workstation']")
setprop(ws, 'CraftingAreaRecipes', 'grimmerCompostBin')
repair = bin_block.find("property[@class='RepairItems']")
if repair is not None:
    bin_block.remove(repair)
repair = E.SubElement(bin_block, 'property', {'class':'RepairItems'})
E.SubElement(repair, 'property', name='resourceWood', value='10')
for drop in list(bin_block.findall('drop')):
    bin_block.remove(drop)
E.SubElement(bin_block, 'drop', event='Destroy', count='0')

items = E.Element('configs')
ia = E.SubElement(items, 'append', xpath='/items')
names = [('grimmerCompost', 'Compost', 'foodRottingFlesh', '666F38',
          'Made in a Compost Bin from 5 rotten flesh and 20 plant fibres. Two Compost replace the rotten flesh and reduce base nitrate from 25 to 10 in the alternative Farm Plot recipe. Composting trains Seeds; it does not directly change crop yield or growth time.')]
progression = E.Element('configs')
plot = copy.deepcopy(native.find("block[@name='farmPlotBlock']"))
plot.set('name','grimmerCultivatedPlot')
for name,val in dict(CreativeMode='Player',CustomIcon='farmPlotBlockVariantHelper',CustomIconTint='8EBF63',
                     DescriptionKey='grimmerCultivatedPlotDesc',UnlockedBy='craftingSeeds').items():
    setprop(plot,name,val)
pa=E.SubElement(progression,'append',xpath="/progression/crafting_skills/crafting_skill[@name='craftingSeeds']/effect_group")
E.SubElement(pa,'passive_effect',name='RecipeTagUnlocked',operation='base_set',level='5,20',value='1',tags='grimmerCultivatedPlot')
unlocks = E.parse(game/'Data/Config/progression.xml').getroot().find("crafting_skills/crafting_skill[@name='craftingWorkstations']")
station_names = [('forge','grimmerRestoredForge','Restored Forge'),('workbench','grimmerRestoredWorkbench','Restored Workbench'),
                 ('cementMixer','grimmerRestoredMixer','Restored Cement Mixer'),('chemistryStation','grimmerRestoredChemistry','Restored Chemistry Station')]
station_text = []
for original, restored, title in station_names:
    block = copy.deepcopy(native.find(f"block[@name='{original}']"))
    block.set('name', restored)
    for name,val in dict(CustomIcon=original,DescriptionKey=restored+'Desc',WorkstationWindow='workstation_'+original,
                         UnlockedBy='craftingWorkstations',SellableToTrader='false').items():
        setprop(block,name,val)
    station_data = block.find("property[@class='Workstation']")
    if station_data.find("property[@name='CraftingAreaRecipes']") is None:
        # Native mixer/chemistry infer this from their original block name.
        # Custom-named restored blocks must keep that original recipe area.
        setprop(station_data,'CraftingAreaRecipes',original)
    # Retain the original crafting areas, tools, fuel, forge input/smelting,
    # recipe requirements, queues, heat and material/repair properties.
    append.append(block)
    level = min(int(e.get('level').split(',')[0]) for e in unlocks.findall(".//passive_effect[@name='RecipeTagUnlocked']")
                if original in e.get('tags','').split(','))
    pa = E.SubElement(progression,'append',xpath="/progression/crafting_skills/crafting_skill[@name='craftingWorkstations']/effect_group")
    E.SubElement(pa,'passive_effect',name='RecipeTagUnlocked',operation='base_set',level=f'{level},75',value='1',tags=restored)
    station_text.extend([(restored,title),(restored+'Desc',f'Rebuilt from ruined-station parts with about 30% fewer normal materials. Unlocks at Workstations {level}. Uses the normal {original} model, recipes, tools, fuel and crafting speed. Rebuilding trains Workstations; this is a material-saving restoration, not a faster or powered station.')])
append.append(plot) # Append after existing station definitions to retain their order.
stations = [('cntForgeWorkstationBroken','forge','grimmerForgeSalvage','Forge Restoration Parts'),
            ('cntCollapsedWorkbench','workbench','grimmerBenchSalvage','Workbench Restoration Parts'),
            ('cntCollapsedWorkbenchEmpty','workbench','grimmerBenchSalvage','Workbench Restoration Parts'),
            ('cntCollapsedCementMixer','cementMixer','grimmerMixerSalvage','Mixer Restoration Parts'),
            ('cntCollapsedChemistryStation','chemistryStation','grimmerChemistrySalvage','Chemistry Restoration Parts')]
seen = set()
for ruined, output, item, title in stations:
    assert native.find(f"block[@name='{ruined}']") is not None, ruined
    # Existing harvest resources are untouched. Destruction can supply one
    # component; no per-hit payouts or unreliable interaction menu required.
    patch = E.SubElement(blocks, 'append', xpath=f"/blocks/block[@name='{ruined}']")
    E.SubElement(patch, 'drop', event='Destroy', name=item, count='1', prob='0.5')
    if item not in seen:
        names.append((item,title,output,'B9A585',
            'Recoverable parts from a ruined station: 50% chance when the ruined station is destroyed. No special tool required for these parts; use a salvage tool for normal salvage resources. Consumed by an alternative rebuild recipe with about 30% fewer normal materials. Original skill unlock, crafting station, beakers and engines remain required.'))
        seen.add(item)
for name,title,icon,tint,description in names:
    item = E.SubElement(ia, 'item', name=name)
    for key,val in dict(Extends='resourceMechanicalParts', CustomIcon=icon, CustomIconTint=tint,
                        DescriptionKey=name+'Desc', EconomicValue='1', SellableToTrader='false', Stacknumber='100',
                        Weight='1', Material='MresourceYuccaFibers' if name=='grimmerCompost' else 'MmechanicalParts').items():
        E.SubElement(item, 'property', name=key, value=val)

import csv
import io
text = io.StringIO(newline='')
writer = csv.writer(text, lineterminator='\n')
writer.writerow(['Key','File','Type','UsedInMainMenu','NoTranslate','KeepLoaded','english'])
for name,title,icon,tint,description in names:
    writer.writerow([name,'items','Item','','','',title])
    writer.writerow([name+'Desc','items','Item','','','',description])
writer.writerow(['grimmerCompostBin','blocks','Block','','','','Compost Bin'])
writer.writerow(['grimmerCompostBinDesc','blocks','Block','','','','Wooden composting bin. Craft from 40 wood, 10 nails and 10 plant fibres. No fuel or tools needed. Queue 5 rotten flesh and 20 plant fibres to make one Compost over 120 seconds. Open the bin after completion to claim Seeds practice. Uses the vanilla wooden crate model.'])
writer.writerow(['grimmerCultivatedPlot','blocks','Block','','','','Cultivated Farm Plot'])
writer.writerow(['grimmerCultivatedPlotDesc','blocks','Block','','','','Compost-enriched growing bed. Unlocks at Seeds 5. Costs one Farm Plot Block, four Compost and five nitrate. Newly scheduled crop growth stages above this plot take 20% less time, including normal growth randomness. Sunlight and harvest yields stay normal. No watering needed. Build an empty plot before planting; this does not upgrade occupied beds in place. Keep Workshop installed for the speed benefit.'])
for key,value in station_text:
    writer.writerow([key,'blocks','Block','','','',value])
info = '<xml><Name value="ZZZ_GrimmerHomestead"/><DisplayName value="Workshop Farming and Restoration"/><Version value="0.1.0"/><Description value="Original native-asset composting and ruined-station restoration. Retain while saves contain these items."/><Author value="Grimmer Workshop"/></xml>'
payloads = {'Config/blocks.xml': E.tostring(blocks,encoding='unicode'),
            'Config/items.xml': E.tostring(items,encoding='unicode'),
            'Config/progression.xml': E.tostring(progression,encoding='unicode'),
            'Config/Localization.csv':text.getvalue(), 'ModInfo.xml':info}
lines = ['# BEGIN GENERATED HOMESTEAD',
         'function Write-WorkshopHomestead([string]$Root, [string]$GameDirectory) {',
         "    $directory=Join-Path $Root 'Profile\\Mods\\ZZZ_GrimmerHomestead'",
         '    Assert-WorkshopPlainPath $directory', '    $payloads=@{}']
for name,value in payloads.items():
    lines.extend([f"    $payloads['{name}']=@'",value,"'@"])
lines.extend(['    foreach($relative in $payloads.Keys) {',
              '        $destination=Join-Path $directory $relative',
              '        Assert-WorkshopPlainPath $destination; Assert-WorkshopPlainPath ($destination+\'.tmp\')',
              '        New-Item -ItemType Directory -Path (Split-Path $destination) -Force | Out-Null',
              '        [IO.File]::WriteAllText(($destination+\'.tmp\'),$payloads[$relative],(New-Object Text.UTF8Encoding($false)))',
              '        Move-Item -LiteralPath ($destination+\'.tmp\') -Destination $destination -Force',
              '    }','}', '# END GENERATED HOMESTEAD'])
path = project / 'Update-Core.ps1'
source = path.read_text(encoding='utf-8-sig')
start, end = '# BEGIN GENERATED HOMESTEAD', '# END GENERATED HOMESTEAD'
if start in source:
    before, rest = source.split(start,1)
    _, after = rest.split(end,1)
    source = before + '\n'.join(lines) + after
else:
    source += '\n' + '\n'.join(lines) + '\n'
path.write_text(source,encoding='utf-8')
print('Embedded compost bin, cultivated plot, four restored stations, five items and five ruined-station salvage patches.')
