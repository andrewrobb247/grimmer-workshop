using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
namespace GrimmerWorkshop
{
    [HarmonyPatch(typeof(BlockPlantGrowing),"addScheduledTick")]
    public static class CropGrowth
    {
        public static ulong Scale(ulong ticks){return ticks-ticks/5;}
        public static ulong Ticks(Block crop,WorldBase world,Vector3i position)
        {
            ulong ticks=crop.GetTickRate();
            string name=crop.GetBlockName();
            if(world==null || Workshop.Player()==null || name==null || !name.StartsWith("planted",StringComparison.Ordinal))return ticks;
            position.y--;
            var soil=world.GetBlock(position).Block;
            return soil!=null && soil.GetBlockName()=="grimmerCultivatedPlot" ? Scale(ticks) : ticks;
        }
        public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> source)
        {
            int matches=0;
            foreach(var instruction in source) {
                var method=instruction.operand as MethodInfo;
                if(method!=null && method.DeclaringType==typeof(Block) && method.Name=="GetTickRate") {
                    if(instruction.labels.Count!=0 || instruction.blocks.Count!=0)throw new InvalidOperationException("Unexpected crop schedule branch boundary.");
                    yield return new CodeInstruction(OpCodes.Ldarg_1);
                    yield return new CodeInstruction(OpCodes.Ldarg_2);
                    yield return new CodeInstruction(OpCodes.Call,AccessTools.Method(typeof(CropGrowth),"Ticks"));
                    matches++;
                } else yield return instruction;
            }
            if(matches!=2)throw new InvalidOperationException("Expected two native crop schedule tick calls.");
        }
    }
}
