# Publication status

0.1.35 audit fixes built and regression-tested; normal testing-channel publication pending hosted byte verification. See AUDIT-REPORT.md for findings, scope and live limitations. No separate installer required.
