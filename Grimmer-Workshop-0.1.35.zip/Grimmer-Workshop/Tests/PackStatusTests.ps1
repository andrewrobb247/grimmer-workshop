$ErrorActionPreference='Stop'
. (Join-Path (Split-Path $PSScriptRoot) 'Update-Core.ps1')
$root=Join-Path ([IO.Path]::GetTempPath()) ('pack-status-test-'+[guid]::NewGuid().ToString('N'))
$rows=@(Get-WorkshopPackStatus $root)
if($rows.Count -ne 6 -or @($rows|Where-Object Status -ne 'Not installed').Count){throw 'Absent pack status wrong'}
$pack=Join-Path $root 'Profile\Mods\Looted';New-Item -ItemType Directory -Path (Join-Path $pack 'Config\XUi_InGame') -Force|Out-Null
[IO.File]::WriteAllText((Join-Path $pack 'ModInfo.xml'),'<xml><Name value="Looted"/><Version value="3.4.9"/></xml>')
[IO.File]::WriteAllText((Join-Path $pack 'Looted.dll'),'fixture')
[IO.File]::WriteAllText((Join-Path $pack 'Config\XUi_InGame\windows.xml'),'<configs/>')
if((Get-WorkshopPackStatus $root|Where-Object Folder -eq 'Looted').Status -ne 'Recognised metadata'){throw 'Known version not detected'}
[IO.File]::WriteAllText((Join-Path $pack 'ModInfo.xml'),'<xml><Name value="Looted"/><Version value="99"/></xml>')
if((Get-WorkshopPackStatus $root|Where-Object Folder -eq 'Looted').Status -ne 'Different version - unreviewed'){throw 'Unknown version trusted'}
[IO.File]::WriteAllText((Join-Path $pack 'ModInfo.xml'),'broken')
if((Get-WorkshopPackStatus $root|Where-Object Folder -eq 'Looted').Status -ne 'Unreadable metadata'){throw 'Broken metadata trusted'}
$tokens=$null;$errors=$null
$null=[Management.Automation.Language.Parser]::ParseFile((Join-Path (Split-Path $PSScriptRoot) 'Launcher.ps1'),[ref]$tokens,[ref]$errors)
if($errors.Count){throw 'Launcher syntax invalid'}
Write-Host 'PASS: 6 absent entries, recognised/unknown/broken metadata cases and launcher syntax on Windows PowerShell 5.1.'
