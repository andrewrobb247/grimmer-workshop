param([string]$PackDirectory,[string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $GameDirectory 'Mods\0_TFP_Harmony\Mono.Cecil.dll')
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $GameDirectory '7DaysToDie_Data\Managed\Assembly-CSharp.dll'))
$types=@($a.MainModule.Types|ForEach-Object {$_.Name})
$root=Join-Path $PackDirectory 'Config'
[xml]$buffs=Get-Content (Join-Path $root 'buffs.xml') -Raw
[xml]$events=Get-Content (Join-Path $root 'gameevents.xml') -Raw
$checked=0
foreach($node in $buffs.SelectNodes('//requirement')){$name=$node.GetAttribute('name').TrimStart('!');if($types -notcontains $name){throw ('Missing buff requirement '+$name)};$checked++}
foreach($node in $buffs.SelectNodes('//triggered_effect')){$name='MinEventAction'+$node.GetAttribute('action');if($types -notcontains $name){throw ('Missing min-event action '+$name)};$checked++}
foreach($node in $events.SelectNodes('//requirement')){$name='Requirement'+$node.GetAttribute('class');if($types -notcontains $name){throw ('Missing event requirement '+$name)};$checked++}
foreach($node in $events.SelectNodes('//action')){$name='Action'+$node.GetAttribute('class');if($types -notcontains $name){throw ('Missing event action '+$name)};$checked++}
Write-Host ('PASS: '+$checked+' wildlife requirement/action type references resolve against native game.')
[xml]$spawn=Get-Content (Join-Path $GameDirectory 'Data\Config\spawning.xml') -Raw
[xml]$patch=Get-Content (Join-Path $root 'spawning.xml') -Raw
foreach($node in $patch.configs.append){if($spawn.SelectNodes($node.xpath).Count -eq 0){throw ('Unknown biome target '+$node.xpath)}}
[xml]$nb=Get-Content (Join-Path $GameDirectory 'Data\Config\buffs.xml') -Raw
foreach($node in $buffs.configs.append){if($nb.SelectNodes($node.xpath).Count -eq 0){throw ('Unknown buff target '+$node.xpath)}}
Write-Host 'PASS: all wildlife biome/buff append targets match.'
