param([string]$GuppyDirectory,[string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
$project=Split-Path $PSScriptRoot
. (Join-Path $project 'Update-Core.ps1')
$root=Join-Path ([IO.Path]::GetTempPath()) ('workshop-generated-test-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path (Join-Path $root 'Profile\Mods') -Force|Out-Null
Copy-Item -LiteralPath (Join-Path $project 'Profile\Mods\GrimmerWorkshop') -Destination (Join-Path $root 'Profile\Mods\GrimmerWorkshop') -Recurse
Write-WorkshopAttachments $root $GameDirectory
Assert-WorkshopGeneratedConfig $root
$metadata=New-Object Xml.XmlDocument;$metadata.Load((Join-Path $root 'Profile\Mods\ZZZ_GrimmerEnemies\ModInfo.xml'))
if($metadata.SelectSingleNode('/xml/Name').GetAttribute('value') -ne 'ZZZ_GrimmerEnemies'){throw 'Absent-pack companion identity invalid'}
if($GuppyDirectory) {
    $pack=Join-Path $root 'Profile\Mods\Guppy_Zombies_V3'
    New-Item -ItemType Directory -Path (Join-Path $pack 'Config') -Force|Out-Null
    Copy-Item -LiteralPath (Join-Path $GuppyDirectory 'ModInfo.xml') -Destination (Join-Path $pack 'ModInfo.xml')
    foreach($file in @('entityclasses.xml','entitygroups.xml')){Copy-Item -LiteralPath (Join-Path $GuppyDirectory ('Config\'+$file)) -Destination (Join-Path $pack ('Config\'+$file))}
    Write-WorkshopEnemyBalance $root $GameDirectory
    Assert-WorkshopGeneratedConfig $root
    $metadata.Load((Join-Path $root 'Profile\Mods\ZZZ_GrimmerEnemies\ModInfo.xml'))
    if($metadata.SelectSingleNode('/xml/Name').GetAttribute('value') -ne 'ZZZ_GrimmerEnemies'){throw 'Present-pack companion identity invalid'}
    $groups=New-Object Xml.XmlDocument;$groups.Load((Join-Path $root 'Profile\Mods\ZZZ_GrimmerEnemies\Config\entitygroups.xml'))
    if($groups.DocumentElement.ChildNodes.Count -lt 400){throw 'Expected active roster filtering'}
}
$fixture=Join-Path $root 'Profile\Mods\ZZZ_GrimmerBadFixture'
New-Item -ItemType Directory -Path $fixture|Out-Null
[IO.File]::WriteAllText((Join-Path $fixture 'ModInfo.xml'),'System.Xml.XmlDocument')
$rejected=$false
try{Assert-WorkshopGeneratedConfig $root}catch{$rejected=$true}
if(-not $rejected){throw 'Launch guard accepted a broken generated manifest'}
Write-Host 'PASS: generated XML including absent/present-pack ModInfo, active filtering and corrupt-manifest launch rejection.'
