using System;
using System.Collections.Generic;
using System.Globalization;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace GrimmerWorkshop
{
    public static class SkillScreen
    {
        sealed class Snapshot { public float Next, Practice; public string Name; public int Level; public double Cost, Growth, Activity; }
        static readonly ConditionalWeakTable<XUiController, Snapshot> snapshots = new ConditionalWeakTable<XUiController, Snapshot>();
        public static string SkillName(ProgressionValue skill)
        {
            if (skill == null) return null;
            foreach (string name in Workshop.Skills)
                if (String.Equals(name,skill.Name,StringComparison.OrdinalIgnoreCase)) return name;
            return null;
        }
        public static bool IsCrafting(ProgressionValue skill)
        {
            return SkillName(skill) != null && Workshop.Player() != null;
        }
        public static bool Changed(XUiController controller, ProgressionValue skill)
        {
            if (!IsCrafting(skill) || controller.WindowGroup == null || !controller.WindowGroup.isShowing) return false;
            var snapshot = snapshots.GetOrCreateValue(controller);
            float now = Time.realtimeSinceStartup;
            if (now < snapshot.Next && now >= snapshot.Next - 0.25f) return false;
            snapshot.Next = now + 0.25f;
            float practice = Workshop.Player().Buffs.GetCustomVar("grimmerPractice_" + SkillName(skill));
            bool changed = snapshot.Name != skill.Name || snapshot.Level != skill.Level || snapshot.Practice != practice || snapshot.Cost != Workshop.Cost || snapshot.Growth != Workshop.Growth || snapshot.Activity != Workshop.ActivitySpeed;
            snapshot.Name=skill.Name; snapshot.Level=skill.Level; snapshot.Practice=practice; snapshot.Cost=Workshop.Cost; snapshot.Growth=Workshop.Growth; snapshot.Activity=Workshop.ActivitySpeed;
            return changed;
        }
        public static string Progress(ProgressionValue skill)
        {
            return SkillScreenText.Progress(skill.Level,skill.ProgressionClass.MaxLevel,Workshop.Player().Buffs.GetCustomVar("grimmerPractice_"+SkillName(skill)),Workshop.Cost,Workshop.Growth);
        }
        public static string Fill(ProgressionValue skill)
        {
            return SkillScreenText.Ratio(skill.Level,skill.ProgressionClass.MaxLevel,Workshop.Player().Buffs.GetCustomVar("grimmerPractice_"+SkillName(skill)),Workshop.Cost,Workshop.Growth).ToString("0.####",CultureInfo.InvariantCulture);
        }
        public static string Next(ProgressionValue skill)
        {
            var milestones = new List<SkillMilestone>();
            if (skill.ProgressionClass.DisplayDataList != null) foreach (var display in skill.ProgressionClass.DisplayDataList) {
                if (!display.Enabled) continue;
                int next = display.GetNextPoints(skill.Level);
                if (next <= skill.Level) continue;
                string name = Localization.Get(display.GetName(next),false);
                milestones.Add(new SkillMilestone { Level=next, Name=name, Quality=display.HasQuality ? display.GetQualityLevel(next) : 0 });
            }
            return SkillScreenText.Next(skill.Level,skill.ProgressionClass.MaxLevel,milestones);
        }
    }

    [HarmonyPatch(typeof(XUiC_SkillCraftingInfoWindow), "GetBindingValueInternal")]
    public static class SkillDetailsBindingsPatch
    {
        public static bool Prefix(XUiC_SkillCraftingInfoWindow __instance, ref string __0, string __1, ref bool __result)
        {
            var skill = __instance.CurrentSkill;
            if (!SkillScreen.IsCrafting(skill)) {
                if (__1=="gw_practice" || __1=="gw_fill" || __1=="gw_training" || __1=="gw_next" || __1=="gw_next_full") {
                    __0=__1=="gw_fill" ? "0" : ""; __result=true; return false;
                }
                return true;
            }
            switch(__1) {
                case "gw_practice": __0=SkillScreen.Progress(skill); break;
                case "gw_fill": __0=SkillScreen.Fill(skill); break;
                case "gw_training": __0=SkillScreenText.Training(SkillScreen.SkillName(skill),skill.Level,Workshop.ActivitySpeed>0); break;
                case "gw_next": __0=SkillScreenText.Shorten(SkillScreen.Next(skill),80); break;
                case "gw_next_full": __0=SkillScreen.Next(skill); break;
                case "groupdescription": __0="Learn by crafting and relevant activities. Better-quality crafts teach more. Magazines are not required."; break;
                default: return true;
            }
            __result=true; return false;
        }
    }

    [HarmonyPatch(typeof(XUiC_SkillEntry), "GetBindingValueInternal")]
    public static class SkillRowBindingsPatch
    {
        public static void Postfix(XUiC_SkillEntry __instance, ref string __0, string __1, ref bool __result)
        {
            var skill=__instance.Skill;
            if (!SkillScreen.IsCrafting(skill)) return;
            if (__1=="skillpercentthislevel") { __0=SkillScreen.Fill(skill); __result=true; }
            if (__1=="skillpercentshouldshow") { __0="true"; __result=true; }
        }
    }

    [HarmonyPatch(typeof(XUiC_SkillCraftingInfoWindow), "Update")]
    public static class SkillDetailsRefreshPatch
    {
        public static void Prefix(XUiC_SkillCraftingInfoWindow __instance)
        {
            if (SkillScreen.Changed(__instance,__instance.CurrentSkill)) __instance.IsDirty=true;
        }
    }
    [HarmonyPatch(typeof(XUiC_SkillEntry), "Update")]
    public static class SkillRowsRefreshPatch
    {
        public static void Prefix(XUiC_SkillEntry __instance)
        {
            if (SkillScreen.Changed(__instance,__instance.Skill)) __instance.IsDirty=true;
        }
    }
}
