# 0.1.22 release candidate

578 old routes unchanged; 52 new routes and 15 Construction tag patches. 18 exact non-wildcard exclusions checked. Bulk output and vehicle awards, native forge completion-count flow, old tag preservation and lockpick bundle normalization checked. 2,627 regressions, 34 layout checks and game compilation pass. Live manufacturing checks pending.
