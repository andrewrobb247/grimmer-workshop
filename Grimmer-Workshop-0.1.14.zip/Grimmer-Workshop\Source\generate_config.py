"""Build original practice rules from the installed vanilla progression data."""
import csv
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

game, destination = map(Path, sys.argv[1:])
config = game / 'Data' / 'Config'
progression = ET.parse(config / 'progression.xml').getroot()
recipes = ET.parse(config / 'recipes.xml').getroot()
skills = progression.findall('.//crafting_skill')
skill_names = {s.get('name') for s in skills}
recipe_by_name = defaultdict(list)
for recipe in recipes.findall('recipe'):
    if recipe.find('wildcard_forge_category') is None:
        recipe_by_name[recipe.get('name')].append(recipe)

rule_root = ET.Element('practiceRules')
rules = {}
coverage = defaultdict(list)

def add_rule(item, skill, unlock=1, until=20, cap=100, credit=10):
    if item not in recipe_by_name:
        raise ValueError(f'Missing recipe {item}')
    output = min(int(r.get('count', '1')) for r in recipe_by_name[item])
    rules[item, skill] = dict(item=item, skill=skill, output=str(output), unlock=str(unlock), until=str(until), cap=str(cap), credit=str(credit))

for skill in skills:
    name = skill.get('name')
    maximum = int(skill.get('max_level'))
    unlocks = {}
    for effect in skill.findall(".//passive_effect[@name='RecipeTagUnlocked']"):
        level = int(effect.get('level').split(',')[0])
        for item in effect.get('tags', '').split(','):
            if item in recipe_by_name:
                unlocks[item] = min(level, unlocks.get(item, level))
    levels = sorted(set(unlocks.values()))
    for item, level in unlocks.items():
        next_level = next((n for n in levels if n > level), maximum + 1)
        add_rule(item, name, level, next_level + 3, maximum)

# Recipes already tagged with a crafting skill include primitive tools that have
# no UnlockedBy property on their item definitions.
for item, item_recipes in recipe_by_name.items():
    tags = set(','.join(r.get('tags', '') for r in item_recipes).split(','))
    for skill in tags & skill_names:
        if not any(existing_item == item for existing_item, _ in rules):
            maximum = int(next(s for s in skills if s.get('name') == skill).get('max_level'))
            add_rule(item, skill, 1, 15, maximum)

# Bootstrap paths use practical consumables and preparation recipes. The cap
# directs players onto the category's unlocked equipment once it becomes available.
bootstrap = [
    ('resourceCloth', 'craftingBackpack', 5, 5),
    ('resourceGunPowder', 'craftingExplosives', 2, 2),
    ('foodCharredMeat', 'craftingFood', 2, 10),
    ('medicalBandage', 'craftingMedical', 5, 8),
    ('resourceDuctTape', 'craftingVehicles', 5, 6),
    ('resourceRepairKit', 'craftingRepairTools', 4, 10),
    ('resourceMechanicalParts', 'craftingSalvageTools', 4, 8),
    ('resourceElectricParts', 'craftingElectrician', 25, 8),
    ('trapSpikesWoodDmg0', 'craftingTraps', 25, 5),
    ('farmPlotBlockVariantHelper', 'craftingSeeds', 2, 10),
    ('meleeWpnBatonT0PipeBaton', 'craftingRobotics', 11, 10),
    ('campfire', 'craftingWorkstations', 4, 10),
]

# Add workshop assembly recipes for mechanical and electrical components.
recipe_patch = ET.Element('configs')
append = ET.SubElement(recipe_patch, 'append', xpath='/recipes')
for item, ingredients in [
    ('resourceMechanicalParts', [('resourceForgedIron', 2), ('resourceScrapPolymers', 2)]),
    ('resourceElectricParts', [('resourceScrapIron', 5), ('resourceScrapPolymers', 3)])
]:
    recipe = ET.SubElement(append, 'recipe', name=item, count='1', craft_time='12', tags='grimmerWorkshopAssembly', always_unlocked='true')
    for ingredient, count in ingredients:
        ET.SubElement(recipe, 'ingredient', name=ingredient, count=str(count))
    recipe_by_name[item].append(recipe)

for item, skill, cap, credit in bootstrap:
    if skill in skill_names:
        add_rule(item, skill, 1, cap, cap, credit)

# Fuel is a rapid two-unit refining batch, not an equipment assembly.
# Keep it useful for practice without making one shale outperform a chassis.
if ('ammoGasCan', 'craftingVehicles') in rules:
    rules['ammoGasCan', 'craftingVehicles']['credit'] = '0.1'

# Normal cooking also teaches workstation fundamentals up to the workbench.
for item, skill in list(rules):
    if skill == 'craftingFood':
        add_rule(item, 'craftingWorkstations', 1, 10, 10, 5)

for key in sorted(rules):
    rule = rules[key]
    ET.SubElement(rule_root, 'rule', **rule)
    coverage[rule['skill']].append(rule)

def write_xml(path, root):
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.indent(root, space='  ')
    ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)

write_xml(destination / 'PracticeRules.xml', rule_root)
write_xml(destination / 'Config' / 'recipes.xml', recipe_patch)

# Keep magazines as loot and merchant goods. Their skill gain is suppressed in
# the explicit skill-magazine items, including their duplicate-point proc.
items = ET.parse(config / 'items.xml').getroot()
item_patch = ET.Element('configs')
magazines = []
for item in items.findall('item'):
    unlock = item.find("property[@name='Unlocks']")
    if not item.get('name', '').endswith('SkillMagazine') or unlock is None or unlock.get('value') not in skill_names:
        continue
    magazines.append(item.get('name'))
    ET.SubElement(item_patch, 'remove', xpath="/items/item[@name='%s']//triggered_effect[@action='AddProgressionLevel']" % item.get('name'))
write_xml(destination / 'Config' / 'items.xml', item_patch)

missing = skill_names - coverage.keys()
if missing:
    raise ValueError(f'Skills without any practice route: {missing}')
unstarted = [s for s in skill_names if not any(int(r['unlock']) == 1 for r in coverage[s])]
if unstarted:
    raise ValueError(f'Skills without a level-one practice route: {unstarted}')

# Check every transition, not just the existence of a level-one recipe. A route
# must be hand-unlocked or explicitly unlocked by the relevant crafting skill.
audit = ['# Crafting progression audit', '',
         'Generated from installed V3.4 b10 data. All crafting-level transitions have a magazine-free recipe route. Ingredients, loot luck and workstation construction still need real play balancing.', '',
         '| Crafting skill | Maximum | Starting recipe | Starting station | Levels checked |',
         '| --- | --- | --- | --- | --- |']
checked = 0
for skill in sorted(skills, key=lambda s: s.get('name')):
    name, maximum = skill.get('name'), int(skill.get('max_level'))
    explicit = {tag: int(effect.get('level').split(',')[0])
                for effect in skill.findall(".//passive_effect[@name='RecipeTagUnlocked']")
                for tag in effect.get('tags', '').split(',')}
    available = []
    for level in range(1, maximum):
        available = [r for r in coverage[name]
                     if int(r['unlock']) <= level < int(r['cap'])
                     and (explicit.get(r['item'], maximum + 1) <= level
                          or any(x.get('always_unlocked') == 'true' or 'learnable' not in x.get('tags', '').split(',')
                                 for x in recipe_by_name[r['item']]))]
        if not available:
            raise ValueError(f'No magazine-free recipe route for {name} at level {level}')
        if level == 1:
            start = min(available, key=lambda r: (int(r['cap']), r['item']))
            stations = sorted({x.get('craft_area', 'backpack') for x in recipe_by_name[start['item']]})
        checked += 1
    audit.append(f"| {name[8:]} | {maximum} | {start['item']} | {', '.join(stations)} | 1–{maximum - 1} |")
audit += ['', f'Checked {checked} level transitions across {len(skills)} crafting skills. No progression-gap failures.', '',
          'Early workstation path: campfires to Workstations 4 unlock the forge; cooking also trains Workstations to 10 for the workbench. Mechanical parts assembly requires forged iron from that forge. Electrical parts assembly requires scrap iron and polymers. Both assembly recipes are always unlocked.']
(Path(__file__).parent / 'PROGRESSION-AUDIT.md').write_text('\n'.join(audit) + '\n', encoding='utf-8')

with (destination / 'CRAFTING-ROUTES.csv').open('w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Skill', 'Item', 'Unlock level', 'Full credit through level', 'Training cap', 'Practice per recipe batch'])
    for skill in sorted(coverage):
        for rule in coverage[skill]:
            writer.writerow([skill, rule['item'], rule['unlock'], rule['until'], rule['cap'], rule['credit']])
print(f'Generated {len(rules)} practice routes across {len(coverage)} crafting skills and {len(magazines)} magazine patches.')
