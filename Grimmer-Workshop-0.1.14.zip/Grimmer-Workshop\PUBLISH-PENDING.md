# Publication complete

0.1.13 published 18 November 2026. All 20 runtime files and the full archive verified. Testing channel matches prepared manifest. No publication steps remain.
