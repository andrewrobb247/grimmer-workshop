using System;
using System.Collections.Generic;
namespace HarmonyLib { public class HarmonyPatch : Attribute { public HarmonyPatch(Type t,string m) {} } }
public class XUiController {
    public event Action<XUiController,int> OnPress;
    public void Press(int button) { if(OnPress!=null) OnPress(this,button); }
}
public class XUiC_BackpackWindow : XUiController {
    public Dictionary<string,XUiController> Children=new Dictionary<string,XUiController>();
    public XUiController GetChildById(string id) { return Children.ContainsKey(id)?Children[id]:null; }
}
public static class GameManager { public static string Message; public static void ShowTooltip(object p,string m,bool a,bool b,int c) { Message=m; } }
public static class Log { public static void Error(string m) {} }
namespace GrimmerWorkshop {
    public static class Workshop { public static object Current=new object(); public static object Player() { return Current; } }
    public static class Storage {
        public static int Calls,Count=7; public static bool Refill,Fail;
        public static int Transfer(bool refill) { Calls++; Refill=refill; if(Fail)throw new Exception("test"); return Count; }
    }
    public static class StorageButtonTests {
        static int checks;
        static void Check(bool condition,string message) { checks++; if(!condition)throw new Exception(message); }
        public static void Main() {
            StorageButtons.Postfix(new XUiC_BackpackWindow());
            var window=new XUiC_BackpackWindow();
            var deposit=new XUiController(); var refill=new XUiController();
            window.Children["grimmerDepositNearby"]=deposit; window.Children["grimmerRefillNearby"]=refill;
            StorageButtons.Postfix(window); StorageButtons.Postfix(window);
            deposit.Press(-1); Check(Storage.Calls==1&&!Storage.Refill,"Deposit runs once after repeated Init");
            Check(GameManager.Message.Contains("Deposited 7"),"Deposit feedback");
            refill.Press(-1); Check(Storage.Calls==2&&Storage.Refill,"Refill calls correct operation");
            Check(GameManager.Message.Contains("Refilled 7"),"Refill feedback");
            deposit.Press(-2); Check(Storage.Calls==2,"Right click does not transfer");
            deposit.Press(0); Check(Storage.Calls==2,"Unity-style zero is not an XUi left-click");
            Workshop.Current=null; refill.Press(-1); Check(Storage.Calls==2,"No world does not transfer"); Workshop.Current=new object();
            Storage.Count=0; deposit.Press(-1); Check(GameManager.Message.Contains("Nothing deposited"),"No-op deposit explanation");
            refill.Press(-1); Check(GameManager.Message.Contains("Nothing refilled"),"No-op refill explanation");
            Storage.Fail=true; deposit.Press(-1); Check(GameManager.Message.Contains("failed"),"Exception contained and reported");
            Console.WriteLine("Passed "+checks+" storage button checks.");
        }
    }
}

