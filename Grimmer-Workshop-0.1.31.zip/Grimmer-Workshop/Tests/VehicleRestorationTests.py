"""Check the engine recipe, save-safe item identity and unchanged old routes."""
import csv
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

game, current, previous, fixture = map(Path, sys.argv[1:])
rules = { (r.get('item'), r.get('skill')): r.attrib for r in ET.parse(current/'PracticeRules.xml').getroot() }
old = { (r.get('item'), r.get('skill')): r.attrib for r in ET.parse(previous/'PracticeRules.xml').getroot() }
assert len(old) == 632 and all(rules.get(k) == v for k, v in old.items()), 'Existing practice routes changed'
assert set(rules)-set(old) == {('smallEngine', 'craftingVehicles')}
assert rules['smallEngine','craftingVehicles']['credit'] == '12'
assert rules['smallEngine','craftingVehicles']['until'] == '40'
assert rules['smallEngine','craftingVehicles']['cap'] == '100'
recipes = ET.parse(current/'Config/recipes.xml').getroot()
engine = recipes.find(".//recipe[@name='smallEngine']")
assert engine is not None and engine.get('craft_area') == 'workbench'
assert engine.get('always_unlocked') == 'true' and engine.get('craft_time') == '120'
assert engine.get('count') == '1'
assert {i.get('name'):int(i.get('count')) for i in engine.findall('ingredient')} == {
    'grimmerRecoveredEngine':1,'resourceForgedIron':10,'resourceMechanicalParts':12,'resourceOil':4,'resourceDuctTape':2}
original = ET.parse(previous/'Config/recipes.xml').getroot()
def entries(root):
    result = set()
    for r in root.findall('.//recipe'):
        if r.get('name') == 'smallEngine':
            continue
        r.tail = None  # Ignore indentation after the former final recipe.
        result.add(ET.tostring(r))
    return result
assert entries(recipes) == entries(original), 'Previous custom recipes changed'
parts = fixture/'Profile/Mods/ZZZ_GrimmerVehicleParts'
item = ET.parse(parts/'Config/items.xml').getroot().find(".//item[@name='grimmerRecoveredEngine']")
properties = {p.get('name'):p.get('value') for p in item.findall('property')}
assert properties['Extends'] == 'resourceMechanicalParts', 'Damaged engine must not function as native engine'
assert properties['CustomIcon'] == 'smallEngine' and properties['Stacknumber'] == '1'
assert properties['DescriptionKey'] == 'grimmerRecoveredEngineDesc'
with (parts/'Config/Localization.csv').open(newline='',encoding='utf-8-sig') as f:
    texts = {r['Key']:r['english'] for r in csv.DictReader(f)}
assert texts['grimmerRecoveredEngine'] == 'Damaged Engine Assembly'
assert 'workbench' in texts['grimmerRecoveredEngineDesc'] and 'Vehicles' in texts['grimmerRecoveredEngineDesc']
vanilla = {i.get('name') for i in ET.parse(game/'Data/Config/items.xml').getroot()}
assert all(i.get('name') in vanilla or i.get('name') == 'grimmerRecoveredEngine' for i in engine.findall('ingredient'))
assert not any(r.get('name') == 'grimmerRecoveredEngine' for r in recipes.findall('.//recipe')), 'No renewable damaged-engine craft loop'
print('PASS: restoration recipe, localization, damaged item identity and all 632 existing routes/recipes preserved.')
