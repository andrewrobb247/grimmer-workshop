import sys,xml.etree.ElementTree as E
from pathlib import Path
mod,baseline,game=map(Path,sys.argv[1:])
def load(p):return {(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(p/'PracticeRules.xml').getroot()}
new,old=load(mod),load(baseline)
assert all(new[k]==v for k,v in old.items()),'Existing practice route changed'
added=set(new)-set(old)
assert len(added)==57
assert all(item.startswith('ammo') for item,_ in added)
assert all(new[k]['output']=='1' and new[k]['unlock']=='1' for k in added)
assert new['ammo9mmBulletBall','craftingHandguns']['credit']=='0.02'
assert new['ammo762mmBulletBall','craftingRifles']['credit']=='0.01'
assert new['ammo762mmBulletBall','craftingMachineGuns']['credit']=='0.01'
assert new['ammoArrowStone','craftingBows']['credit']=='0.05'
assert new['ammoDartIron','craftingTraps']['credit']=='0.01'
items={i.get('name'):i for i in E.parse(game/'Data/Config/items.xml').getroot()}
def action(name,prop):
 item=items[name];value=item.find("property[@class='Action0']/property[@name='%s']"%prop)
 if value is not None:return value.get('value')
 parent=item.find("property[@name='Extends']")
 return action(parent.get('value'),prop) if parent is not None else None
bundles={item for item,skill in added if item.startswith('ammoBundle')}
for name in bundles:
 assert action(name,'Class')=='OpenBundle'
 output=action(name,'Create_item');count=int(action(name,'Create_item_count'))
 for item,skill in added:
  if item!=name:continue
  r=new[item,skill];direct=new[output,skill]
  assert int(r['units'])==count
  assert r['credit']==direct['credit'] and r['until']==direct['until'] and r['cap']==direct['cap']
assert new['ammoBundleArrowExploding','craftingBows']['units']=='75'
assert new['ammoBundleJunkTurretRegular','craftingRobotics']['units']=='1000'
assert new['ammoBundle9mmBulletBall','craftingHandguns']['units']=='100'
assert not any(item.endswith('Bundle') and not item.startswith('ammoBundle') for item,_ in added)
# No recipe gates, ingredients, outputs or manufacturing actions are changed.
assert (mod/'Config/recipes.xml').read_bytes()==(baseline/'Config/recipes.xml').read_bytes()
source=(mod.parents[2]/'Source/Workshop.cs').read_text(encoding='utf8')
assert 'PracticeMath.NormalizedOutput(stack.count, rule.Units)' in source
assert 'Units = (int?)entry.Attribute("units") ?? 1' in source
print(f'Passed ammunition audit: {len(old)} existing routes unchanged; {len(added)} new routes; {len(bundles)} inherited bundle counts and per-projectile equivalence checked. Recipe definitions unchanged.')
