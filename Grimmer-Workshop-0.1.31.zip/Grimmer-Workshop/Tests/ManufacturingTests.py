import sys,xml.etree.ElementTree as E
from pathlib import Path
from collections import Counter
mod,baseline,game=map(Path,sys.argv[1:])
def load(p):return {(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(p/'PracticeRules.xml').getroot()}
new,old=load(mod),load(baseline)
assert all(new[k]==v for k,v in old.items()),'Existing route changed'
added=set(new)-set(old)
assert len(added)==52
samples={'cntWallSafe_Player':'craftingConstruction','cntDeskSafe_Player':'craftingConstruction','cntSteelWallCabinetSecure':'craftingConstruction','candle':'craftingConstruction','meleeToolPaintTool':'craftingConstruction','resourceNail':'craftingConstruction','resourcePaper':'craftingWorkstations','resourceGlue':'craftingWorkstations','resourceForgedIron':'craftingWorkstations','toolCookingPot':'craftingWorkstations','resourceArmorCraftingKit':'craftingArmor','biomeWeatherItem1':'craftingArmor','meleeToolWireTool':'craftingElectrician','mineCandyTin':'craftingTraps','trapSpikesIronDmg0':'craftingTraps','plantedGraceCorn1':'craftingSeeds','thrownAmmoMolotovCocktail':'craftingExplosives','vehicleMotorcyclePlaceable':'craftingVehicles'}
for item,skill in samples.items():assert (item,skill) in added,(item,skill)
for item,credit in [('resourcePaper',.02),('resourceNail',.005),('resourceForgedIron',.05),('resourceForgedSteel',.1),('resourceGlue',.5)]:
 r=new[item,samples.get(item,'craftingWorkstations')]
 assert r['output']=='1' and float(r['credit'])==credit
for item,credit in [('vehicleBicyclePlaceable',12),('vehicleMinibikePlaceable',20),('vehicleMotorcyclePlaceable',30),('vehicleTruck4x4Placeable',40),('vehicleGyrocopterPlaceable',50)]:
 assert float(new[item,'craftingVehicles']['credit'])==credit
pick=new['resourceLockPick','craftingWorkstations'];bundle=new['resourceLockPickBundle','craftingWorkstations']
assert bundle['units']=='50' and bundle['output']=='1'
assert all(bundle[k]==pick[k] for k in ['unlock','until','cap','credit'])
recipes=E.parse(game/'Data/Config/recipes.xml').getroot()
allowed_exclusions={'resourceClayLump','resourceRockSmall','resourceScrapBrass','resourceScrapIron','resourceScrapLead','resourceRockSmallBundle','resourceWoodBundle','resourceScrapIronBundle','resourceOilShaleBundle','resourcePotassiumNitratePowderBundle','resourceLeadBundle','resourceScrapBrassBundle','resourceCoalBundle','foodRawMeatBundle','terrDestroyedStone','terrDirt','terrTopSoil','plantedtreeGrassSeed1'}
missing={r.get('name') for r in recipes.findall('recipe') if r.find('wildcard_forge_category') is None and not any(i==r.get('name') for i,s in new)}
assert missing==allowed_exclusions,(missing^allowed_exclusions)
for item,skill in added:
 assert item not in allowed_exclusions
 assert all(r.get('craft_exp_gain')!='0' for r in recipes.findall('recipe') if r.get('name')==item and r.find('wildcard_forge_category') is None)
# Existing managed recipe additions and prior tags are preserved. New patches
# only add the Construction tag to the new construction recipes.
patch=E.parse(mod/'Config/recipes.xml').getroot();previous=E.parse(baseline/'Config/recipes.xml').getroot()
def key(op):return (op.tag,tuple(sorted(op.attrib.items())))
by_key={key(op):op for op in patch}
for op in previous:assert key(op) in by_key and E.tostring(op).strip()==E.tostring(by_key[key(op)]).strip()
newops=[op for op in patch if key(op) not in {key(x) for x in previous}]
for op in newops:
 assert op.tag=='setattribute' and op.get('name')=='tags'
 path=op.get('xpath');item=path.split("'")[1];index=int(path.rsplit('[',1)[1][:-1])-1
 assert (item,'craftingConstruction') in added
 rows=[r for r in recipes.findall('recipe') if r.get('name')==item and r.find('wildcard_forge_category') is None]
 tags=set(rows[index].get('tags','').split(','))-{''}
 assert set(op.text.split(','))==tags|{'grimmerConstruction'}
print(f'Passed fixture/manufacturing audit: {len(old)} old routes unchanged, {len(added)} new routes, {len(newops)} new tag patches; exactly {len(missing)} intentional exclusions. Bulk-unit and vehicle awards checked.')
print('New route categories:',dict(Counter(s for _,s in added)))
