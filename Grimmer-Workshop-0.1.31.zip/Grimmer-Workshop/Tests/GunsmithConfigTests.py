"""Compare generated specialist recipes to actual native definitions."""
import csv
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

game,current,previous,fixture=map(Path,sys.argv[1:])
new_rules={(r.get('item'),r.get('skill')):r.attrib for r in ET.parse(current/'PracticeRules.xml').getroot()}
old_rules={(r.get('item'),r.get('skill')):r.attrib for r in ET.parse(previous/'PracticeRules.xml').getroot()}
assert len(old_rules)==633 and all(new_rules[k]==v for k,v in old_rules.items())
assert set(new_rules)-set(old_rules)=={('grimmerGunsmithBench','craftingWorkstations')}
assert new_rules['grimmerGunsmithBench','craftingWorkstations']['unlock']=='20'
mod=fixture/'Profile/Mods/ZZZ_GrimmerGunsmith'
bench=ET.parse(mod/'Config/blocks.xml').getroot().find('.//block')
assert bench.get('name')=='grimmerGunsmithBench'
props={p.get('name'):p.get('value') for p in bench.findall('property') if p.get('name')}
assert props['Class']=='Workstation' and props['WorkstationWindow']=='workstation_workbench'
assert props['UnlockedBy']=='craftingWorkstations'
assert bench.find("property[@class='Workstation']/property[@name='CraftingAreaRecipes']").get('value')=='grimmerGunsmithBench'
native_bench=ET.parse(game/'Data/Config/blocks.xml').getroot().find("block[@name='workbench']")
assert props['Model']==native_bench.find("property[@name='Model']").get('value')
assert props['MultiBlockDim']==native_bench.find("property[@name='MultiBlockDim']").get('value')
assert [ET.tostring(n).strip() for n in bench.findall('drop')]==[ET.tostring(n).strip() for n in native_bench.findall('drop')]
effect=ET.parse(mod/'Config/progression.xml').getroot().find('.//passive_effect')
assert effect.attrib==dict(name='RecipeTagUnlocked',operation='base_set',level='20,75',value='1',tags='grimmerGunsmithBench')
native=ET.parse(game/'Data/Config/recipes.xml').getroot()
custom=ET.parse(current/'Config/recipes.xml').getroot()
sources=list(native.findall('recipe'))+list(custom.findall('.//recipe'))
copies=ET.parse(mod/'Config/recipes.xml').getroot().findall('.//recipe')
def signature(node):
    return node.tag,tuple(sorted(node.attrib.items())),tuple(signature(n) for n in node)
assert len(copies)>50
names=set()
for copy in copies:
    assert copy.get('craft_area')=='grimmerGunsmithBench'
    name=copy.get('name');assert name not in names;names.add(name)
    copy.set('craft_area','workbench')
    assert any(signature(copy)==signature(s) for s in sources), 'Changed ingredients, output, requirements, tags or effects: '+name
assert {'gunHandgunT1Pistol','ammo9mmBulletBall','ammoBundle9mmBulletBall','grimmerLightGrip','grimmerPowerGrip'}<=names
assert not {'smallEngine','grimmerGunsmithBench','workbench','gunBotT3JunkDrone','grimmerLightToolGrip'}&names
recipe=custom.find(".//recipe[@name='grimmerGunsmithBench']")
assert recipe.get('craft_area')=='workbench' and 'learnable' in recipe.get('tags').split(',')
assert recipe.get('always_unlocked') is None
assert {n.get('name'):n.get('count') for n in recipe.findall('ingredient')}=={'workbench':'1','resourceForgedIron':'10','resourceMechanicalParts':'10','resourceDuctTape':'4'}
old_recipes=ET.parse(previous/'Config/recipes.xml').getroot()
assert {signature(n) for n in custom.findall('.//recipe') if n.get('name')!='grimmerGunsmithBench'}=={signature(n) for n in old_recipes.findall('.//recipe')}
with (mod/'Config/Localization.csv').open(newline='',encoding='utf-8-sig') as f:
    texts={r['Key']:r['english'] for r in csv.DictReader(f)}
assert texts['grimmerGunsmithBench']=='Gunsmith Bench' and '15%' in texts['grimmerGunsmithBenchDesc']
print(f'PASS: {len(copies)} specialist recipe variants match source costs/outputs/unlocks/quality effects; all 633 previous routes preserved; bench registration, unlock, costs and localization checked.')
