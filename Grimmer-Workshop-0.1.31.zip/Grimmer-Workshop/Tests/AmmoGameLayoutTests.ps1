$ErrorActionPreference='Stop'
Add-Type -Path 'C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die\Mods\0_TFP_Harmony\Mono.Cecil.dll'
$a=[Mono.Cecil.AssemblyDefinition]::ReadAssembly('C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die\7DaysToDie_Data\Managed\Assembly-CSharp.dll')
try {
 $type=$a.MainModule.Types | Where-Object Name -eq 'ItemActionOpenBundle'
 if(-not $type){throw 'Bundle action class changed'}
 foreach($name in @('ExecuteAction','ExecuteInstantAction')) {
  $m=$type.Methods | Where-Object Name -eq $name
  if(-not $m -or -not $m.HasBody){throw ('Missing bundle action: '+$name)}
  if(@($m.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -eq 'CraftedItem' }).Count){throw 'Opening bundles now fires crafting events; duplicate-credit guard needed'}
 }
 $instant=$type.Methods | Where-Object Name -eq 'ExecuteInstantAction'
 if(-not @($instant.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -eq 'AddItem' }).Count){throw 'Bundle output delivery changed'}
 Write-Host 'Passed native bundle action checks: both opening paths exist, deliver items, and do not fire CraftedItem.'
} finally {$a.Dispose()}
