import sys,xml.etree.ElementTree as E
from pathlib import Path
mod,baseline,game=map(Path,sys.argv[1:])
def load(p):return {(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(p/'PracticeRules.xml').getroot()}
new,old=load(mod),load(baseline)
assert all(new[k]==v for k,v in old.items()),'Existing route changed'
added=set(new)-set(old)
assert len(added)==75
recipes=E.parse(game/'Data/Config/recipes.xml').getroot()
expected={r.get('name') for r in recipes.findall('recipe') if r.get('name').startswith('mod') and r.find('wildcard_forge_category') is None}
assert {item for item,skill in added}==expected
assert all(sum(1 for i,s in added if i==item)==1 for item in expected),'Attachment awards duplicated across skill categories'
checks={'modArmorStoragePocket':'craftingBackpack','modArmorQuadStoragePocket':'craftingBackpack','modArmorPlatingBasic':'craftingArmor','modArmorAdvancedMuffledConnectors':'craftingArmor','modArmorHelmetLight':'craftingElectrician','modGunLaserSight':'craftingElectrician','modGunBowPolymerString':'craftingBows','modGunChoke':'craftingShotguns','modShotgunSawedOffBarrel':'craftingShotguns','modMeleeClubMetalSpikes':'craftingClubs','modMeleeWoodSplitter':'craftingHarvestingTools','modFuelTankLarge':'craftingHarvestingTools','modMeleeStunBatonRepulsor':'craftingRobotics','modRoboticDroneMedicMod':'craftingRobotics','modVehicleStorage':'craftingVehicles','modMeleeErgonomicGrip':'craftingWorkstations','modGunScopeLarge':'craftingWorkstations','modArmorCigar':'craftingWorkstations'}
for item,skill in checks.items():assert (item,skill) in added,(item,skill)
mods={m.get('name'):m for m in E.parse(game/'Data/Config/item_modifiers.xml').getroot().findall('item_modifier')}
for item,skill in added:
 assert item in mods
 r=new[item,skill]
 assert r['output']=='1' and r['unlock']=='1' and r.get('units','1')=='1'
 assert r['cap']==('75' if skill in ('craftingBows','craftingClubs','craftingWorkstations') else '100')
 assert 0<float(r['credit'])<=12 and int(r['until']) in (25,40)
assert new['modArmorStoragePocket','craftingBackpack']['credit']=='4'
assert new['modArmorQuadStoragePocket','craftingBackpack']['credit']=='12'
assert new['modGunScopeLarge','craftingWorkstations']['credit']=='8'
assert new['modArmorCigar','craftingWorkstations']['credit']=='2'
assert (mod/'Config/recipes.xml').read_bytes()==(baseline/'Config/recipes.xml').read_bytes(),'Recipe requirements changed'
# Original custom grips retain their existing routes and definitions.
assert new['grimmerLightGrip','craftingWorkstations']==old['grimmerLightGrip','craftingWorkstations']
assert new['grimmerPowerGrip','craftingWorkstations']==old['grimmerPowerGrip','craftingWorkstations']
print(f'Passed attachment-practice audit: {len(old)} previous routes unchanged; all {len(added)} attachment recipes train exactly one skill; caps, award tiers and recipe preservation checked.')
