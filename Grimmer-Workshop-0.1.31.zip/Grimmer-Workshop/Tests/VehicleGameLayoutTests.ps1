param([string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $GameDirectory 'Mods\0_TFP_Harmony\Mono.Cecil.dll')
$assembly=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $GameDirectory '7DaysToDie_Data\Managed\Assembly-CSharp.dll'))
$radial=($assembly.MainModule.Types | Where-Object Name -eq 'XUiC_Radial').Methods | Where-Object Name -eq 'handleBlockCommand'
$instructions=@($radial.Body.Instructions)
$dispatch=$false
for($index=0;$index -lt $instructions.Count-1;$index++) {
    if([string]$instructions[$index].Operand -eq 'System.String BlockActivationCommand::text') {
        foreach($following in $instructions[($index+1)..([Math]::Min($index+20,$instructions.Count-1))]) {
            if([string]$following.Operand -match 'Block::OnBlockActivated'){ $dispatch=$true }
        }
    }
}
if(-not $dispatch){throw 'Native radial command text dispatch changed.'}
$composite=$assembly.MainModule.Types | Where-Object Name -eq 'BlockCompositeTileEntity'
if(-not ($composite.Methods | Where-Object { $_.Name -eq 'TryGetParentBlockAndTileEntity' -and $_.Parameters[0].ParameterType.FullName -eq 'Vector3i&' })) {throw 'Native parent-resolution hook missing.'}
[xml]$blocks=Get-Content -Raw (Join-Path $GameDirectory 'Data\Config\blocks.xml')
$sedan=$blocks.blocks.block | Where-Object name -eq 'cntCar03SedanDamage0Master'
if(-not ($sedan.property | Where-Object { $_.name -eq 'Class' -and $_.value -eq 'CompositeTileEntity' })) {throw 'Sedan no longer composite.'}
if(-not ($sedan.property.property | Where-Object class -eq 'TEFeatureStorage')) {throw 'Sedan storage feature missing.'}
[xml]$items=Get-Content -Raw (Join-Path $GameDirectory 'Data\Config\items.xml')
foreach($part in @('resourceMechanicalParts','resourceElectricParts','smallEngine','carBattery','vehicleWheels')) {
    if(-not ($items.items.item | Where-Object name -eq $part)){throw "Missing part: $part"}
}
Write-Host 'Passed 9 installed-game vehicle layout and item checks.'
