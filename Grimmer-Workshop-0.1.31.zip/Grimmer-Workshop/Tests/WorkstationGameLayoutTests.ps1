param([string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $GameDirectory 'Mods\0_TFP_Harmony\Mono.Cecil.dll')
$assembly=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $GameDirectory '7DaysToDie_Data\Managed\Assembly-CSharp.dll'))
$station=$assembly.MainModule.Types|Where-Object Name -eq 'TileEntityWorkstation'
$method=$station.Methods|Where-Object Name -eq 'AddCraftComplete'
$il=$method.Body.Instructions;$matches=0
for($n=0;$n -lt $il.Count-3;$n++) {
 if([string]$il[$n].Operand -eq 'System.Int32 ItemValue::GetItemId()' -and $il[$n+1].OpCode.Name -eq 'ldarg.2' -and [string]$il[$n+2].Operand -eq 'System.Int32 ItemValue::GetItemId()' -and $il[$n+3].OpCode.Name -in @('bne.un','bne.un.s')) {$matches++}
}
if($matches -ne 1){throw 'Actual workstation layout no longer has exactly one supported comparison.'}
$claim=$station.Methods|Where-Object Name -eq 'CheckForCraftComplete'
if(-not ($claim.Body.Instructions|Where-Object{[string]$_.Operand -eq 'System.Void EntityPlayerLocal::GiveExp(CraftCompleteData)'})){throw 'Claim event route changed.'}
if(-not ($claim.Body.Instructions|Where-Object{[string]$_.Operand -match 'RemoveAt'})){throw 'Claim no longer removes completion records.'}
$open=($assembly.MainModule.Types|Where-Object Name -eq 'XUiC_WorkstationWindowGroup').Methods|Where-Object Name -eq 'OnOpen'
if(-not ($open.Body.Instructions|Where-Object{[string]$_.Operand -match 'TileEntityWorkstation::CheckForCraftComplete'})){throw 'Opening station no longer claims completions.'}
Write-Host 'Passed 4 installed-game workstation layout checks: quality comparison, completion delivery, claim removal, station-open trigger.'
