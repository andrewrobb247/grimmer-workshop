using System;
using System.Collections.Generic;
using GrimmerWorkshop;
namespace HarmonyLib { public class HarmonyPatch:Attribute {public HarmonyPatch(Type t,string n){}} }
public class XUiC_RecipeList {public string Workstation;}
public class Recipe {public string craftingArea;public int itemValueType;}
namespace GrimmerWorkshop {public static class Workshop {public static object player=new object();public static object Player(){return player;}}}
class RecipeVariantsTests {
    static int checks;
    static void Check(bool pass,string text){checks++;if(!pass)throw new Exception(text);}
    static void Main(){
        var gun=new Recipe{itemValueType=1,craftingArea="workbench"};var specialist=new Recipe{itemValueType=1,craftingArea="grimmerGunsmithBench"};
        var food=new Recipe{itemValueType=2,craftingArea="campfire"};var stove=new Recipe{itemValueType=2,craftingArea="grimmerCookingStove"};
        var source=new List<Recipe>{gun,specialist,food,stove};var display=RecipeVariants.ForDisplay(source);
        Check(display.Count==2&&display.Contains(gun)&&display.Contains(food),"General list prefers original recipes");
        Check(source.Count==4,"Source list not mutated");
        Check(RecipeVariants.ForDisplay(new List<Recipe>{specialist}).Contains(specialist),"Gunsmith retains its own variant");
        Check(RecipeVariants.ForDisplay(new List<Recipe>{stove}).Contains(stove),"Cooking stove retains its own variant");
        var other=new Recipe{itemValueType=1,craftingArea="thirdPartyBench"};
        Check(RecipeVariants.ForDisplay(new List<Recipe>{gun,other}).Count==2,"Other mods' alternate recipes preserved");
        var refund=new Recipe{itemValueType=1,craftingArea="forge"};
        Check(RecipeVariants.ForDisplay(new List<Recipe>{gun,refund}).Count==2,"Legitimate vanilla alternatives preserved");
        Check(RecipeVariants.ForDisplay(new List<Recipe>{gun,specialist,other}).Count==2,"Only our duplicate row removed");
        Check(RecipeVariants.ForDisplay(new List<Recipe>{specialist,stove}).Count==2,"Station-only selection kept");
        Check(RecipeVariants.ForDisplay(new List<Recipe>{specialist,gun})[0]==gun,"Ordering-independent preference");
        Check(RecipeVariants.ForDisplay(null)==null,"Null list safe");
        Check(RecipeVariants.ForDisplay(new List<Recipe>{null}).Count==1,"Null entry preserved for native handling");
        var unknown=new Recipe{itemValueType=0,craftingArea="grimmerGunsmithBench"};
        Check(RecipeVariants.ForDisplay(new List<Recipe>{unknown,new Recipe()}).Count==2,"Unresolved outputs not conflated");
        var gunsmithDisplay=RecipeVariants.ForDisplay(source,"grimmerGunsmithBench");
        Check(gunsmithDisplay.Count==2&&gunsmithDisplay.Contains(specialist)&&gunsmithDisplay.Contains(food),"All-recipes view at Gunsmith prefers craftable specialist");
        var stoveDisplay=RecipeVariants.ForDisplay(source,"grimmerCookingStove");
        Check(stoveDisplay.Count==2&&stoveDisplay.Contains(stove)&&stoveDisplay.Contains(gun),"All-recipes view at stove prefers craftable specialist");
        Check(RecipeVariants.ForDisplay(new List<Recipe>{gun,specialist,other},"grimmerGunsmithBench").Contains(other),"Specialist context preserves unrelated alternative");
        var patched=source;RecipeVariantsDisplayPatch.Prefix(new XUiC_RecipeList(),ref patched);Check(patched.Count==2&&source.Count==4,"UI gets a display copy");
        Workshop.player=null;patched=source;RecipeVariantsDisplayPatch.Prefix(new XUiC_RecipeList(),ref patched);Check(object.ReferenceEquals(patched,source),"Non-solo UI unaffected");
        Console.WriteLine("PASS: "+checks+" specialist recipe display checks.");
    }
}
