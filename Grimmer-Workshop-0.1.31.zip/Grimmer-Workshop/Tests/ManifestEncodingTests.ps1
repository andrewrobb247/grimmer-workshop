$ErrorActionPreference='Stop'
$builder=Join-Path $PSScriptRoot '..\Build-Release.ps1'
$output=Join-Path $PSScriptRoot ('..\..\work\manifest-encoding-'+[guid]::NewGuid().ToString('N'))
& $builder -Version '9.9.9' -OutputDirectory $output -Notes 'Local encoding regression fixture only; do not publish.'
foreach($path in @((Join-Path $output 'channels\testing.json'),(Join-Path $output 'versions\9.9.9\Installed-Release.json'))) {
 $bytes=[IO.File]::ReadAllBytes($path)
 if($bytes.Length -ge 3 -and $bytes[0] -eq 239 -and $bytes[1] -eq 187 -and $bytes[2] -eq 191){throw 'Release JSON has a UTF-8 BOM.'}
 $json=[Text.Encoding]::UTF8.GetString($bytes)|ConvertFrom-Json
 if($json.schema -ne 1 -or $json.version -ne '9.9.9'){throw 'Generated JSON is invalid.'}
}
Write-Host 'Passed Windows PowerShell release encoding checks: manifest and installed state are valid marker-free UTF-8 JSON.'
