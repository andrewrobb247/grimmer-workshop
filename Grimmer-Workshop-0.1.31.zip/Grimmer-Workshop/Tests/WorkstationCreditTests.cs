using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using GrimmerWorkshop;
namespace HarmonyLib {
 public class HarmonyPatch:Attribute { public HarmonyPatch(Type t,string m){} }
 public static class AccessTools { public static MethodInfo Method(Type t,string n){return t.GetMethod(n);} }
 public class CodeInstruction {
  public OpCode opcode; public object operand;
  public List<Label> labels=new List<Label>(); public List<object> blocks=new List<object>();
  public CodeInstruction(OpCode o,object p=null){opcode=o;operand=p;}
  public CodeInstruction(CodeInstruction c){opcode=c.opcode;operand=c.operand;labels.AddRange(c.labels);blocks.AddRange(c.blocks);}
 }
}
public class TileEntityWorkstation {}
public class ItemValue { public int Type,Quality; public int GetItemId(){return Type;} }
class WorkstationCreditTests {
 static int checks;
 static void Check(bool v,string m){checks++;if(!v)throw new Exception(m);}
 static void Reject(IEnumerable<HarmonyLib.CodeInstruction> il,string message){bool rejected=false;try{WorkstationCredit.Transpiler(il).ToList();}catch(InvalidOperationException){rejected=true;}Check(rejected,message);}
 static List<HarmonyLib.CodeInstruction> Pattern(OpCode branch){var get=typeof(ItemValue).GetMethod("GetItemId");return new List<HarmonyLib.CodeInstruction>{new HarmonyLib.CodeInstruction(OpCodes.Callvirt,get),new HarmonyLib.CodeInstruction(OpCodes.Ldarg_2),new HarmonyLib.CodeInstruction(OpCodes.Callvirt,get),new HarmonyLib.CodeInstruction(branch,new object())};}
 public static void Main(){
  Check(WorkstationCredit.SameCreditItem(new ItemValue{Type=1,Quality=3},new ItemValue{Type=1,Quality=3}),"Same quality may aggregate");
  Check(!WorkstationCredit.SameCreditItem(new ItemValue{Type=1,Quality=1},new ItemValue{Type=1,Quality=6}),"Mixed quality stays separate");
  Check(!WorkstationCredit.SameCreditItem(new ItemValue{Type=1,Quality=3},new ItemValue{Type=2,Quality=3}),"Different items stay separate");
  Check(!WorkstationCredit.SameCreditItem(null,new ItemValue()),"Null credit item is safe");
  Check(WorkstationCredit.SameCreditItem(new ItemValue{Type=1},new ItemValue{Type=1}),"Unquality cooking batches may aggregate");
  foreach(var branch in new[]{OpCodes.Bne_Un_S,OpCodes.Bne_Un}){
   var pattern=Pattern(branch);var result=WorkstationCredit.Transpiler(pattern).ToList();
   Check(result.Count==3&&result[0].opcode==OpCodes.Ldarg_2,"Existing stack receives item comparison argument");
   Check(result[1].operand.Equals(typeof(WorkstationCredit).GetMethod("SameCreditItem")),"Calls production quality comparison");
   Check(result[2].opcode==OpCodes.Brfalse&&Object.ReferenceEquals(result[2].operand,pattern[3].operand),"Keeps original mismatch branch target");
  }
  Reject(new HarmonyLib.CodeInstruction[0],"Missing game comparison fails visibly");
  Reject(Pattern(OpCodes.Bne_Un_S).Concat(Pattern(OpCodes.Bne_Un_S)),"Ambiguous game comparison fails visibly");
  var unsafePattern=Pattern(OpCodes.Bne_Un_S);unsafePattern[1].labels.Add(default(Label));Reject(unsafePattern,"Unexpected branch label rejected");
  Console.WriteLine("Passed "+checks+" workstation quality credit checks.");
 }
}
