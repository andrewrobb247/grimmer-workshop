import sys,xml.etree.ElementTree as E
from pathlib import Path
mod,baseline,game=map(Path,sys.argv[1:])
def rules(path):return {(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(path/'PracticeRules.xml').getroot()}
new,old=rules(mod),rules(baseline)
assert all(new[k]==v for k,v in old.items()),'Existing route changed'
added=set(new)-set(old)
assert len(added)==16
expected={'foodCornMeal':('craftingFood',1,10),'foodEggBoiled':('craftingFood',4,10),'drinkJarPureMineralWater':('craftingFood',6,25),'drinkJarBlackStrapCoffee':('craftingFood',8,40),'foodCanSham':('craftingFood',8,40),'resourceChickenFeed':('craftingFood',2,10),'medicalAloeCream':('craftingMedical',2,10),'medicalSplint':('craftingMedical',4,20)}
for name in ['foodBurntSmoothie','foodOasisSmoothie','foodFrostbiteSmoothie','foodAtomicSmoothie']:expected[name]=('craftingFood',8,40)
base=E.parse(game/'Data/Config/recipes.xml').getroot()
for item,(skill,credit,until) in expected.items():
 r=new[item,skill]
 assert float(r['credit'])==credit and int(r['until'])==until
 assert r['unlock']=='1' and r['cap']==('75' if skill=='craftingMedical' else '100')
 recipes=[x for x in base.findall('recipe') if x.get('name')==item and x.find('wildcard_forge_category') is None]
 assert len({x.get('count','1') for x in recipes})==1,'Ambiguous batch output'
 assert int(r['output'])==int(recipes[0].get('count','1'))
 if skill=='craftingFood' and any(x.get('craft_area')=='campfire' for x in recipes):
  assert new[item,'craftingWorkstations']['credit']=='12' and new[item,'craftingWorkstations']['cap']=='10'
 else:assert (item,'craftingWorkstations') not in added
assert new['resourceChickenFeed','craftingFood']['output']=='10'
assert not any('Bundle' in item or item.startswith('biomeWeather') for item,_ in added)
assert ('drinkJarEmpty','craftingFood') not in new
print(f'Passed preparation audit: {len(old)} previous routes unchanged; 12 preparation routes plus 4 campfire routes; outputs, caps and packing exclusions checked.')
