param([string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '..\Update-Core.ps1')
$catalog=@(Get-WorkshopBookCatalog $GameDirectory)
if (@($catalog | Where-Object Category -eq 'craftingMagazines').Count -ne 24) { throw 'Expected 24 crafting magazine types.' }
if (@($catalog | Where-Object Category -eq 'perkBooks').Count -lt 100 -or @($catalog | Where-Object Category -eq 'schematics').Count -lt 50) { throw 'Book categories incomplete.' }
[xml]$settings='<workshop />'
$disabled=@(Get-WorkshopDisabledBooks $settings $catalog)
if ($disabled.Count -ne 24) { throw 'Default policy should disable only crafting magazines.' }
[xml]$settings='<workshop><books craftingMagazines="true" perkBooks="false" schematics="true"><allow item="bookFiremansAlmanacHeat"/><deny item="modGunBipodSchematic"/></books></workshop>'
$disabled=@(Get-WorkshopDisabledBooks $settings $catalog)
if ($disabled -contains 'harvestingToolsSkillMagazine' -or $disabled -contains 'bookFiremansAlmanacHeat' -or $disabled -notcontains 'modGunBipodSchematic') { throw 'Individual book overrides failed.' }
$root=Join-Path $PSScriptRoot ('..\..\work\book-policy-test-' + [guid]::NewGuid().ToString('N'))
$mod=Join-Path $root 'Profile\Mods\GrimmerWorkshop'
New-Item -ItemType Directory -Path $mod -Force | Out-Null
'<workshop />' | Set-Content -LiteralPath (Join-Path $mod 'WorkshopSettings.xml') -Encoding UTF8
$count=Write-WorkshopBookPolicy $root $GameDirectory
if ($count -ne 24) { throw 'Wrong default disabled count.' }
$changes=0
foreach($file in @('loot.xml','traders.xml')) {
    [xml]$original=Get-Content -LiteralPath (Join-Path $GameDirectory ('Data\Config\'+$file)) -Raw
    [xml]$patch=Get-Content -LiteralPath (Join-Path $mod ('Config\'+$file)) -Raw
    foreach($operation in $patch.SelectNodes('/configs/*')) {
        $matches=$original.SelectNodes($operation.GetAttribute('xpath'))
        if (-not $matches.Count) { throw 'Invalid book replacement target.' }
        foreach($match in $matches) {
            if($operation.Name -eq 'set') { if($operation.InnerText -ne 'resourcePaper') { throw 'Invalid paper replacement' }; $match.Value=$operation.InnerText }
            elseif($operation.Name -eq 'remove') { $null=$match.ParentNode.RemoveChild($match) }
            elseif($operation.Name -eq 'append') { foreach($child in $operation.ChildNodes) { $null=$match.AppendChild($original.ImportNode($child,$true)) } }
            else { throw 'Unknown book operation' }
            $changes++
        }
    }
    foreach($name in @(Get-WorkshopDisabledBooks ([xml]'<workshop />') $catalog)) {
        if ($original.SelectNodes("//item[@name='$name']").Count) { throw "Disabled book still generated: $name" }
    }
    if($file -eq 'loot.xml') {
        foreach($group in @('groupQuestT1SkillMagazineBundle','groupChallengeRewardSkillMagazinesAll01')) {
            $pool=$original.SelectSingleNode("/lootcontainers/lootgroup[@name='$group']")
            if($pool.SelectNodes('item').Count -ne 1 -or $pool.item.name -ne 'resourceRepairKit' -or $pool.item.count -ne '3') { throw 'Quest pool was not replaced with three repair kits.' }
        }
    }
}
# A disabled direct schematic reward becomes useful too; id changes must happen last.
'<workshop><books craftingMagazines="false" schematics="false" /></workshop>' | Set-Content -LiteralPath (Join-Path $mod 'WorkshopSettings.xml') -Encoding UTF8
$null=Write-WorkshopBookPolicy $root $GameDirectory
[xml]$quests=Get-Content (Join-Path $GameDirectory 'Data\Config\quests.xml') -Raw
[xml]$questPatch=Get-Content (Join-Path $mod 'Config\quests.xml') -Raw
$rewardChanges=0
foreach($operation in $questPatch.SelectNodes('/configs/set')) {
    $targets=$quests.SelectNodes($operation.GetAttribute('xpath'))
    if(-not $targets.Count) { throw 'Quest reward operation lost its target.' }
    foreach($target in $targets) { $target.Value=$operation.InnerText; $rewardChanges++ }
}
if($rewardChanges -eq 0) { throw 'No disabled direct rewards tested.' }
foreach($name in @(Get-WorkshopDisabledBooks ([xml]'<workshop><books craftingMagazines="false" schematics="false" /></workshop>') $catalog)) {
    if($quests.SelectNodes("//reward[@type='Item' and @id='$name']").Count) { throw 'Disabled direct reward remains.' }
}
# Re-enable every category and confirm generated files are emptied, not accumulated.
'<workshop><books craftingMagazines="false"><allow item="bowsSkillMagazine" /></books></workshop>' | Set-Content -LiteralPath (Join-Path $mod 'WorkshopSettings.xml') -Encoding UTF8
$null=Write-WorkshopBookPolicy $root $GameDirectory
[xml]$partial=Get-Content (Join-Path $mod 'Config\loot.xml') -Raw
if($partial.SelectNodes('/configs/remove|/configs/append').Count) { throw 'Partial magazine selection should retain the original bundle pool.' }
'<workshop><books craftingMagazines="true" perkBooks="true" schematics="true" /></workshop>' | Set-Content -LiteralPath (Join-Path $mod 'WorkshopSettings.xml') -Encoding UTF8
if ((Write-WorkshopBookPolicy $root $GameDirectory) -ne 0) { throw 'Re-enable books failed.' }
foreach($file in @('loot.xml','traders.xml','quests.xml')) { [xml]$patch=Get-Content -LiteralPath (Join-Path $mod ('Config\'+$file)) -Raw; if ($patch.SelectNodes('/configs/*').Count) { throw 'Stale disabled rules remained.' } }
Write-Host "Book policy passed: $($catalog.Count) selectable books, 24 magazines, $changes loot/trader references checked, individual overrides and full re-enable."
