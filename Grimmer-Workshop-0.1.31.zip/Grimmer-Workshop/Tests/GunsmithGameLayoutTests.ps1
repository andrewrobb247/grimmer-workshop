param([string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
Add-Type -Path (Join-Path $GameDirectory 'Mods\0_TFP_Harmony\Mono.Cecil.dll')
$assembly=[Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $GameDirectory '7DaysToDie_Data\Managed\Assembly-CSharp.dll'))
$craft=($assembly.MainModule.Types | Where-Object Name -eq 'ItemActionEntryCraft').Methods | Where-Object Name -eq 'OnActivated'
if(-not ($craft.Body.Instructions | Where-Object { [string]$_.Operand -eq 'System.Single XUiM_Recipes::GetRecipeCraftTime(XUi,Recipe)' })){throw 'Native craft action no longer uses the timing hook.'}
$assign=($assembly.MainModule.Types | Where-Object Name -eq 'XUiC_WorkstationWindowGroup').Methods | Where-Object Name -eq 'SetTileEntity'
if(-not ($assign.Body.Instructions | Where-Object { [string]$_.Operand -eq 'System.Void XUiC_CraftingWindowGroup::set_Workstation(System.String)' })){throw 'Shared workstation UI no longer accepts dynamic station identity.'}
$open=($assembly.MainModule.Types | Where-Object Name -eq 'TileEntityWorkstation').Methods | Where-Object Name -eq 'OnLockResponseLocal'
if(-not ($open.Body.Instructions | Where-Object { [string]$_.Operand -eq 'System.String WorkstationData::WorkstationWindow' })){throw 'Station window override hook changed.'}
[xml]$ui=Get-Content -Raw (Join-Path $GameDirectory 'Data\Config\XUi_InGame\xui.xml')
if(-not $ui.SelectSingleNode("//window_group[@name='workstation_workbench']")){throw 'Native workbench window missing.'}
Write-Host 'Passed 4 native gunsmith integration checks: actual craft timer, station identity, window override and native workbench UI.'
