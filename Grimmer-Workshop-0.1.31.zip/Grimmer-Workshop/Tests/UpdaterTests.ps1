$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot '..\Update-Core.ps1')
$script:checks = 0
function Check($Condition, [string]$Message) { $script:checks++; if (-not $Condition) { throw $Message } }
function MustReject([scriptblock]$Action, [string]$Message) {
    $rejected = $false
    try { & $Action | Out-Null } catch { $rejected = $true }
    Check $rejected $Message
}
function New-Fixture {
    $root = Join-Path $PSScriptRoot ('..\..\work\updater-tests\' + [guid]::NewGuid().ToString('N'))
    $game = Join-Path $root 'fake-game'; $install = Join-Path $root 'install'; $payload = Join-Path $root 'payload'
    New-Item -ItemType Directory -Path (Join-Path $game '7DaysToDie_Data\Managed'),$install,$payload -Force | Out-Null
    Set-Content -LiteralPath (Join-Path $game '7DaysToDie_Data\Managed\Assembly-CSharp.dll') -Value 'fake assembly fixture' -Encoding ASCII
    $files = @()
    foreach ($path in @('Launch-Workshop.ps1','README.md','Profile/Mods/GrimmerWorkshop/WorkshopSettings.xml')) {
        $source = Join-Path $payload $path
        New-Item -ItemType Directory -Path (Split-Path $source) -Force | Out-Null
        Set-Content -LiteralPath $source -Value ('updated ' + $path) -Encoding ASCII
        $files += [pscustomobject]@{path=$path; mode=$(if($path.EndsWith('.xml')){'default'}else{'managed'}); size=(Get-Item $source).Length; sha256=(Get-WorkshopHash $source); url=('https://raw.githubusercontent.com/andrewrobb247/grimmer-workshop/main/versions/0.1.3/' + $path)}
    }
    Set-Content -LiteralPath (Join-Path $install 'Launch-Workshop.ps1') -Value 'old launcher' -Encoding ASCII
    Set-Content -LiteralPath (Join-Path $install 'Installed-Release.json') -Value '{"version":"0.1.2"}' -Encoding ASCII
    $settings = Join-Path $install 'Profile/Mods/GrimmerWorkshop/WorkshopSettings.xml'
    New-Item -ItemType Directory -Path (Split-Path $settings) -Force | Out-Null
    Set-Content -LiteralPath $settings -Value 'my custom settings' -Encoding ASCII
    $save = Join-Path $install 'Profile/Saves/my-world/save.dat'
    New-Item -ItemType Directory -Path (Split-Path $save) -Force | Out-Null
    Set-Content -LiteralPath $save -Value 'precious world' -Encoding ASCII
    $manifest = [pscustomobject]@{schema=1;version='0.1.3';gameAssemblySha256=(Get-WorkshopHash (Join-Path $game '7DaysToDie_Data\Managed\Assembly-CSharp.dll'));notes='fixture'; files=$files}
    $downloads = New-Object 'Collections.Generic.List[string]'
    $fetch = {param($url,$destination) $relative = $url.Split(@('/versions/0.1.3/'),[StringSplitOptions]::None)[1]; $downloads.Add($relative); Copy-Item -LiteralPath (Join-Path $payload $relative) -Destination $destination}.GetNewClosure()
    return @{Root=$install; Game=$game; Manifest=$manifest; Fetch=$fetch; Downloads=$downloads; Save=$save; Settings=$settings}
}

$f = New-Fixture
Check (@(Get-WorkshopPlan $f.Root $f.Manifest).Count -eq 2) 'Only changed managed files are planned.'
Check ($f.Downloads.Count -eq 0) 'Checking does not download payloads.'
$null = Install-WorkshopRelease $f.Root $f.Manifest $f.Game $f.Fetch
Check ($f.Downloads.Count -eq 2) 'Only changed files downloaded.'
Check ((Get-Content $f.Settings -Raw).Trim() -eq 'my custom settings') 'Settings preserved.'
Check ((Get-Content $f.Save -Raw).Trim() -eq 'precious world') 'World preserved.'
Check ((Get-Content (Join-Path $f.Root 'Installed-Release.json') -Raw | ConvertFrom-Json).version -eq '0.1.3') 'Installed version recorded.'
Check (@(Get-WorkshopPlan $f.Root $f.Manifest).Count -eq 0) 'Matching files do not download twice.'
$null = Undo-WorkshopRelease $f.Root
Check ((Get-Content (Join-Path $f.Root 'Launch-Workshop.ps1') -Raw).Trim() -eq 'old launcher') 'Rollback restores original files.'
Check (-not (Test-Path (Join-Path $f.Root 'README.md'))) 'Rollback removes introduced managed file.'
Check ((Get-Content $f.Settings -Raw).Trim() -eq 'my custom settings') 'Rollback keeps settings.'
Check ((Get-Content $f.Save -Raw).Trim() -eq 'precious world') 'Rollback keeps world.'
Check ((Get-Content (Join-Path $f.Root 'Installed-Release.json') -Raw | ConvertFrom-Json).version -eq '0.1.2') 'Rollback restores version.'

$f = New-Fixture
$f.Manifest.files[0].sha256 = '0' * 64
MustReject { Install-WorkshopRelease $f.Root $f.Manifest $f.Game $f.Fetch } 'Reject corrupt download.'
Check ((Get-Content (Join-Path $f.Root 'Launch-Workshop.ps1') -Raw).Trim() -eq 'old launcher') 'Corrupt download changes nothing.'
$f = New-Fixture
$f.Manifest.gameAssemblySha256 = '0' * 64
MustReject { Install-WorkshopRelease $f.Root $f.Manifest $f.Game $f.Fetch } 'Reject incompatible game.'
Check ($f.Downloads.Count -eq 0) 'Game mismatch rejected before downloads.'

foreach ($badPath in @('../outside.ps1','Profile/Saves/my-world/save.dat','C:/outside.ps1','Profile/Mods/GrimmerWorkshop/../../Saves/foo','Profile/Mods/GrimmerWorkshop/GrimmerWorkshop.dll:stream')) {
    $f = New-Fixture; $f.Manifest.files[0].path = $badPath
    MustReject { @(Get-WorkshopPlan $f.Root $f.Manifest) } "Reject unsafe path: $badPath"
}
$f = New-Fixture; $f.Manifest.files[0].url = 'https://example.com/evil.ps1'
MustReject { @(Get-WorkshopPlan $f.Root $f.Manifest) } 'Reject foreign host.'
$f = New-Fixture; $f.Manifest.files[2].mode = 'managed'
MustReject { @(Get-WorkshopPlan $f.Root $f.Manifest) } 'Reject manifest overriding settings.'
$f = New-Fixture; $f.Manifest.files += $f.Manifest.files[0]
MustReject { @(Get-WorkshopPlan $f.Root $f.Manifest) } 'Reject duplicate paths.'

# Fail a copy after the first file was applied; verify transaction recovery.
$f = New-Fixture
$script:failCopy = $true
function Copy-Item {
    param([string]$LiteralPath,[string]$Destination,[switch]$Force)
    if ($script:failCopy -and $LiteralPath -match 'staging-.*README\.md$') { $script:failCopy = $false; throw 'Injected mid-install failure' }
    Microsoft.PowerShell.Management\Copy-Item -LiteralPath $LiteralPath -Destination $Destination -Force:$Force
}
MustReject { Install-WorkshopRelease $f.Root $f.Manifest $f.Game $f.Fetch } 'Inject installation failure.'
Check ((Get-Content (Join-Path $f.Root 'Launch-Workshop.ps1') -Raw).Trim() -eq 'old launcher') 'Partial install restored first file.'
Check (-not (Test-Path (Join-Path $f.Root 'README.md'))) 'Partial install restored file absence.'
Check ((Get-Content (Join-Path $f.Root 'Installed-Release.json') -Raw | ConvertFrom-Json).version -eq '0.1.2') 'Partial install preserves version.'
Remove-Item Function:\Copy-Item
Write-Host "Passed $script:checks updater checks."

