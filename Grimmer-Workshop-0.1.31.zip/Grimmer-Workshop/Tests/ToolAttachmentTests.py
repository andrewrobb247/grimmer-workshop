import sys,csv,math,struct,xml.etree.ElementTree as E
from pathlib import Path
game,mod,fixture,baseline,previous=map(Path,sys.argv[1:])
folder=fixture/'Profile/Mods/ZZZ_GrimmerToolOptions'
assert E.parse(folder/'ModInfo.xml').find('Name').get('value')=='ZZZ_GrimmerToolOptions'
mods=E.parse(folder/'Config/item_modifiers.xml').findall('.//item_modifier')
assert len(mods)==2
expected={'grimmerLightToolGrip':(-.1,.15,-10,15),'grimmerReinforcedToolFrame':(.1,-.25,10,-25)}
assert {m.get('name') for m in mods}==set(expected)
items={i.get('name'):i for i in E.parse(game/'Data/Config/items.xml').getroot()}
def tags(name):
 i=items[name];own=i.find("property[@name='Tags']");parent=i.find("property[@name='Extends']")
 return set(own.get('value').split(',')) if own is not None else tags(parent.get('value')) if parent is not None else set()
def accepts(m,name):return bool(tags(name)&set(m.get('installable_tags').split(','))) and not bool(tags(name)&set(m.get('blocked_tags').split(',')))
base=E.parse(game/'Data/Config/item_modifiers.xml').getroot()
with (folder/'Config/Localization.csv').open(encoding='utf8') as f:loc={r['Key']:r['english'] for r in csv.DictReader(f)}
display=E.parse(folder/'Config/ui_display.xml').getroot()
def f32(x):return struct.unpack('f',struct.pack('f',x))[0]
for m in mods:
 name=m.get('name');stamina,wear,shown_s,shown_w=expected[name]
 assert base.find("item_modifier[@name='%s']"%name) is None
 assert m.get('modifier_tags')=='grimmerToolChoice' and m.get('type')=='attachment'
 assert m.find("property[@name='ShowQuality']").get('value')=='false'
 assert m.find("property[@name='DisplayType']").get('value')==name
 assert name in loc and name+'Desc' in loc
 icon=m.find("property[@name='CustomIcon']").get('value');assert base.find("item_modifier[@name='%s']"%icon) is not None
 effects={x.get('name'):x for x in m.findall('.//passive_effect')}
 assert len(effects)==2 and float(effects['StaminaLoss'].get('value'))==stamina and float(effects['DegradationPerUse'].get('value'))==wear
 assert effects['StaminaLoss'].get('tags')=='primary,secondary'
 for tool in ['meleeToolRepairT0StoneAxe','meleeToolPickT1IronPickaxe','meleeToolAxeT2SteelAxe','meleeToolShovelT2SteelShovel','meleeToolSalvageT1Wrench','meleeToolSalvageT2Ratchet','meleeToolSalvageT3ImpactDriver']:assert accepts(m,tool),(name,tool)
 for tool in ['meleeToolAxeT3Chainsaw','meleeToolPickT3Auger','meleeToolRepairT1ClawHammer','meleeToolRepairT3Nailgun','meleeToolSalvageWrenchAdmin','meleeWpnClubT0WoodenClub','gunBowT0PrimitiveBow','gunHandgunT1Pistol']:assert not accepts(m,tool),(name,tool)
 panel=display.find(".//item_display_info[@display_type='%s']"%name);assert panel is not None and len(panel.findall('display_entry'))==2
 values={v.get('name'):float(v.get('value')) for v in m.findall('.//display_value')}
 for key,shown in [('dStaminaLoss',shown_s),('dDegradationPerUse',shown_w)]:
  assert math.floor(f32(f32(f32(1+f32(values[key]))-1)*100))==shown
 for entry in panel.findall('display_entry'):assert entry.get('title_key') in loc
 recipes=E.parse(mod/'Config/recipes.xml').getroot();r=recipes.find(".//recipe[@name='%s']"%name)
 assert r.get('craft_area')=='workbench' and r.get('always_unlocked')=='true' and r.get('count')=='1'
 assert len(r.findall('ingredient'))==3 and all(i.get('name') in items and int(i.get('count'))>0 for i in r.findall('ingredient'))
old=E.parse(baseline/'Profile/Mods/GrimmerWorkshop/Config/item_modifiers.xml').getroot()
current=E.parse(fixture/'Profile/Mods/GrimmerWorkshop/Config/item_modifiers.xml').getroot()
assert E.tostring(old)==E.tostring(current),'Original melee definitions changed'
rules={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(mod/'PracticeRules.xml').getroot()}
prior={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(previous/'PracticeRules.xml').getroot()}
assert all(rules[k]==v for k,v in prior.items())
assert set(rules)-set(prior)=={(name,'craftingWorkstations') for name in expected}
old_recipes=E.parse(previous/'Config/recipes.xml').getroot()
for old_recipe in old_recipes.findall('.//recipe'):
 current_recipe=recipes.find(".//recipe[@name='%s']"%old_recipe.get('name'))
 assert current_recipe is not None and E.tostring(current_recipe).strip()==E.tostring(old_recipe).strip()
for name in expected:
 r=rules[name,'craftingWorkstations'];assert r['credit']=='4' and r['cap']=='25'
print('Passed tool attachment checks: fixed tradeoffs, readable names, stat display rounding, hand-tool compatibility, motor/repair/weapon exclusions, mutual tag, recipes and old melee preservation.')
