import sys,xml.etree.ElementTree as E
from pathlib import Path
mod,baseline=map(Path,sys.argv[1:])
rules={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(mod/'PracticeRules.xml').getroot()}
old={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(baseline/'PracticeRules.xml').getroot()}
for key,rule in old.items():
 new=rules[key]
 expected=dict(rule)
 if key[1]=='craftingWorkstations' and rule['credit']=='5' and rule['cap']=='10':expected['credit']='12'
 assert new==expected,(key,new,expected)
assert rules['drinkJarBoiledWater','craftingWorkstations']['credit']=='2'
assert rules['drinkJarBoiledWater','craftingWorkstations']['cap']=='10'
assert rules['ammoGasCan','craftingVehicles']['credit']=='0.1'
added=set(rules)-set(old)
for item,skill in added:
 assert skill=='craftingWorkstations'
 assert item=='drinkJarBoiledWater' or item in ('grimmerLightGrip','grimmerPowerGrip') or item.startswith(('meleeWpn','meleeTool','gun','apparel'))
 if item not in ('drinkJarBoiledWater','grimmerLightGrip','grimmerPowerGrip'):
  assert rules[item,skill]['credit']=='2' and rules[item,skill]['cap']=='75'
# At base speed and no saved practice, food-only level 4 -> 10 takes 22 batches, previously 52.
cost=sum(40+.5*(lvl-1) for lvl in range(4,10))
assert (cost+11)//12==22 and (cost+4)//5==52
print(f'Passed route-change audit: {len(old)} existing routes checked; {len(added)} bounded secondary routes; food bridge 52 -> 22 batches.')
