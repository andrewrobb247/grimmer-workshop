import csv
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

game,current,previous,fixture=map(Path,sys.argv[1:])
def signature(n):
    return n.tag,tuple(sorted(n.attrib.items())),tuple(signature(c) for c in n)
rules={(r.get('item'),r.get('skill')):r.attrib for r in ET.parse(current/'PracticeRules.xml').getroot()}
old={(r.get('item'),r.get('skill')):r.attrib for r in ET.parse(previous/'PracticeRules.xml').getroot()}
assert len(old)==634 and all(rules[k]==v for k,v in old.items())
assert set(rules)-set(old)=={('grimmerCookingStove','craftingWorkstations')}
config=fixture/'Profile/Mods/ZZZ_GrimmerCooking/Config'
bench=ET.parse(config/'blocks.xml').getroot().find('.//block')
props={p.get('name'):p.get('value') for p in bench.findall('property') if p.get('name')}
assert bench.get('name')=='grimmerCookingStove' and props['Class']=='Campfire'
assert props['WorkstationWindow']=='workstation_campfire' and props['UnlockedBy']=='craftingFood'
assert props['MaxDamage']=='500'
assert not {'ParticleName','ParticleOffset','BuffsWhenWalkedOn'}&props.keys()
assert props['HeatMapStrength']=='5', 'Normal heat generation retained'
assert props['ActiveRadiusEffects']=='buffCampfireAOE,3', 'Normal warmth retained'
nativeblocks=ET.parse(game/'Data/Config/blocks.xml').getroot()
model=nativeblocks.find("block[@name='cntWoodBurningStove']/property[@name='Model']").get('value')
assert props['Model']==model
settings={p.get('name'):p.get('value') for p in bench.findall("property[@class='Workstation']/property")}
assert settings['CraftingAreaRecipes']=='grimmerCookingStove'
assert settings['Modules']=='tools,output,fuel,input', 'Native tools/fuel queues required'
effect=ET.parse(config/'progression.xml').getroot().find('.//passive_effect')
assert effect.attrib==dict(name='RecipeTagUnlocked',operation='base_set',level='20,100',value='1',tags='grimmerCookingStove')
native=ET.parse(game/'Data/Config/recipes.xml').getroot().findall("recipe[@craft_area='campfire']")
copies=ET.parse(config/'recipes.xml').getroot().findall('.//recipe')
assert len(native)==49 and len(copies)==49
for recipe in copies:
    assert recipe.get('craft_area')=='grimmerCookingStove'
    recipe.set('craft_area','campfire')
assert {signature(r) for r in copies}=={signature(r) for r in native}, 'Ingredients, tools, unlocks, outputs or quality rules changed'
recipes=ET.parse(current/'Config/recipes.xml').getroot()
stove=recipes.find(".//recipe[@name='grimmerCookingStove']")
assert stove.get('craft_area')=='workbench' and stove.get('craft_time')=='60'
assert 'learnable' in stove.get('tags') and stove.get('always_unlocked') is None
assert {i.get('name'):i.get('count') for i in stove.findall('ingredient')}=={'resourceForgedIron':'10','resourceMetalPipe':'4','resourceMechanicalParts':'4','resourceRockSmall':'10'}
previous_recipes=ET.parse(previous/'Config/recipes.xml').getroot()
assert {signature(r) for r in recipes.findall('.//recipe') if r.get('name')!='grimmerCookingStove'}=={signature(r) for r in previous_recipes.findall('.//recipe')}
with (config/'Localization.csv').open(newline='',encoding='utf-8-sig') as f:
    texts={r['Key']:r['english'] for r in csv.DictReader(f)}
assert texts['grimmerCookingStove']=='Cooking Stove' and '25%' in texts['grimmerCookingStoveDesc'] and 'fuel' in texts['grimmerCookingStoveDesc']
print('PASS: all 49 stove recipes preserve native ingredients/tools/unlocks/quality effects; fuel modules, Food 20 gate, model, costs, localization and 634 previous routes/custom recipes verified.')
