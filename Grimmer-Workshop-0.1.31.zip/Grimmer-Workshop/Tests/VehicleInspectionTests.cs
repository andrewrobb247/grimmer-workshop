using System;
using System.IO;
using GrimmerWorkshop;

class VehicleInspectionTests
{
    static int checks;
    static void Check(bool pass, string message) { checks++; if (!pass) throw new Exception(message); }
    static void Main(string[] args)
    {
        string directory = Path.Combine(args[0], "vehicle-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(directory);
        string file = Path.Combine(directory, "world-a.xml");
        var state = new VehicleInspectionState(file);
        string key = VehicleInspectionState.Key(-345, 62, 17);
        Check(!state.Contains(key), "Fresh vehicle is available");
        Check(state.Reserve(key, "smallEngine:1:1;"), "First reserve succeeds");
        Check(!state.Reserve(key, "carBattery:1:3;"), "Repeat reserve rejected");
        var reloaded = new VehicleInspectionState(file);
        Check(reloaded.Contains(key), "Depletion survives reload");
        Check(!reloaded.Reserve(key, "vehicleWheels:1:1;"), "Reload cannot reroll");
        string other = VehicleInspectionState.Key(-344, 62, 17);
        Check(reloaded.Reserve(other, "resourceMechanicalParts:2:1;"), "Neighbour remains available");
        Check(new VehicleInspectionState(file).Contains(key), "Second atomic write preserves first vehicle");
        Check(!new VehicleInspectionState(Path.Combine(directory, "world-b.xml")).Contains(key), "Worlds isolated");
        File.WriteAllText(file, "broken");
        bool rejected = false;
        try { new VehicleInspectionState(file); } catch { rejected = true; }
        Check(rejected, "Corrupt ledger fails closed");
        var unwritable = new VehicleInspectionState(Path.Combine(directory, "missing", "state.xml"));
        rejected = false;
        try { unwritable.Reserve(key, "parts"); } catch (IOException) { rejected = true; }
        Check(rejected && !unwritable.Contains(key), "Failed write never marks vehicle or authorizes payout");
        Check(VehicleInspectionState.EligibleName("cntCar03Sedan3WideDamage0v06"), "Sedan supported");
        Check(VehicleInspectionState.EligibleName("cntBusSchool"), "Bus supported");
        foreach(var vehicle in new[]{"cntMinivan01White","cntMinivan3Wide01Black","cntPickupTruck01White","cntPickupTruck3Wide01Pink","cntSemiTruck01White","cntSemiTruck01ModularFrontRed","cntFireTruck01Red","cntServiceTruckMoPower","cntBoxTruckBlue","cntArmyTruckClosed","cntFarmTruckOpen"})
            Check(VehicleInspectionState.EligibleName(vehicle), "Additional searchable vehicle: "+vehicle);
        Check(VehicleInspectionState.EligibleName("cntPoliceCar01AlarmLocked"), "Police eligible subject to runtime lock check");
        Check(!VehicleInspectionState.EligibleName("cntCar03SedanDamage0RandomHelper"), "Random helpers excluded");
        Check(!VehicleInspectionState.EligibleName("cntCardboardBox"), "Other containers excluded");
        Check(!VehicleInspectionState.EligibleName("vehicle4x4Truck"), "Player vehicles excluded");
        int[] successes = new int[3], damaged = new int[3];
        for (int condition = 0; condition < 3; condition++)
            for (int roll = 0; roll < 100; roll++) {
                string result = VehicleInspectionState.WorkingPart(roll, condition);
                Check(result == null || result == "smallEngine" || result == "carBattery" || result == "vehicleWheels", "Only allowed usable parts");
                if (result != null) successes[condition]++;
                bool recoverable = VehicleInspectionState.RecoverableEngine(roll, condition);
                Check(!recoverable || result == null, "Damaged engine never duplicates working component outcome");
                if (recoverable) damaged[condition]++;
            }
        Check(successes[0] == 18 && successes[1] == 9 && successes[2] == 0, "Condition affects usable-part chance");
        Check(damaged[0] == 18 && damaged[1] == 9 && damaged[2] == 0, "Condition affects damaged engine chance");
        Check(VehicleInspectionState.Condition("cntCar03SedanDamage1v01") == 1, "Damaged condition");
        Check(VehicleInspectionState.Condition("cntCar03SedanDamage2Master") == 2, "Wreck condition");
        Console.WriteLine("PASS: " + checks + " vehicle inspection checks. Fixtures: " + directory);
    }
}
