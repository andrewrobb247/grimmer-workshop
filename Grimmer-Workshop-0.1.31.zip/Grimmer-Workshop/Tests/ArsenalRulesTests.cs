using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using GrimmerWorkshop;
namespace GrimmerWorkshop { public sealed class PracticeRule { public string Item,Skill;public int Output,Unlock,Until,Cap;public int Units=1;public double Credit; } }
class ArsenalRulesTests {
    static int checks;
    static void Check(bool pass,string text){checks++;if(!pass)throw new Exception(text);}
    static void Main(string[] args){
        string pack=args[0];
        var rules=ArsenalRules.Read(pack);
        Check(rules.Count==54,"53 weapons and one energy-cell route");
        Check(rules.Select(r=>r.Item).Distinct().Count()==54,"One award route per output");
        var expected=new Dictionary<string,int>{{"craftingHandguns",16},{"craftingShotguns",6},{"craftingRifles",6},{"craftingMachineGuns",7},{"craftingKnuckles",3},{"craftingBlades",3},{"craftingClubs",5},{"craftingSledgehammers",3},{"craftingSpears",3},{"craftingRobotics",1},{"craftingElectrician",1}};
        foreach(var pair in expected)Check(rules.Count(r=>r.Skill==pair.Key)==pair.Value,"Correct family: "+pair.Key);
        foreach(var rule in rules){Check(rule.Unlock>=1&&rule.Unlock<=rule.Cap&&rule.Until>=rule.Unlock,"Valid unlock/relevance: "+rule.Item);Check(rule.Output==1&&rule.Units==1,"No duplicated output credit");}
        Check(rules.Single(r=>r.Item=="dsdArsEnergyCell").Credit==.02,"Small per-cell practice");
        Check(rules.Single(r=>r.Item=="dsdArsThermalKatana").Skill=="craftingBlades","Katana trains Blades");
        Check(rules.Single(r=>r.Item=="dsdArsWarMace").Skill=="craftingClubs","War Mace trains Clubs");
        Check(ArsenalRules.Read(Path.Combine(pack,"missing")).Count==0,"Pack absent leaves vanilla play intact");
        var destination=new Dictionary<string,List<PracticeRule>>();destination.Add("nativeWeapon",new List<PracticeRule>());
        var skills=new HashSet<string>();
        Check(ArsenalRules.Register(Path.Combine(Path.GetDirectoryName(pack),"GrimmerWorkshop"),destination,skills)==54,"Full optional registration");
        Check(destination.Count==55&&destination.ContainsKey("nativeWeapon"),"Existing rules retained");
        bool rejected=false;try{ArsenalRules.Register(Path.Combine(Path.GetDirectoryName(pack),"GrimmerWorkshop"),destination,skills);}catch(InvalidDataException){rejected=true;}
        Check(rejected&&destination.Count==55,"Duplicate registration fails before changing routes");
        Console.WriteLine("PASS: "+checks+" Arsenal integration checks against downloaded pack metadata.");
        foreach(var rule in rules)Console.WriteLine(rule.Item+" -> "+rule.Skill+"; unlock "+rule.Unlock+"; full through "+rule.Until);
    }
}
