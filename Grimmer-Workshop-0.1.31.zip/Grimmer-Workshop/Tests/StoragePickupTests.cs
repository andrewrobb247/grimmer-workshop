using System;
using GrimmerWorkshop;
class StoragePickupTests
{
    static int checks;
    static void Check(bool pass,string name){checks++;if(!pass)throw new Exception(name);}
    static void Main(){
        var p=new Vector3i(0,0,0);
        var world=new WorldBase { value=new BlockValue { Block=new Block { name="cntWoodWritableCrate" } }, tile=new TileEntityComposite { PlayerPlaced=true,LocalPlayerIsOwner=true,lockable=new TEFeatureLockable() } };
        GameManager.Instance.World=world;
        Check(StoragePickup.CanTake(world,p,Workshop.player),"Empty owned crate accepted");
        foreach(string name in new[]{"cntWoodWritableCrate","cntIronWritableCrate","cntSteelWritableCrate"})Check(StoragePickup.Eligible(name),"Supported material");
        foreach(string name in new[]{"cntWoodWritableCrateInsecure","cntLootChestHero","cntCar03SedanDamage0v01","forge","workbench"})Check(!StoragePickup.Eligible(name),"Other blocks excluded");
        world.tile.storage.empty=false;Check(!StoragePickup.CanTake(world,p,Workshop.player),"Contents protected");world.tile.storage.empty=true;
        world.tile.LocalPlayerIsOwner=false;Check(!StoragePickup.CanTake(world,p,Workshop.player),"Others' storage protected");world.tile.LocalPlayerIsOwner=true;
        world.tile.PlayerPlaced=false;Check(!StoragePickup.CanTake(world,p,Workshop.player),"World props protected");world.tile.PlayerPlaced=true;
        world.tile.accessing=true;Check(!StoragePickup.CanTake(world,p,Workshop.player),"Open inventory protected");world.tile.accessing=false;
        world.tile.lockable.locked=true;Check(!StoragePickup.CanTake(world,p,Workshop.player),"Locked storage protected");world.tile.lockable.locked=false;
        world.value.damage=1;Check(!StoragePickup.CanTake(world,p,Workshop.player),"Repair required");world.value.damage=0;
        Workshop.player.position=new UnityEngine.Vector3(100,0,0);Check(!StoragePickup.CanTake(world,p,Workshop.player),"Distance checked");Workshop.player.position=UnityEngine.Vector3.zero;
        bool result=false;
        Check(StoragePickupActivatePatch.Prefix("Search",world,p,world.value,Workshop.player,ref result),"Search passes through");
        Check(!StoragePickupActivatePatch.Prefix(StoragePickup.Command,world,p,world.value,Workshop.player,ref result)&&Block.timers==1,"Native pickup timer started");
        var data=new TimerEventData { Data=new object[]{world.value,p,Workshop.player} };
        Check(StoragePickupCompletePatch.Prefix(data),"Valid completion delegates to native transfer");
        world.tile.storage.empty=false;Check(!StoragePickupCompletePatch.Prefix(data),"Items added during timer protected");world.tile.storage.empty=true;
        world.tile.LocalPlayerIsOwner=false;Check(!StoragePickupCompletePatch.Prefix(data),"Ownership rechecked at completion");world.tile.LocalPlayerIsOwner=true;
        world.tile=null;Check(!StoragePickupCompletePatch.Prefix(data),"Removed or replaced tile protected");
        data.Data=new object[]{new BlockValue{Block=new Block{name="forge"}},p,Workshop.player};
        Check(StoragePickupCompletePatch.Prefix(data),"Vanilla workstation pickup unchanged");
        Console.WriteLine("PASS: "+checks+" storage pickup checks.");
    }
}
