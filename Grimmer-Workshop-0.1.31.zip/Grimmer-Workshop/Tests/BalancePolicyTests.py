"""Ensure the first balance pass changes only the evidenced fuel outlier."""
import sys,xml.etree.ElementTree as E
from pathlib import Path
current,baseline=map(Path,sys.argv[1:])
def rules(p):return {(x.get('item'),x.get('skill')):dict(x.attrib) for x in E.parse(p).getroot()}
new,old=rules(current),rules(baseline)
assert new.keys()==old.keys(), 'Training route set changed'
changes=[key for key in new if new[key]!=old[key]]
assert changes==[('ammoGasCan','craftingVehicles')], changes
key=changes[0]
assert float(new[key]['credit'])==.1 and float(old[key]['credit'])==10
for field in old[key]:
 if field!='credit':assert new[key][field]==old[key][field],field
assert new[key]['output']=='2', 'Fuel batch normalisation changed'
print('Passed fuel balance policy: 311 routes retained; only fuel credit changed; output, unlock, relevance and caps retained.')
