import sys,csv,xml.etree.ElementTree as E
from pathlib import Path
game,fixture,mod=map(Path,sys.argv[1:]);config=game/'Data'/'Config'
base=E.parse(config/'item_modifiers.xml').getroot()
patch=E.parse(fixture/'Profile'/'Mods'/'GrimmerWorkshop'/'Config'/'item_modifiers.xml').getroot()
assert base.find("item_modifier[@name='modGeneralMaster']") is not None
mods=patch.findall("append/item_modifier")
assert len(mods)==2
names={m.get('name') for m in mods};assert names=={'grimmerLightGrip','grimmerPowerGrip'}
checks=3
for m in mods:
 assert base.find("item_modifier[@name='%s']"%m.get('name')) is None
 assert m.get('type')=='attachment' and m.get('blocked_tags')=='noMods'
 assert m.get('modifier_tags')=='grimmerGrip'
 icon=m.find("property[@name='CustomIcon']").get('value')
 assert base.find("item_modifier[@name='%s']"%icon) is not None
 assert m.find("property[@name='UnlockedBy']") is None
 effects={x.get('name'):x for x in m.findall('.//passive_effect')}
 assert len(effects)==2 and 'StaminaLoss' in effects
 assert effects['StaminaLoss'].get('tags')=='primary,secondary'
 assert all(x.get('operation')=='perc_add' for x in effects.values())
 assert all(base.find(".//passive_effect[@name='%s']"%name) is not None for name in effects)
 if m.get('name')=='grimmerLightGrip':assert float(effects['StaminaLoss'].get('value'))==-.15 and float(effects['DegradationPerUse'].get('value'))==.2
 else:assert float(effects['StaminaLoss'].get('value'))==.15 and float(effects['EntityDamage'].get('value'))==.1
 checks+=9
items={x.get('name'):x for x in E.parse(config/'items.xml').getroot()}
def tags(name,seen=()):
 assert name not in seen
 item=items[name];own=item.find("property[@name='Tags']");parent=item.find("property[@name='Extends']")
 return set(own.get('value').split(',')) if own is not None else tags(parent.get('value'),seen+(name,)) if parent is not None else set()
for name in ['meleeWpnClubT0WoodenClub','meleeWpnSledgeT0StoneSledgehammer','meleeWpnSpearT0StoneSpear','meleeWpnBladeT0BoneKnife','meleeWpnKnucklesT0LeatherKnuckles','meleeWpnBatonT0PipeBaton']:
 for m in mods:assert tags(name)&set(m.get('installable_tags').split(','));checks+=1
for name in ['meleeToolRepairT0StoneAxe','meleeToolSalvageT1Wrench','gunHandgunT1Pistol','gunBowT0PrimitiveBow']:
 for m in mods:assert not tags(name)&set(m.get('installable_tags').split(','));checks+=1
with (fixture/'Profile'/'Mods'/'GrimmerWorkshop'/'Config'/'Localization.csv').open(encoding='utf8') as f:localization={r['Key']:r['english'] for r in csv.DictReader(f)}
for m in mods:
 assert m.get('name') in localization and m.find("property[@name='DescriptionKey']").get('value') in localization;checks+=1
recipes=E.parse(mod/'Config'/'recipes.xml').getroot()
for name in names:
 recipe=recipes.find(".//recipe[@name='%s']"%name);assert recipe is not None
 assert recipe.get('always_unlocked')=='true' and recipe.get('craft_area')=='workbench' and recipe.get('count')=='1'
 assert all(i.get('name') in items and int(i.get('count'))>0 for i in recipe.findall('ingredient'))
 assert len(recipe.findall('ingredient'))==3
 checks+=4
print('Passed %s attachment definition, compatibility, effect, recipe and localization checks.'%checks)

# Validate the native stat display chain, not only gameplay effects.
displays=E.parse(fixture/'Profile'/'Mods'/'GrimmerWorkshop'/'Config'/'ui_display.xml').getroot()
for m in mods:
 display_type=m.find("property[@name='DisplayType']").get('value')
 panel=displays.find(".//item_display_info[@display_type='%s']"%display_type)
 assert panel is not None
 values={v.get('name'):float(v.get('value')) for v in m.findall('.//display_value')}
 entries=panel.findall('display_entry')
 assert len(entries)==2
 for entry in entries:
  assert entry.get('name') in values
  assert entry.get('title_key') in localization
  assert entry.get('display_type')=='Percent'
 assert localization[m.get('name')] in ('Light Grip Mod','Power Grip Mod')
print('Passed native stat-panel and readable-name checks.')
