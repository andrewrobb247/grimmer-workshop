"""Check generated patches against the installed baseline without editing it."""
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

root = Path(__file__).resolve().parents[1]
game = Path(sys.argv[1])
mod = root / 'Profile' / 'Mods' / 'GrimmerWorkshop'
config = game / 'Data' / 'Config'
skills = {s.get('name'): int(s.get('max_level')) for s in ET.parse(config / 'progression.xml').findall('.//crafting_skill')}
rules = ET.parse(mod / 'PracticeRules.xml').getroot()
by_skill = defaultdict(list)
for rule in rules:
    assert rule.get('skill') in skills
    assert int(rule.get('output')) > 0
    assert 1 <= int(rule.get('cap')) <= skills[rule.get('skill')]
    assert float(rule.get('credit')) > 0
    by_skill[rule.get('skill')].append(rule)
assert set(by_skill) == set(skills)
assert all(any(int(r.get('unlock')) == 1 for r in entries) for entries in by_skill.values())

items = ET.parse(config / 'items.xml').getroot()
removed_effects = 0
for operation in ET.parse(mod / 'Config' / 'items.xml').getroot():
    name = operation.get('xpath').split("[@name='")[1].split("']")[0]
    item = items.find("item[@name='%s']" % name)
    assert item is not None
    matches = item.findall(".//triggered_effect[@action='AddProgressionLevel']")
    assert matches
    assert all(e.get('progression_name') in skills for e in matches)
    removed_effects += len(matches)

recipe_names = {r.get('name') for r in ET.parse(config / 'recipes.xml').getroot()}
new_recipes = ET.parse(mod / 'Config' / 'recipes.xml').find('append')
all_items = {i.get('name') for i in items}
for recipe in new_recipes:
    assert recipe.get('name') in all_items
    assert recipe.get('always_unlocked') == 'true'
    for ingredient in recipe.findall('ingredient'):
        assert ingredient.get('name') in all_items
        assert int(ingredient.get('count')) > 0
    recipe_names.add(recipe.get('name'))
assert all(r.get('item') in recipe_names for r in rules)

windows = ET.parse(config / 'XUi_InGame' / 'windows.xml').getroot()
hud = ET.parse(root / 'Profile' / 'Mods' / 'ZZZ_GrimmerHUD' / 'Config' / 'XUi_InGame' / 'windows.xml').getroot()
for operation in hud:
    xpath = operation.get('xpath')
    xpath = '.' + xpath[len('/windows'):]
    if '/@' in xpath:
        parent, attribute = xpath.rsplit('/@', 1)
        targets = windows.findall(parent)
        assert targets, operation.get('xpath')
        assert all(attribute in target.attrib for target in targets), operation.get('xpath')
    else:
        assert windows.findall(xpath), operation.get('xpath')

print(f'Configuration checks passed: {len(rules)} routes, {len(skills)} startable skills, {removed_effects} magazine effects, {len(new_recipes)} assembly recipes, and all HUD patch targets.')
