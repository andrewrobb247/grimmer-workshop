# Publication status

0.1.31 vehicle interaction follow-up prepared. Publication verification pending. Includes all prior features and recipe display fix; no external assets changed. See PLAYTEST-CHECKLIST.md.
