# Future ideas — design backlog

User suggestions, recorded 18 November 2026. These are discussion ideas, not approved replacements for the existing roadmap.

- Zombie weak points, joint damage and targeted dismemberment.
- Experimental zombie variants with a core in a body region: decapitation need not kill them; destroying the core or disabling every limb provides an outcome. Investigate engine feasibility and visual clues first.
- Inspect derelict vehicles for working engines/parts before salvage, with persistent depletion to prevent duplicate parts.
- Pick up empty owned deployed storage, with contents/ownership checks.
- Convenient thin floor panels for building above terrain without excavating full blocks.

Current priority remains finishing storage and progression, then balance and the existing roadmap in README.md.
