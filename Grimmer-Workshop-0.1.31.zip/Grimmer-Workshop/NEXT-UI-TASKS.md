# Next tasks

- 0.1.30 recipe display fix published and old updater verified. Live list check after restart pending.
- DSD Arsenal 1.2.1 installation complete: actual startup log confirms pack and Workshop 0.1.29 load, all 53 weapon practice mappings registered.
- Continue actual model/animation/sound, crafting quality/gates, combat/scrap practice and save/reload checks from PLAYTEST-CHECKLIST.md.
- Preserve author files; no external assets bundled. No native-model substitute weapons added.
- Farming/compost deferred behind weapon feedback.
