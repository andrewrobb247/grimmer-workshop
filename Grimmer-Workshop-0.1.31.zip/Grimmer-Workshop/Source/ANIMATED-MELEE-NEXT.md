# Current priority - animated melee weapons

User specifically wants genuinely new melee models and animations, and is willing to download an external pack. Do not substitute vanilla-model stat variants as completion of this task. Experimental Field Knife/Scrap Mace/Long Spear source additions were removed before publication; current published build remains 0.1.28, with 635 practice routes.

Leading candidate: xDarksides Arsenal (Pantstain's Pack Remastered), Nexus 13921, author advertises V3.4 and 18 melee weapons with custom models/animations/sounds. Entire pack also contains firearms. Download it unchanged from the author, inspect exact files and permissions, test in an isolated Workshop profile, then determine supported integration without copying/repacking restricted assets. Do not claim melee-only installation support before inspecting files. No pack installed or compatibility established yet.

Main download page: https://www.nexusmods.com/7daystodie/mods/13921?tab=files
User can leave downloaded archive in Downloads for read-only inspection. Do not write to user Downloads or Steam Mods from this workspace. Do not run third-party DLLs before inspection and an isolated test setup. Existing farm/compost work is deferred behind this melee priority.