# Workstation completion audit

18 November 2026, installed V3.4 b10 assemblies.

The game's workstation queue records completed output through AddCraftComplete. Records are saved by writeCraftCompleteData and restored by readCraftCompleteData. Opening a workstation invokes CheckForCraftComplete for the local player. That calls GiveExp, which emits QuestEventManager.CraftedItem, then removes claimed completion records and marks the station modified. The Workshop crafting hook listens to that event. Merely standing nearby is not the reliable claim trigger; open the station.

Issue found: AddCraftComplete compares only ItemValue.GetItemId and ItemScrapped when merging records. GetItemId returns type minus ItemsStartHere; quality is absent. A Q1 then Q6 batch can therefore be recorded as two Q1 items (or vice versa). Workshop practice applies the record's quality multiplier, so this miscredits mixed-quality crafts.

Correction: refine that one item comparison to require the same type AND quality. Keep the existing completion list, serialization, claim/removal path, output items and other native logic. Plain cooking batches still aggregate. No new timer or extra completion award hook was added.

Validation: 14 production transpiler/helper checks, four installed-game layout checks, real-game compilation. Layout guards fail visibly if the game method changes. These are code checks; a live mixed-quality workstation run and save/reload remain pending.

Live test: craft the same mapped equipment at two different qualities in a station, leave/close it until completion, then open it. Compare saved practice with each quality's expected reward. Reopen and ensure no additional credit. Cook several items, repeat, and then save/reload before claiming another batch. Rates and recipe caps still apply. Earlier pending completion records already merged by the old game path cannot have their original qualities reconstructed.
