using System;
using System.Collections.Generic;
namespace GrimmerWorkshop
{
    // Only activity rewards are throttled. Completed crafts retain full credit.
    public sealed class ActivityBudget
    {
        sealed class Window { public double Start, Used; }
        readonly Dictionary<string, Window> windows = new Dictionary<string, Window>();
        public double Take(string skill, double amount, double now)
        {
            if (amount <= 0 || double.IsNaN(amount) || double.IsInfinity(amount) || double.IsNaN(now) || double.IsInfinity(now)) return 0;
            Window window;
            if (!windows.TryGetValue(skill, out window) || now < window.Start || now >= window.Start + 1) {
                window = new Window { Start = now }; windows[skill] = window;
            }
            double result = Math.Min(amount, Math.Max(0, 3 - window.Used));
            window.Used += result;
            return result;
        }
    }
}
