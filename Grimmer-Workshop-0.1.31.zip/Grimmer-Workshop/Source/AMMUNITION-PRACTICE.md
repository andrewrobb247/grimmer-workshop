# Ammunition practice — 0.1.20

New awards are per completed round/projectile. These are base values at learning speed 1 before relevance decay. Existing recipes, materials and unlock requirements are unchanged.

| Ammunition | Crafting skill | Base practice per round |
| --- | --- | ---: |
| 9mm / .44 ball, HP, AP | Handguns | 0.02 / 0.03 / 0.04 |
| 7.62mm ball, HP, AP | Rifles and Machine Guns, each | 0.01 / 0.015 / 0.02 |
| Shotgun shell / slug | Shotguns | 0.03 / 0.04 |
| Turret regular / shell or AP | Robotics | 0.01 / 0.02 |
| Stone / iron / steel arrows and bolts | Bows | 0.05 / 0.075 / 0.1 |
| Flaming / explosive arrows and bolts | Bows | 0.15 / 0.2 |
| Iron darts | Traps | 0.01 |

Bundles inherit their real contents from vanilla Action0 Create_item and Create_item_count: usually 100, turret bundles 1,000, explosive arrow/bolt bundles 75. Runtime expands bundle counts before level-boundary calculations. Opening a found or crafted bundle awards no practice; native opening paths add items without firing CraftedItem. Resource packing and meat bundles remain excluded.

The 7.62mm award is split across Rifles and Machine Guns because that cartridge serves both; it is not doubled. Advanced ammo retains its vanilla perk/book/schematic requirements. Ammo practice adds a minor route alongside weapon crafting and combat; relevance decays at higher crafting levels.

Validation: 446 previous routes unchanged; 57 new ammo/skill routes; 25 bundle definitions checked. Recipe XML is byte-identical to 0.1.19. Per-round grouping is explicit (output=1); optional units attribute defaults to 1 on old rules.
