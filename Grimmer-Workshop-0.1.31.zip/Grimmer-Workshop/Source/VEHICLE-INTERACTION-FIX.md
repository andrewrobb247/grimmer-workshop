# Vehicle interaction follow-up, 0.1.31

Native XUiC_Radial.SetCommonData immediately invokes its only enabled entry. Previously an already-inspected vehicle had its inspection entry disabled, leaving only Search, so holding E started looting. Keep an enabled status action for depleted vehicles; dispatch through the same validation and do not grant again. Add HasBlockActivationCommands postfix so inspection is recognised before radial entry enumeration, preserving existing true native results. Native player interaction and radial single-entry behavior verified against installed Assembly-CSharp via Cecil.

Broaden name eligibility to native minivan/pickup/semi/fire/service/box/army/farm families, retaining parent resolution, required TEFeatureStorage, unplaced requirement, lock/use/range checks, persisted depletion and atomic payout reservation. Do not inspect standalone cargo sections without storage. Generated vehicle companion includes both native blockcommand localization entries.

631 state/coverage checks and 21 interaction checks pass, plus existing progression/storage/optional Arsenal regressions. Live sedan report is not conclusively reproduced: saved ledger has one prior recovery, but the tested sedan position is unknown. Pending checks remain explicit.
