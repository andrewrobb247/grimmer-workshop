# Nexus content shortlist - 19 November 2026

Research and proposals, not installed or integrated content. Author descriptions establish advertised features; no candidate has been tested with Grimmer Workshop V3.4 b10. Some Nexus pages were accessible only through indexed description text. Version labels do not establish compatibility with our practice hooks, UI, saves or updater.

## Weapons

| Candidate | Advertised content | Workshop proposal / integration route |
| --- | --- | --- |
| [xDarksides Arsenal](https://www.nexusmods.com/7daystodie/mods/13921) | V3.4; 53 weapons: 35 guns, including 7 lasers, and 18 melee weapons; custom models/animations; Q1-Q6 and vanilla progression. | First full-model weapons candidate to evaluate separately. Focus on scrap guns, service pistol, single-barrel shotgun, battle rifle, crowbar, mace and spears. Author forbids reuploads and requires permission for modifications/asset use, including AI-assisted modification. Do not import or patch files without resolving terms. |
| [IZY New Weapon Pack](https://www.nexusmods.com/7daystodie/mods/12005) | 30+ weapons; v3 release; several support modules; author recommends a new game and warns about overhaul compatibility. | Alternative optional weapon pack, not stacked blindly with other packs. Investigate alongside a disposable test world. Reupload/modification restrictions; permission needed before integration. |
| [N.V.A Weapons Expansion](https://www.nexusmods.com/7daystodie/mods/7014) | Dedicated weapon workbench, 11 firearms, advanced ammunition and rare crafting resources. | Inspiration for an original gunsmith bench, salvaged receiver/barrel components and weapon-family practice. Server-side description is not evidence of new visual models. Permission and exact compatibility not yet checked. |
| [Noble's Katana](https://www.nexusmods.com/7daystodie/mods/925) | V3 file on Nexus, focused sword addition. | Smaller optional melee candidate if a full arsenal is too broad. Inspect weapon tags, quality, animation/slot compatibility, crafting route and permissions first. |

Original weapon-role ideas: compact pistol for cheap close-range use; slower powerful revolver; quiet bow/crossbow options; long-reach spear; fast blade; heavy armour-breaking mace. These are proposals, not claims that every source mod implements them. Adding a distinct 3D weapon requires appropriate model, rig, animations, sounds and attachment support; XML stat variants alone are not new weapon art.

## Vehicles

| Candidate | Advertised content | Workshop proposal / integration route |
| --- | --- | --- |
| [Bdub's Vehicles](https://www.nexusmods.com/7daystodie/mods/342) | Listing shows version 3.4.0.2; dirt bike, buggy, pickup/work trucks, box truck, military vehicles and helicopters; custom mechanic trader. | Prioritise dirt bike, utility pickup and cargo van/truck for different exploration/hauling roles. Optional separate dependency is preferable to repacking; author restricts modification and asset redistribution. Mechanic POI/world-generation limitations need checking. |
| [Vehicle Additions](https://www.nexusmods.com/7daystodie/mods/9354) | V3; drivable abandoned-vehicle types; rare salvaged jalopies and accessories used to assemble vehicles; modular content. | Closest inspiration for our inspection/rebuild progression: inspect, diagnose, recover chassis, replace engine/battery/wheels, finish a vehicle. We must choose how it interacts with native salvage to avoid duplicate rewards. Modification/asset use require permission; redistribution restricted. |
| [Nomad Stations](https://www.nexusmods.com/7daystodie/mods/12324) | Vehicle-mounted stations with persistent inventories, tools, fuel, queues and resources. Earlier listing specifies 3.2/3.3 support. | Later optional mobile-workshop project. Requires special verification of our saved workstation credit, queue quality and update/rollback handling. V3.4 b10 support not established. |

Original vehicle roles: scout bike (small cargo), work pickup (balanced), cargo van (hauling), late heavy truck (capacity versus fuel/repair cost). Restoration is a separate project from merely adding drivable models.

## Zombies, wildlife and combat variety

| Candidate | Advertised content | Workshop proposal / integration route |
| --- | --- | --- |
| [Guppycur's Zombies](https://www.nexusmods.com/7daystodie/mods/4412) | V3 remaster; dozens of civilian, worker, responder, military and other infected models integrated into spawning. | Leading enemy-model candidate. Start with a limited grounded roster, balanced to our existing progression. Author explicitly objects to redistributing the mod; use a separate download or obtain permission. |
| [Double G Zombies 3](https://www.nexusmods.com/7daystodie/mods/8212) | Additional zombie characters/skins and upgraded variants; description contains mixed V2/V3 sections. | Alternative smaller roster. Verify exact V3 file and supported game build rather than trusting the title. Do not treat skin/variant counts as distinct base models. Permissions not yet resolved. |
| [Dismember Randomizer](https://www.nexusmods.com/7daystodie/mods/9314) | Advertises 3.3/3.4 injury/gore variation and infected wildlife. | Research reference for the user's limb/weak-point ideas. Not evidence that a movable hidden-core survival system already works. That mechanic still needs separate feasibility, readable clues and gameplay tests. |
| [KGX Wildlife](https://www.nexusmods.com/7daystodie/mods/13799) | Deer herds, predator packs and biome populations using vanilla animal models. | Behaviour/ecosystem candidate: more interesting hunting without simply increasing enemy health. Adds behaviour, not new animal species/models. Dependencies and permission still to inspect. |
| [Livelier Wildlife](https://www.nexusmods.com/7daystodie/mods/14042) | Scavengers can follow kills/blood and vultures investigate kills in certain biomes. | Original hunting-risk idea: noise/carcasses attract danger. Needs spawn/performance limits and no excessive repeat-farming rewards. Not a new-species pack. |

Rejected misleading lead: [Animal Kingdom Pack](https://www.nexusmods.com/7daystodie/mods/10077) is decorative animal artwork/paint tiles, not live animals. Do not list it as a mob expansion. We still need a verified current new-species model pack if the goal is genuinely new animal species.

## Crafting stations and base progression

| Candidate | Advertised content | Workshop proposal / integration route |
| --- | --- | --- |
| [Electric Workstations](https://www.nexusmods.com/7daystodie/mods/12603) | Powered adapter for forge/campfire/chemistry station; optional cooking appliances; page says built/tested on V3.1.0 b14. | Strong early integration candidate: useful electrical progression and electric cooking. Listing states MIT reuse; retain licence and credit, confirm downloaded package terms. Test power loss, unloaded chunks, completion credit and avoid free crafting after power loss. Not yet V3.4 tested. |
| [Austi's Working Machines](https://www.nexusmods.com/7daystodie/mods/10105) | Working oven, coffee makers, grills, water heater, chemistry set and more, using vanilla models. | Inspiration for our own cooking progression. Preserve vanilla recipe alternatives initially and bind unlocks/awards to Food, Workstations and Electrician. Source files have restrictive reuse terms; do not copy. |
| [Repaired Workstations](https://www.nexusmods.com/7daystodie/mods/1161) | A21-era salvage of broken station parts into repaired workstations. | Good mechanic to build independently for V3.4: inspect a ruined forge/bench, recover components, restore at home. Old mod is an idea source, not a compatible drop-in. Avoid bypassing our entire Workstations progression. |
| [Gold Star Workstations](https://www.nexusmods.com/7daystodie/mods/10889) | Rare premium stations and better tools, with faster queues. | Original upgrade path for long-term progression: better tools or station tiers, each with useful cost/benefit. Prefer earned skill/crafting upgrades to a purely trader-luck gate. |
| [Mazriq Food Core](https://www.nexusmods.com/7daystodie/mods/13886) | Custom cooking range/soda fountain, LPG/CO2 fuels and stacking food effects. | Visual reference for richer cooking stations. Inspect model licences/dependencies separately; food buff stacking needs balance rather than direct adoption. |

## Suggested implementation order

1. Test one genuine weapon-model pack in an isolated profile. xDarksides Arsenal has an explicit V3.4 claim; IZY is an alternative. Resolve reuse/patch permissions before editing or bundling. Map accepted weapons to existing skills and completion/scrap practice, with magazine-free progression.
2. Add an original gunsmith bench and original cooking-station progression. Investigate Electric Workstations as a permissively licensed dependency, subject to build verification.
3. Test a small optional zombie-model roster. Balance spawn groups and performance before bosses or special abilities.
4. Test a small optional utility-vehicle roster and connect it to diagnosis/restoration. Keep each vehicle's fuel, capacity and repair role distinct.
5. Farming/hunting improvements, then a larger mobile workshop or weak-point/core prototype.

Keep external downloads separate where authors prohibit repacking. The launcher can later document/validate optional installed packs; automatic redistribution is not presumed. Do not send author messages without the user's explicit instruction. Nothing here changes the unpublished 0.1.26 candidate or existing saves.
