"""Report static recipe economics; values are screening proxies, not live pacing."""
import argparse,csv,json,xml.etree.ElementTree as E
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('game',type=Path);p.add_argument('mod',type=Path);p.add_argument('--baseline',type=Path)
a=p.parse_args();c=a.game/'Data'/'Config';out=Path(__file__).parent
items={x.get('name'):x for file,tag in [('blocks.xml','block'),('items.xml','item')] for x in E.parse(c/file).getroot().findall(tag)}
def prop(name,key,seen=()):
 if name in seen or name not in items:return None
 x=items[name];v=x.find("property[@name='%s']"%key)
 if v is not None:return v.get('value')
 parent=x.find("property[@name='Extends']")
 return prop(parent.get('value'),key,seen+(name,)) if parent is not None else None
def unit_value(name):
 value=prop(name,'EconomicValue');bundle=prop(name,'EconomicBundleSize') or '1'
 try:return float(value)/float(bundle) if value is not None and float(bundle)>0 else None
 except ValueError:return None
recipes={}
for file in [c/'recipes.xml',a.mod/'Config'/'recipes.xml']:
 for recipe in E.parse(file).getroot().findall('.//recipe'):
  if recipe.find('wildcard_forge_category') is None:recipes.setdefault(recipe.get('name'),[]).append(recipe)
rules={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(a.mod/'PracticeRules.xml').getroot()}
rows=[]
for (name,skill),r in sorted(rules.items()):
 for n,recipe in enumerate(recipes.get(name,[]),1):
  ingredients=[(x.get('name'),float(x.get('count'))) for x in recipe.findall('ingredient') if float(x.get('count'))>0]
  values=[unit_value(name) for name,count in ingredients]
  cost=sum(count*value for (name,count),value in zip(ingredients,values)) if all(v is not None for v in values) else None
  credit=float(r['credit'])*(1+(int(r['unlock'])-1)/25)*float(recipe.get('count','1'))/float(r['output'])
  rows.append(dict(skill=skill,item=name,variant=n,station=recipe.get('craft_area','backpack'),unlock=r['unlock'],cap=r['cap'],output=recipe.get('count','1'),quality1_practice=round(credit,5),static_ingredient_value='' if cost is None else round(cost,5),practice_per_value='' if not cost else round(credit/cost,5),declared_craft_seconds=recipe.get('craft_time',''),ingredients='; '.join('%s x%g'%(name,count) for name,count in ingredients)))
with (out/'BALANCE-DATA.csv').open('w',newline='',encoding='utf8') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
changes=[]
if a.baseline:
 old={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(a.baseline).getroot()}
 for key in sorted(old.keys()|rules.keys()):
  if old.get(key)!=rules.get(key):changes.append(dict(item=key[0],skill=key[1],before=old.get(key),after=rules.get(key)))
(out/'BALANCE-CHANGES.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf8')
fuel=rules['ammoGasCan','craftingVehicles']
def simulate(base,batches,grouped=False):
 level=20;practice=0.;total=0.
 for _ in range(1 if grouped else batches):
  if level>=int(fuel['cap']):break
  relevance=1 if level<=int(fuel['until']) else max(.1,1/(1+(level-int(fuel['until']))/5))
  amount=base*(1+(int(fuel['unlock'])-1)/25)*relevance*(batches if grouped else 1);practice+=amount;total+=amount
  while level<int(fuel['cap']) and practice>=40+(level-1)*.5:
   practice-=40+(level-1)*.5;level+=1
 return level,round(practice,3),round(total,3)
text=['# Recipe balance audit','', '18 November 2026. Static vanilla V3.4 b10 recipes plus Workshop assembly recipes.','',
 f'Checked {len(rules)} practice routes and {len(rows)} recipe variants across {len(set(r[1] for r in rules))} skills. Full comparisons are in BALANCE-DATA.csv.','',
 'Ingredient values resolve inherited EconomicValue and EconomicBundleSize independently. This avoids treating one wood as the value of a whole trading bundle. These are comparison proxies, not actual buy/sell prices, resource rarity or gathering time. Counts are the recipe XML baseline; perks, quality scaling, sandbox settings and zero-count placeholders can change actual costs. Missing craft times remain unknown. Reported practice is quality 1 at the recipe unlock level, before falloff, using actual output-to-rule batch normalisation.','',
 '## Confirmed outlier and targeted change','',
 '| Recipe | Ingredients | Old practice | New practice | Declared base time |',
 '| --- | --- | --- | --- | --- |',
 '| Two fuel | One oil shale | 17.6 | 0.176 | 0.125 seconds |',
 '| Bicycle chassis | 5 forged iron, 2 mechanical parts, 2 tape, 2 leather, 2 springs | 11.6 | 11.6 | 30 seconds |','',
 'At Vehicle skill 20 both routes still have full recipe relevance. The old fuel batch exceeded the chassis reward despite its minimal inputs and fast refining time. Fuel base credit changes from 10 to 0.1, retaining output normalisation, unlock scaling and later falloff. No other route or global learning rate changes.','',
 'Simulation, starting Vehicle level 20 with zero practice, 1,000 refining batches (2,000 fuel, 1,000 shale). Separate claims reevaluate relevance as levels increase; one grouped station claim evaluates relevance at its starting level:',
 f'- Old rules: level/practice/credited total {simulate(10,1000)}.',
 f'- New rules, separate claims: level/practice/credited total {simulate(.1,1000)}.',
 f'- Old rules, one grouped claim: {simulate(10,1000,True)}.',
 f'- New rules, one grouped claim: {simulate(.1,1000,True)}.','',
 '## Observations retained for playtesting','',
 '- Backpacks: later packs have expensive sewing/steel/legendary inputs. Quality multipliers already increase reward; ordinary-play craft frequency remains unmeasured. No speculative increase yet.',
 '- Armour: primitive crafts are cheap, but their relevance falls after later unlocks. Advanced armour needs crafting kits. Keep rates while observing actual use.',
 '- Electronics: relays/tripwires cost much less than powered doors, yet both require useful base construction. Their unlock relevance and real build frequency matter; avoid automatic price-proportional rewards.',
 '- Traps: starter spikes train only to skill 25, directing progress to later traps. Confirm regular defence construction can support progression.',
 '- Bulk gunpowder bundles and expensive foods have low practice per listed ingredient value. Bulk processing is supplementary; do not multiply rewards by the bundle contents without checking exploit and pacing effects.','',
 '## Validation and limits','',
 'Compare BALANCE-CHANGES.json with the baseline to ensure only the fuel credit changed. Regenerate all progression routes; unchanged caps/unlocks must still cover every level. Live checks: refine a small fuel batch at Vehicle 20+, compare practice before/after, then reopen the station and check no duplicate credit. No full economy playthrough has been claimed.']
(out/'BALANCE-AUDIT.md').write_text('\n'.join(text)+'\n',encoding='utf8')
print(f'Audited {len(rules)} routes, {len(rows)} variants; {len(changes)} baseline differences. Fuel simulation: old {simulate(10,1000)}, new {simulate(.1,1000)}.')
