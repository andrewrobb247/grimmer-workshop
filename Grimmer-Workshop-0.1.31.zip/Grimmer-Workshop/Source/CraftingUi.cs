using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace GrimmerWorkshop
{
    // A read-only display snapshot. Ingredient collection always rechecks live
    // storage and never removes items from this cache.
    public static class RecipeSuppliesCache
    {
        private static EntityPlayerLocal player;
        private static float nextRefresh;
        private static string signature;
        private static List<ItemStack> stacks = new List<ItemStack>();
        private static int revision;

        public static int Revision { get { Refresh(); return revision; } }
        public static List<ItemStack> Stacks { get { Refresh(); return stacks; } }

        private static void Refresh()
        {
            var currentPlayer = Workshop.Player();
            if (currentPlayer == player && Time.realtimeSinceStartup < nextRefresh) return;
            nextRefresh = Time.realtimeSinceStartup + 0.5f;
            var updated = new List<ItemStack>();
            if (Workshop.NearbyCrafting && currentPlayer != null)
            {
                foreach (var container in Storage.Nearby())
                for (int slot = 0; slot < container.Grid.Length; slot++)
                {
                    var item = container.Grid[slot];
                    if (!container.Grid.IsSlotLocked(slot) && !item.IsEmpty() && !item.itemValue.HasQuality)
                        updated.Add(item.Clone());
                }
            }
            string updatedSignature = String.Join(";", updated.GroupBy(s => s.itemValue.type).OrderBy(g => g.Key).Select(g => g.Key + ":" + g.Sum(s => (long)s.count)));
            if (currentPlayer != player || signature != updatedSignature)
            {
                revision++;
                signature = updatedSignature;
            }
            stacks = updated;
            player = currentPlayer;
        }
    }

    public sealed class SupplyRevision
    {
        public int Value = -1;
    }

    public static class RecipeUiRefresh
    {
        private static readonly ConditionalWeakTable<XUiController, SupplyRevision> revisions = new ConditionalWeakTable<XUiController, SupplyRevision>();
        public static bool Changed(XUiController controller)
        {
            if (controller.WindowGroup == null || !controller.WindowGroup.isShowing) return false;
            int revision = RecipeSuppliesCache.Revision;
            var previous = revisions.GetOrCreateValue(controller);
            if (previous.Value == revision) return false;
            previous.Value = revision;
            return true;
        }
    }

    [HarmonyPatch(typeof(XUiC_RecipeList), "BuildRecipeInfosList")]
    public static class RecipeAvailabilityPatch
    {
        public static void Prefix(XUiC_RecipeList __instance, ref List<ItemStack> __0)
        {
            if (!Workshop.NearbyCrafting || Workshop.Player() == null) return;
            // Match vanilla's distinction between player ingredients and a
            // workstation's dedicated input grid (notably forge materials).
            var input = __instance.WindowGroup.Controller.GetChildByType<XUiC_WorkstationInputGrid>();
            if (input != null && !(input is XUiC_WorkstationMaterialInputGrid && XUiM_Recipes.DisableSmelter)) return;
            var combined = new List<ItemStack>(__0);
            combined.AddRange(RecipeSuppliesCache.Stacks.Select(s => s.Clone()));
            __0 = combined;
        }
    }

    [HarmonyPatch(typeof(XUiC_RecipeList), "Update")]
    public static class RecipeListRefreshPatch
    {
        public static void Prefix(XUiC_RecipeList __instance, ref bool ___resortRecipes)
        {
            if (!RecipeUiRefresh.Changed(__instance)) return;
            ___resortRecipes = true;
            __instance.IsDirty = true;
        }
    }

    [HarmonyPatch(typeof(XUiC_IngredientEntry), "Update")]
    public static class IngredientRefreshPatch
    {
        public static void Prefix(XUiC_IngredientEntry __instance)
        {
            if (RecipeUiRefresh.Changed(__instance)) __instance.IsDirty = true;
        }
    }

    [HarmonyPatch(typeof(XUiC_RecipeCraftCount), "Update")]
    public static class CraftQuantityRefreshPatch
    {
        public static void Prefix(XUiC_RecipeCraftCount __instance)
        {
            if (!RecipeUiRefresh.Changed(__instance)) return;
            __instance.RefreshCounts();
            __instance.IsDirty = true;
        }
    }
}
