using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using HarmonyLib;
using UnityEngine;

namespace GrimmerWorkshop
{
    public static class RecipeTraining
    {
        sealed class Snapshot { public float Next; public string Text; }
        static readonly ConditionalWeakTable<XUiController, Snapshot> snapshots=new ConditionalWeakTable<XUiController, Snapshot>();
        public static string Tooltip(Recipe recipe)
        {
            var player=Workshop.Player();
            if (player==null || recipe==null || Workshop.Speed<=0) return "";
            var output=recipe.GetOutputItemClass();
            List<PracticeRule> rules;
            if (output==null || !Workshop.Rules.TryGetValue(output.GetItemName(),out rules)) return "";
            var entries=new List<string>();
            foreach(var rule in rules) {
                var skill=player.Progression.GetProgressionValue(rule.Skill);
                if(skill==null || rule.Credit<=0) continue;
                int cap=Math.Min(rule.Cap,skill.ProgressionClass.MaxLevel);
                if(skill.Level>=cap) continue;
                entries.Add(Localization.Get(skill.ProgressionClass.NameKey,false)+" (up to level "+cap+")");
            }
            return entries.Count==0 ? "" : "Crafting trains: "+String.Join("; ",entries.Distinct().ToArray());
        }
        public static bool Changed(XUiController controller, Recipe recipe)
        {
            if(controller.WindowGroup==null || !controller.WindowGroup.isShowing) return false;
            var snapshot=snapshots.GetOrCreateValue(controller);
            float now=Time.realtimeSinceStartup;
            if(now<snapshot.Next && now>=snapshot.Next-0.5f) return false;
            snapshot.Next=now+0.5f;
            string text=Tooltip(recipe);
            if(snapshot.Text==text) return false;
            snapshot.Text=text;
            return true;
        }
    }
    [HarmonyPatch(typeof(XUiC_RecipeEntry),"GetBindingValueInternal")]
    public static class RecipeTrainingBindingsPatch
    {
        public static bool Prefix(XUiC_RecipeEntry __instance, ref string __0, string __1, ref bool __result)
        {
            if(__1!="gw_recipe_trains" && __1!="gw_recipe_training") return true;
            string text=RecipeTraining.Tooltip(__instance.Recipe);
            __0=__1=="gw_recipe_trains" ? (text.Length>0 ? "true" : "false") : text;
            __result=true; return false;
        }
    }
    [HarmonyPatch(typeof(XUiC_RecipeList),"Update")]
    public static class RecipeTrainingRefreshPatch
    {
        public static void Prefix(XUiC_RecipeList __instance)
        {
            foreach(var entry in __instance.GetChildrenByType<XUiC_RecipeEntry>())
                if(RecipeTraining.Changed(entry,entry.Recipe)) entry.IsDirty=true;
        }
    }
}
