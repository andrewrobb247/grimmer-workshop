# Enemy expansion research — 19 November 2026

Inspected the installed War3zuk pack read-only at C:/7D2D/v3/War3zuk/War3zuk_AIO_OverHaul. No files copied into Workshop and no spawn changes made.

## Candidates from separate packs

| Pack | Entity-class declarations in installed XML | Author credits | Notes |
| --- | --- | --- | --- |
| NPCXS Gans Zombies | 11 | GanTheGrey | Clown, war zombies, Rekt/Hugh variants, Girl and Carl. Metadata description lists fewer than the XML; count is declarations, not distinct models. |
| NPCXS Zombie Pack | 41 | DoubleG/Guppycur/TormentedEmu | Includes civilian, police, nurse and other models; some special entities. Count includes variants. |
| NPCXS SpiderPack | 15 | Xyth; expansion by arramus | Three base spider families with mini, feral, radiated and queen variants. NPC prefab/animal controllers; dependencies need validation. |

Core War3zuk XML also includes giant/infected animal variants, hornets, vipers, TitanSpider and zombie bears. Its 189 entity-class declarations also include vehicles, so this is not a zombie count.

## Permissions and compatibility

The installed ReadMe.md and Mods/War3zuk AIO Overhaul/License Information.md require express permission for extraction into other packs and redistribution. Do not publish its models/code/XML in our GitHub releases on the assumption that private play or public download grants reuse. Author-posted terms: https://community.thefunpimps.com/threads/war3zuk-alpha-21-all-in-one-stable.34158/

Separate packs need their own original distribution and terms checked. Local copies may be edited by the overhaul; lack of a license file is not reuse permission. Some ModInfo versions refer to older releases, so those labels alone do not establish V3.4 compatibility.

## Proposed order

1. Obtain original standalone zombie sources and verify redistribution/modification terms or use separately installed dependencies.
2. Validate model bundles, physics bodies, hand items, loot, buffs and optional SCore/NPC dependencies against V3.4 b10.
3. Start with a small selection of ordinary zombie appearances and conservative spawn weights.
4. Add wildlife and rare stronger variants later, with options and progression gates. Keep giant/supernatural enemies optional.

Continue crafting-practice coverage first; enemy work is a later roadmap stage.
