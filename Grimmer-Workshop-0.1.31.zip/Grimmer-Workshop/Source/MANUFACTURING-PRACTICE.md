# Fixtures and manufacturing practice — 0.1.22

52 new skill/item routes finish this recipe coverage pass. All 578 earlier routes and their awards remain unchanged. Native recipes retain their ingredients, outputs and unlock requirements; 15 new recipe tag patches only add the existing Construction crafting-time benefit to newly mapped building crafts.

New Construction routes include safes, a secure cabinet, appliances, candles, lamps, a clock, hay bales, land-claim blocks, a decorative pumpkin, paintbrushes, torches and nails. Wiring tools and flashlights train Electrician. Armour kits and crafted biome protection badges train Armor. Grace corn seeds train Seeds. Remaining loose-board traps, iron spikes, glass traps and tin mines train Traps; Molotovs train Explosives.

| Manufacturing | Skill | Base practice per actual output |
| --- | --- | ---: |
| Paper | Workstations | 0.02 per sheet |
| Nails | Construction | 0.005 per nail |
| Forged iron / steel | Workstations | 0.05 / 0.1 per bar |
| Glue | Workstations | 0.5 per bottle |
| Metal pipe | Workstations | 0.05 per pipe |
| Bullet casing/tip/buckshot | Workstations | 0.005 per component |
| Iron / steel arrowhead | Workstations | 0.01 / 0.02 per component |
| Scope lens / empty jar | Workstations | 0.5 / 0.1 per item |
| Cooking pot or grill | Workstations | 6 per item |
| Bicycle / minibike / motorcycle / 4x4 / gyrocopter assembly | Vehicles | 12 / 20 / 30 / 40 / 50 per vehicle |

All rates are before learning-speed, quality and relevance scaling. A ten-sheet paper recipe gives 0.2 base practice. Primitive material awards diminish as the skill advances. Normal scrap processing still gives no practice for non-quality raw materials; raw forge withdrawal/refund recipes have no routes. Manufacturing consumes its normal ingredients and fuel; no new recipe or cheaper reverse conversion is introduced.

The lockpick bundle manufactures 50 picks. It receives exactly the same per-pick route as ordinary lockpicks, expanded to 50 before level calculations; opening it gives no second crafting award. Existing book requirements are retained.

Native forge queue inspection confirms completed output records the actual recipe count in AddCraftComplete. Opening the station claims completion credit through the existing native path; merely standing near a station is not the claim action.

18 deliberate non-wildcard exclusions remain: five raw forge refunds, eight resource-packing bundles, meat packing, three terrain conversions and grass seed conversion. Dynamic wildcard scrapping is excluded too. See RECIPE-COVERAGE-AUDIT.md and its CSV.

Live checks: candle/safe Construction awards, glue/paper/forge manufacturing awards after opening the station, completed vehicle assembly, no claim on pickup/redeployment or bundle opening, and saved progress persistence.
