using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace GrimmerWorkshop
{
    public static class StoragePickup
    {
        public const string Command = "Pick up empty storage";
        public static bool Eligible(string name)
        {
            return name == "cntWoodWritableCrate" || name == "cntIronWritableCrate" || name == "cntSteelWritableCrate";
        }
        public static bool CanTake(WorldBase world, Vector3i position, EntityPlayerLocal player)
        {
            if (player == null || player != Workshop.Player() || world == null) return false;
            var value = world.GetBlock(position);
            if (!Eligible(value.Block.GetBlockName()) || value.damage != 0) return false;
            var tile = world.GetTileEntity(position) as TileEntityComposite;
            if (tile == null || !tile.PlayerPlaced || !tile.LocalPlayerIsOwner || tile.IsUserAccessing()) return false;
            var storage = tile.GetFeature<TEFeatureStorage>();
            var lockable = tile.GetFeature<TEFeatureLockable>();
            if (storage == null || !storage.IsEmpty() || lockable == null || lockable.IsLocked()) return false;
            var center = new Vector3(position.x + .5f, position.y + .5f, position.z + .5f);
            return (center - player.position).sqrMagnitude <= 36;
        }
    }
    [HarmonyPatch(typeof(BlockCompositeTileEntity), "GetBlockActivationCommands")]
    public static class StoragePickupMenuPatch
    {
        public static void Postfix(WorldBase __0, BlockValue __1, Vector3i __2, ref BlockActivationCommand[] __result)
        {
            try {
                if (Workshop.Player() == null || !StoragePickup.Eligible(__1.Block.GetBlockName())) return;
                var tile = __0.GetTileEntity(__2) as TileEntityComposite;
                if (tile == null || !tile.PlayerPlaced || !tile.LocalPlayerIsOwner) return;
                var commands = new List<BlockActivationCommand>(__result ?? BlockActivationCommand.Empty);
                commands.Add(new BlockActivationCommand(StoragePickup.Command, "hand", StoragePickup.CanTake(__0, __2, Workshop.Player()), false, null));
                __result = commands.ToArray();
            } catch (Exception error) { Log.Error("[Grimmer Workshop] Storage pickup menu: " + error.Message); }
        }
    }
    [HarmonyPatch(typeof(BlockCompositeTileEntity), "OnBlockActivated", new Type[] { typeof(string), typeof(WorldBase), typeof(Vector3i), typeof(BlockValue), typeof(EntityPlayerLocal) })]
    public static class StoragePickupActivatePatch
    {
        public static bool Prefix(string __0, WorldBase __1, Vector3i __2, BlockValue __3, EntityPlayerLocal __4, ref bool __result)
        {
            if (__0 != StoragePickup.Command) return true;
            __result = true;
            try {
                if (!StoragePickup.CanTake(__1, __2, __4)) {
                    GameManager.ShowTooltip(__4, "Empty, repair and unlock your storage before picking it up. Close its inventory first.", false, false, 4);
                    return false;
                }
                Block.TakeItemWithTimer(__2, __1.GetBlock(__2), __4, 2, delegate(Vector3i p, EntityPlayerLocal player) { return StoragePickup.CanTake(__1, p, player); });
            } catch (Exception error) { Log.Error("[Grimmer Workshop] Storage pickup: " + error); }
            return false;
        }
    }
    // Native completion checks damage, block identity and use state, but not
    // storage contents or ownership. Recheck those after the timer too.
    [HarmonyPatch(typeof(Block), "TakeItemWithTimerDone")]
    public static class StoragePickupCompletePatch
    {
        public static bool Prefix(TimerEventData __0)
        {
            try {
                var args = __0.Data as object[];
                if (args == null || args.Length < 3 || !(args[0] is BlockValue)) return true;
                var original = (BlockValue)args[0];
                if (!StoragePickup.Eligible(original.Block.GetBlockName())) return true;
                var player = args[2] as EntityPlayerLocal;
                bool valid = StoragePickup.CanTake(GameManager.Instance.World, (Vector3i)args[1], player);
                if (!valid && player != null) GameManager.ShowTooltip(player, "Storage changed or cannot be picked up. Nothing was removed.", false, false, 3);
                return valid;
            } catch (Exception error) { Log.Error("[Grimmer Workshop] Storage pickup completion: " + error); return false; }
        }
    }
}
