using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace GrimmerWorkshop
{
    // Keep vanilla completion storage, persistence and claiming. Only refine
    // the existing item-id comparison so queued qualities cannot share credit.
    [HarmonyPatch(typeof(TileEntityWorkstation), "AddCraftComplete")]
    public static class WorkstationCredit
    {
        public static bool SameCreditItem(ItemValue left, ItemValue right)
        {
            return left != null && right != null && left.GetItemId() == right.GetItemId() && left.Quality == right.Quality;
        }

        public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
        {
            var source = instructions.ToList();
            int matches = 0;
            for (int i = 0; i < source.Count; i++)
            {
                var method = source[i].operand as MethodInfo;
                if (method != null && method.DeclaringType == typeof(ItemValue) && method.Name == "GetItemId" &&
                    i + 3 < source.Count && source[i+1].opcode == OpCodes.Ldarg_2 &&
                    Object.Equals(source[i+2].operand, method) &&
                    (source[i+3].opcode == OpCodes.Bne_Un || source[i+3].opcode == OpCodes.Bne_Un_S))
                {
                    if (source[i+1].labels.Count != 0 || source[i+2].labels.Count != 0 || source[i+1].blocks.Count != 0 || source[i+2].blocks.Count != 0)
                        throw new InvalidOperationException("Workstation completion comparison has unexpected branch targets.");
                    var load = new CodeInstruction(source[i]);
                    load.opcode = OpCodes.Ldarg_2; load.operand = null;
                    yield return load;
                    yield return new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(WorkstationCredit), "SameCreditItem"));
                    var branch = new CodeInstruction(source[i+3]);
                    branch.opcode = OpCodes.Brfalse;
                    yield return branch;
                    matches++; i += 3;
                }
                else yield return source[i];
            }
            if (matches != 1) throw new InvalidOperationException("Game workstation completion layout changed; expected one item comparison.");
        }
    }
}
