# Gunsmith Bench - 0.1.27 testing candidate

An original specialist station using the native workbench model and interface. It is a practical first step toward a larger weapon-crafting system; this release adds no external weapon models or new repair/weapon-assembly mechanics.

## Progression and purpose

- Unlock: Workstations level 20, through normal practice; no magazine required.
- Craft at a workbench using 1 additional workbench item, 10 forged iron, 10 mechanical parts and 4 duct tape. Base craft time 90 seconds.
- Building the bench awards 12 base Workstations practice, full through level 40, then existing diminishing relevance up to the skill cap of 75.
- Supports 118 alternate recipes: eligible vanilla workbench weapon-family recipes, ammunition, appropriate attachments and our original melee grips.
- Specialist recipes take 15% less time after native perks/settings are applied. No additional ingredient discount or practice multiplier.
- Original recipes remain available at their original stations. Unlocks, ingredients, outputs, quality costs, tags and recipe effects are copied intact. Primitive inventory-only recipes, armour, vehicles, engine restoration and the drone are excluded from this specialist station.
- Completed crafts earn their normal skill practice and provenance using the existing native workstation completion/claim mechanism. Ammunition bundles retain their existing normalized practice; opening them is not another craft.

The bench needs no fuel. Native workbench placement footprint, durability, reclaim rules and output queue are retained. The recipe consumes an additional workbench item; it does not consume the station being used to make it. The icon has a different tint, but the physical model is the normal workbench.

## Implementation and saves

The launch helper builds companion modlet `ZZZ_GrimmerGunsmith`: block definition, specialist recipes, unlock effect and localization. The normal launcher invokes it through the existing attachment/configuration entry point, so old updater allowlists still accept the same 20 runtime files. No Python is required on the player's machine.

WorkstationWindow explicitly reuses `workstation_workbench`. Native SetTileEntity assigns the actual station name dynamically. Native ItemActionEntryCraft.OnActivated uses GetRecipeCraftTime, where a narrowly scoped postfix applies the .85 factor only to the Gunsmith crafting area in solo play. The stored queue time and saved completion records remain native.

The companion folder remains when the previous launch helper runs, keeping placed station identity and recipe definitions available after a partial rollback. The speed bonus disappears when rolling back to a DLL without this feature; no item/queue migration is attempted. Keep companion folders installed while a world contains their items/stations.

Existing 633 practice rules and custom recipes are unchanged; one bench route brings the total to 634. The 118 station variants reuse existing output rules rather than award additional practice.

## Verification

Production game build, 11 focused timing checks and all regressions pass. Configuration tests compare every station recipe to its actual source, including nested quality cost effects and learnable tags; verify the level-20 gate, bench cost, native model/footprint, localization and preservation of all old routes/custom recipes. Four installed-game IL/UI checks confirm the actual craft action uses the timer hook, station identity is dynamic, window override is supported and the reused UI exists. Running the previous launch generator leaves the companion station definition intact.

Configuration test arguments: `python Tests/GunsmithConfigTests.py GAME CURRENT_MOD PREVIOUS_0126_MOD GENERATED_FIXTURE`.

Live checks remain in PLAYTEST-CHECKLIST.md: locked/unlocked recipe at 19/20, placement/opening, displayed and real queue times, quality costs, recipe requirements, claim-on-open practice, cancellation, persistence and native reclaim. Do not label these confirmed until tested in game.
