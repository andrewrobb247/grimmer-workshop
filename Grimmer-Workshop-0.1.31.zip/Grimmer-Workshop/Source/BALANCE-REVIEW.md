# Progression balance review

18 November 2026, current 0.1.7 implementation and default settings. This is a code/data review, not confirmation of live pacing. No rates changed.

## Verified formulas

Practice needed for the next level is 40 + 0.5 * (current level - 1). At levels 1, 25, 50 and 99 this is 40, 52, 64.5 and 89. Total practice from level 1 to 100 is 6,385.5, before category caps.

Craft reward per completed recipe batch is base credit * (1 + (unlock level - 1) / 25) * recipe relevance * quality multiplier * learning speed. Quantity is normalised by recipe output count, so a batch yielding several items does not accidentally earn several batches of practice.

| Quality | Multiplier | Stone axe craft at full relevance | Scrap of that newly crafted axe |
| --- | --- | --- | --- |
| 1 | 1 | 10 | 1 |
| 2 | 1.25 | 12.5 | 1.25 |
| 3 | 1.5 | 15 | 1.5 |
| 4 | 1.75 | 17.5 | 1.75 |
| 5 | 2 | 20 | 2 |
| 6 | 2.5 | 25 | 2.5 |

These are comparisons at equal skill/relevance, not a claim that quality 6 is available at level 1. The player's quality-3 observations match the formula.

Outdated recipes fall towards a 10% relevance floor. Higher technology rewards increase with their unlock level. Crafting costs themselves do not directly determine practice: quality and unlock tier are proxies. Cost-reduction perks therefore do not reduce practice. Individual expensive/cheap recipes still need comparison during play.

## Early workstation route

Campfires award 10 Workstations practice per craft up to skill 4. Starting from zero, reaching 4 takes 121.5 practice: 13 campfires if using only that route. This is a fallback route, not a desirable ordinary-play target.

Charred meat awards 5 Workstations practice per recipe batch up to skill 10 and requires no pot. It also trains Food up to level 2. Block upgrading provides a smaller additional Workstations route. The cooking path can therefore be tested before finding a pot, once meat is available.

## Risks to watch

- Craft/scrap cycles still award positive practice by design, but player-made scrap is only 10% of equivalent crafting credit. Materials lost during the cycle are the limiting cost; this is not proof that every recipe's material economy is exploit-free.
- Categories without passive use hooks may advance more slowly than frequently used tools/weapons. Their recipe routes exist, but normal-play pacing is unconfirmed.
- Bulk component crafting could outperform expensive equipment for some skills. Compare material/time cost before raising rewards globally.
- A recipe reaching its training cap can stop awarding practice before a player notices; the skill screen's training hint should direct them to the next route.

## Decision

Keep existing rates while collecting the specific checks in PLAYTEST-CHECKLIST.md. Prefer adjusting an outlying recipe/category after evidence over increasing every skill's speed. Next practical feature: accessible deposit/refill buttons for the existing storage actions, preserving vanilla locking.

Follow-up: the 0.1.13 pass in BALANCE-AUDIT.md identified and corrected rapid fuel refining. The no-rate-change decision above describes the earlier review, before that outlier was measured.
