using System.Collections.Generic;
using HarmonyLib;

namespace GrimmerWorkshop
{
    public static class RecipeVariants
    {
        public static bool IsWorkshopAlternate(Recipe recipe)
        {
            return recipe != null && (recipe.craftingArea == "grimmerGunsmithBench" || recipe.craftingArea == "grimmerCookingStove");
        }
        public static List<Recipe> ForDisplay(List<Recipe> visible, string workstation = null)
        {
            if (visible == null) return null;
            var originals = new HashSet<int>();
            var preferred = new HashSet<int>();
            string originalArea = workstation == "grimmerGunsmithBench" ? "workbench" : workstation == "grimmerCookingStove" ? "campfire" : null;
            foreach (var recipe in visible)
                if (recipe != null && recipe.itemValueType > 0) {
                    if (!IsWorkshopAlternate(recipe)) originals.Add(recipe.itemValueType);
                    else if (originalArea != null && recipe.craftingArea == workstation) preferred.Add(recipe.itemValueType);
                }
            var result = new List<Recipe>();
            foreach (var recipe in visible) {
                if (IsWorkshopAlternate(recipe) && recipe.craftingArea != workstation && originals.Contains(recipe.itemValueType)) continue;
                if (recipe != null && originalArea != null && recipe.craftingArea == originalArea && preferred.Contains(recipe.itemValueType)) continue;
                result.Add(recipe);
            }
            return result;
        }
    }
    [HarmonyPatch(typeof(XUiC_RecipeList), "BuildRecipeInfosList")]
    public static class RecipeVariantsDisplayPatch
    {
        public static void Prefix(XUiC_RecipeList __instance, ref List<Recipe> ___recipes)
        {
            if (Workshop.Player() != null) ___recipes = RecipeVariants.ForDisplay(___recipes, __instance.Workstation);
        }
    }
}
