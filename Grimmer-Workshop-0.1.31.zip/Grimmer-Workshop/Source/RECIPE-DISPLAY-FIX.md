# Specialist recipe display fix - 0.1.30

Player reported repeated vanilla weapons and attachments in the general crafting list after the Arsenal installation. The repeats are Workshop's alternate Gunsmith Bench recipes, not duplicated saved items. Cooking Stove alternatives have the same presentation issue.

Before native BuildRecipeInfosList builds visible rows, a narrow display-only filter copies the current visible recipe list. If both a native source recipe and our specialist variant produce the same item, the general view prefers the source recipe. At a Gunsmith Bench or Cooking Stove, it instead prefers the matching specialist recipe, so even the all-recipes view retains a craftable choice with the correct speed bonus.

The filter recognises only the exact Workshop station areas grimmerGunsmithBench and grimmerCookingStove. Other mods' alternatives, legitimate vanilla alternatives, different outputs, and specialist-only lists are preserved. It does not delete item definitions, recipes, queued crafts, inventory or author pack files. It never modifies the shared global recipe list. Existing skills, unlocks, costs, quality and practice are unchanged.

17 focused display checks cover general/station/all-recipes views, reversed ordering, source preservation, other mod alternatives, vanilla forge alternatives, unresolved/null entries and solo guard. Existing regressions and production compilation pass. Installed-game inspection confirms the recipes field, native list-builder access and station getter used by the Harmony patch.

Live checks: general search has one row per original/Workshop alternate pair; specialist stations retain the correct recipe and speed; ordinary alternatives and Arsenal weapons remain available. Requires closing and relaunching after update. No world reset.
