using System;
using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using UnityEngine;

namespace GrimmerWorkshop
{
    public static class VehicleInspection
    {
        // Native radial block commands dispatch their text, not eventName.
        public const string Command = "Inspect vehicle parts";
        public const string InspectedCommand = "Vehicle parts already inspected";
        static WorldBase cachedWorld;
        static VehicleInspectionState state;
        static readonly System.Random random = new System.Random();
        static VehicleInspectionState State(WorldBase world)
        {
            if (state == null || !object.ReferenceEquals(world, cachedWorld)) {
                var loaded = new VehicleInspectionState(Path.Combine(GameIO.GetSaveGameDir(), "GrimmerVehicleInspections.xml"));
                cachedWorld = world; state = loaded;
            }
            return state;
        }
        public static bool Resolve(BlockCompositeTileEntity block, ref Vector3i position, ref BlockValue value, out TileEntityComposite tile)
        {
            tile = null;
            if (Workshop.Player() == null || !block.TryGetParentBlockAndTileEntity(ref position, ref value, out tile)) return false;
            return !tile.PlayerPlaced && VehicleInspectionState.EligibleName(value.Block.GetBlockName()) && tile.GetFeature<TEFeatureStorage>() != null;
        }
        public static bool Available(WorldBase world, Vector3i position, TileEntityComposite tile)
        {
            var locked = tile.GetFeature<TEFeatureLockable>();
            return !tile.IsUserAccessing() && (locked == null || !locked.IsLocked()) &&
                !State(world).Contains(VehicleInspectionState.Key(position.x, position.y, position.z));
        }
        public static bool CanShowMenu(TileEntityComposite tile)
        {
            var locked = tile.GetFeature<TEFeatureLockable>();
            return !tile.IsUserAccessing() && (locked == null || !locked.IsLocked());
        }
        public static string MenuCommand(WorldBase world, Vector3i position)
        {
            return State(world).Contains(VehicleInspectionState.Key(position.x, position.y, position.z)) ? InspectedCommand : Command;
        }
        static ItemStack Part(string name, int count, int quality)
        {
            var item = ItemClass.GetItem(name, false);
            if (item == null || item.IsEmpty()) throw new InvalidDataException("Missing vehicle part: " + name);
            if (item.HasQuality) item.Quality = (ushort)quality;
            return new ItemStack(item, count);
        }
        public static void Inspect(WorldBase world, BlockCompositeTileEntity block, Vector3i position, BlockValue value, EntityPlayerLocal player)
        {
            TileEntityComposite tile;
            if (player != Workshop.Player() || !Resolve(block, ref position, ref value, out tile)) return;
            if (!Available(world, position, tile)) {
                GameManager.ShowTooltip(player, "Vehicle already inspected, locked or in use.", false, false, 3); return;
            }
            var center = new Vector3(position.x + .5f, position.y + .5f, position.z + .5f);
            if ((player.position - center).sqrMagnitude > 64 || player.PlayerUI == null || player.PlayerUI.xui == null) return;
            int condition = VehicleInspectionState.Condition(value.Block.GetBlockName());
            var parts = new List<ItemStack>();
            parts.Add(Part("resourceMechanicalParts", random.Next(1, condition == 0 ? 5 : 3), 1));
            parts.Add(Part("resourceElectricParts", random.Next(1, 3), 1));
            int componentRoll = random.Next(100);
            string working = VehicleInspectionState.WorkingPart(componentRoll, condition);
            if (working != null) parts.Add(Part(working, 1, random.Next(1, 4)));
            bool recoverable = VehicleInspectionState.RecoverableEngine(componentRoll, condition);
            if (recoverable) parts.Add(Part("grimmerRecoveredEngine", 1, 1));
            string result = "";
            foreach (var part in parts) result += part.itemValue.ItemClass.GetItemName() + ":" + part.count + ":" + part.itemValue.Quality + ";";
            if (!State(world).Reserve(VehicleInspectionState.Key(position.x, position.y, position.z), result)) return;
            foreach (var part in parts) {
                player.PlayerUI.xui.PlayerInventory.AddItem(part, true);
                if (part.count > 0) GameManager.Instance.ItemDropServer(part, player.position, Vector3.zero, player.entityId, 60, false);
            }
            Activities.Award("craftingVehicles", 1);
            Activities.Award("craftingSalvageTools", .5);
            GameManager.ShowTooltip(player, recoverable ? "Inspection: damaged engine recovered. Rebuild it at a workbench. Vehicle can still be searched and salvaged." :
                working == null ? "Inspection: recovered small parts. Vehicle can still be searched and salvaged." :
                "Inspection: usable component recovered! Vehicle can still be searched and salvaged.", false, false, 5);
        }
    }

    [HarmonyPatch(typeof(BlockCompositeTileEntity), "HasBlockActivationCommands")]
    public static class VehicleInspectionMenuGatePatch
    {
        public static void Postfix(BlockCompositeTileEntity __instance, WorldBase __0, BlockValue __1, Vector3i __2, ref bool __result)
        {
            if (__result) return;
            try {
                TileEntityComposite tile;
                if (VehicleInspection.Resolve(__instance, ref __2, ref __1, out tile) &&
                    VehicleInspection.CanShowMenu(tile)) __result = true;
            } catch (Exception error) { Log.Error("[Grimmer Workshop] Inspection menu gate: " + error.Message); }
        }
    }

    [HarmonyPatch(typeof(BlockCompositeTileEntity), "GetBlockActivationCommands")]
    public static class VehicleInspectionCommandsPatch
    {
        public static void Postfix(BlockCompositeTileEntity __instance, WorldBase __0, BlockValue __1, Vector3i __2, ref BlockActivationCommand[] __result)
        {
            try {
                TileEntityComposite tile;
                if (!VehicleInspection.Resolve(__instance, ref __2, ref __1, out tile)) return;
                var commands = new List<BlockActivationCommand>(__result ?? BlockActivationCommand.Empty);
                bool available = VehicleInspection.CanShowMenu(tile);
                commands.Add(new BlockActivationCommand(VehicleInspection.MenuCommand(__0, __2), "search", available, false, null));
                __result = commands.ToArray(); // Never mutate the block's shared command cache.
            } catch (Exception error) { Log.Error("[Grimmer Workshop] Inspection menu: " + error.Message); }
        }
    }
    [HarmonyPatch(typeof(BlockCompositeTileEntity), "OnBlockActivated", new Type[] { typeof(string), typeof(WorldBase), typeof(Vector3i), typeof(BlockValue), typeof(EntityPlayerLocal) })]
    public static class VehicleInspectionActivatePatch
    {
        public static bool Prefix(BlockCompositeTileEntity __instance, string __0, WorldBase __1, Vector3i __2, BlockValue __3, EntityPlayerLocal __4, ref bool __result)
        {
            if (__0 != VehicleInspection.Command && __0 != VehicleInspection.InspectedCommand) return true;
            __result = true;
            try { VehicleInspection.Inspect(__1, __instance, __2, __3, __4); }
            catch (Exception error) {
                Log.Error("[Grimmer Workshop] Vehicle inspection: " + error);
                GameManager.ShowTooltip(__4, "Inspection failed. Check the Workshop log before trying again.", false, false, 4);
            }
            return false;
        }
    }
}
