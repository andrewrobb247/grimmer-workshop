# Attachment practice — 0.1.21

All 75 vanilla attachment recipes now train exactly one crafting skill. Existing attachment recipes, materials, schematics, installation restrictions and effects are unchanged. The two original Workshop grips retain their previous practice routes.

| Attachment family | Skill |
| --- | --- |
| Pockets | Backpacks |
| Armour fittings/plating | Armor |
| Helmet light, weapon light, laser and reflex sight | Electrician |
| Bow parts | Bows |
| Shotgun choke, duckbill, tube extension and sawed-off barrel | Shotguns |
| Club barbs, spikes and chains | Clubs |
| Tool fuel tanks, axe/shovel/mining fittings | Harvesting Tools |
| Drone mods and baton repulsor | Robotics |
| Vehicle mods | Vehicles |
| Universal grips, fittings, scopes and shared weapon parts | Workstations |

Base practice per attachment: simple pocket/basic plating 4; ordinary parts 6; selected advanced or steel-heavy parts 8; legendary-material pocket 12; cosmetic cigar accessory 2 Workstations practice. Quality multipliers and relevance decay still apply. Base full-credit usefulness lasts through 25, or 40 for advanced awards. Actual maximum is the relevant crafting skill maximum.

Only crafting and the existing eligible equipment-scrap path award practice. Installing, removing or swapping an attachment does not award practice. Shared attachments never award the full credit to every compatible weapon category.

Validation: 503 earlier routes unchanged; 75 new routes, exactly one per attachment output. Native recipe XML matches 0.1.20 byte-for-byte. Skill mappings, caps, base awards and custom grip preservation checked by Tests/AttachmentPracticeTests.py.
