using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;

namespace GrimmerWorkshop
{
    // A conservative, world-local depletion ledger. Downgrades and POI resets at
    // the same position deliberately do not provide another parts payout.
    public sealed class VehicleInspectionState
    {
        readonly string path;
        readonly Dictionary<string, string> inspected = new Dictionary<string, string>();
        public VehicleInspectionState(string file)
        {
            path = file;
            if (!File.Exists(path)) return;
            var root = XDocument.Load(path).Root;
            if (root == null || root.Name != "vehicleInspections" || (int?)root.Attribute("schema") != 1)
                throw new InvalidDataException("Unknown vehicle inspection ledger.");
            foreach (var entry in root.Elements("vehicle")) {
                string key = (string)entry.Attribute("position"), result = (string)entry.Attribute("result");
                if (string.IsNullOrEmpty(key) || string.IsNullOrEmpty(result) || inspected.ContainsKey(key))
                    throw new InvalidDataException("Invalid vehicle inspection entry.");
                inspected.Add(key, result);
            }
        }
        public static string Key(int x, int y, int z) { return x + "," + y + "," + z; }
        public bool Contains(string key) { return inspected.ContainsKey(key); }
        public bool Reserve(string key, string result)
        {
            if (inspected.ContainsKey(key)) return false;
            var root = new XElement("vehicleInspections", new XAttribute("schema", 1));
            foreach (var entry in inspected)
                root.Add(new XElement("vehicle", new XAttribute("position", entry.Key), new XAttribute("result", entry.Value)));
            root.Add(new XElement("vehicle", new XAttribute("position", key), new XAttribute("result", result)));
            string temporary = path + ".new";
            // Commit before granting anything. IO failures leave the vehicle available
            // but grant nothing; a crash after commit can lose a reward, never duplicate it.
            using (var stream = new FileStream(temporary, FileMode.Create, FileAccess.Write, FileShare.None)) {
                new XDocument(root).Save(stream);
                stream.Flush(true);
            }
            if (File.Exists(path)) File.Replace(temporary, path, null);
            else File.Move(temporary, path);
            inspected.Add(key, result);
            return true;
        }
        public static bool EligibleName(string name)
        {
            if (string.IsNullOrEmpty(name) || name.IndexOf("Helper", StringComparison.OrdinalIgnoreCase) >= 0) return false;
            return name.StartsWith("cntCar03Sedan", StringComparison.Ordinal) ||
                name.StartsWith("cntPoliceCar01", StringComparison.Ordinal) ||
                name.StartsWith("cntBus", StringComparison.Ordinal) || name == "cntAmbulanceTruck01" ||
                name.StartsWith("cntMinivan", StringComparison.Ordinal) ||
                name.StartsWith("cntPickupTruck", StringComparison.Ordinal) ||
                name.StartsWith("cntSemiTruck", StringComparison.Ordinal) ||
                name.StartsWith("cntFireTruck", StringComparison.Ordinal) ||
                name.StartsWith("cntServiceTruck", StringComparison.Ordinal) ||
                name.StartsWith("cntBoxTruck", StringComparison.Ordinal) ||
                name.StartsWith("cntArmyTruck", StringComparison.Ordinal) ||
                name.StartsWith("cntFarmTruck", StringComparison.Ordinal);
        }
        public static int Condition(string name)
        {
            return name.IndexOf("Damage2", StringComparison.OrdinalIgnoreCase) >= 0 ? 2 :
                name.IndexOf("Damage1", StringComparison.OrdinalIgnoreCase) >= 0 ? 1 : 0;
        }
        public static string WorkingPart(int roll, int condition)
        {
            if (roll < 0 || roll >= 100 || condition < 0 || condition > 2) throw new ArgumentOutOfRangeException();
            if (condition == 2) return null;
            if (condition == 1) roll *= 2;
            return roll < 4 ? "smallEngine" : roll < 10 ? "carBattery" : roll < 18 ? "vehicleWheels" : null;
        }
        public static bool RecoverableEngine(int roll, int condition)
        {
            if (roll < 0 || roll >= 100 || condition < 0 || condition > 2) throw new ArgumentOutOfRangeException();
            if (condition == 2) return false;
            if (condition == 1) roll *= 2;
            // Separate outcomes: never a working component and a damaged engine together.
            return roll >= 18 && roll < 36;
        }
    }
}
