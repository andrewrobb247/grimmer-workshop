# Cooking Stove - 0.1.28

Original, fuel-burning kitchen workstation using the game's wood-burning stove model. No external mod assets or code are included.

## Player progression

Unlock at Food level 20 through normal gameplay practice. Craft at a workbench using 10 forged iron, 4 short iron pipes, 4 mechanical parts and 10 small stones. Base construction time is 60 seconds. Constructing it awards 12 base Workstations practice, full through level 40, with existing diminishing relevance thereafter to the skill cap of 75.

The stove supports all 49 native campfire recipe variants in 25% less time after native perks/settings. It still consumes normal campfire fuel and requires the original pot, grill or beaker for each recipe. Ingredients, recipe unlocks, outputs, tags and quality effects are unchanged. Install cooking tools separately; crafting the stove does not include them. Recipe completion gives the same Food/other practice as the original output, including existing early secondary Workstations practice. No duplicate practice is added for using the stove.

Original campfire recipes remain available. This is an enclosed wood-burning stove, not an electric appliance. Heat-map generation and nearby campfire warmth remain native. The open ground-fire particle and contact-burning buff are removed; no fuel-free crafting or power simulation. Native fuel controls, queue/output/save handling and reclaim requirements remain in use. The station has 500 durability and is repaired with forged iron.

## Implementation and rollback

Launch configuration generates companion modlet ZZZ_GrimmerCooking with the station, 49 source-preserving recipe variants, Food-20 unlock effect and localization. The block clones the native campfire's functional properties, explicitly reuses workstation_campfire UI, and uses the native wood-burning stove visual model. No Python is needed on players' machines.

The existing recipe-time postfix applies .75 only to the stove crafting area in solo play. It continues to apply .85 to the Gunsmith Bench; ordinary stations are unchanged. Native craft action uses this computed time when enqueueing. Fuel/queue logic is not replaced.

The companion definition is retained when an older launcher helper runs, preserving placed station identity. Rolling back to a DLL without the stove time factor removes its speed bonus, but does not delete the saved station. Do not remove companion folders from a world that contains their items/blocks.

Total practice routes: 635. All 634 previous routes and custom recipes unchanged; the new station-construction rule is the only addition. The 49 alternate cooking variants reuse output practice rules.

## Validation

Production build and regression tests pass, including 17 specialist timing checks. Configuration checks compare all 49 stove recipes to installed native definitions, including nested effects, ingredient costs, tool requirements and learnable tags; verify fuel/tools modules, model, Food-20 gate, construction cost, localization and preservation of all previous routes/custom recipes. Previous launcher-helper execution retains the companion definition. Existing native workstation credit checks cover completion delivery/claiming.

Configuration test: python Tests/CookingStoveTests.py GAME CURRENT_MOD PREVIOUS_0127_MOD GENERATED_FIXTURE

Live checks remain in PLAYTEST-CHECKLIST.md: recipe gate, placement/model/collision, opening UI, tool insertion, fuel start/stop, actual timing, completion practice, cancellation, queue/save persistence and native reclaim. Until checked in-game these behaviours are implementation expectations, not player-confirmed results.
