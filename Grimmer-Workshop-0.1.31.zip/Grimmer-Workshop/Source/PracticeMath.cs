using System;

namespace GrimmerWorkshop
{
    public static class PracticeMath
    {
        // Bundle contents are counted before applying per-level relevance.
        // Saturation is safe: level caps bound the amount that can be credited.
        public static int NormalizedOutput(int count, int units)
        {
            if(count<=0 || units<1 || units>10000) return 0;
            return (int)Math.Min(int.MaxValue,(long)count*units);
        }

        public static double QualityMultiplier(int quality)
        {
            switch (quality) {
                case 2: return 1.25;
                case 3: return 1.5;
                case 4: return 1.75;
                case 5: return 2;
                case 6: return 2.5;
                default: return 1;
            }
        }

        public static double Required(int level, double baseCost, double growth)
        {
            return Math.Max(1, baseCost + Math.Max(0, level - 1) * growth);
        }

        public static double Credit(int outputCount, int recipeOutput, int unlockLevel, int currentLevel, int usefulUntil, double baseCredit)
        {
            if (outputCount <= 0 || recipeOutput <= 0) return 0;
            double relevance = currentLevel <= usefulUntil ? 1 : Math.Max(0.1, 1.0 / (1 + (currentLevel - usefulUntil) / 5.0));
            return outputCount / (double)recipeOutput * baseCredit * (1 + Math.Max(0, unlockLevel - 1) / 25.0) * relevance;
        }

        // Evaluate relevance again whenever a completed batch raises a level.
        // Skip groups that cannot cross a level, keeping large queues bounded
        // by level transitions rather than the number of crafted items.
        public static double CreditAcrossLevels(int outputCount, int recipeOutput, int unlockLevel, int currentLevel,
            int usefulUntil, double baseCredit, double multiplier, double savedPractice, int maximum, double cost, double growth)
        {
            if (outputCount <= 0 || recipeOutput <= 0 || currentLevel >= maximum || baseCredit <= 0 || multiplier <= 0 ||
                double.IsNaN(savedPractice) || double.IsInfinity(savedPractice)) return 0;
            double batches = outputCount / (double)recipeOutput, practice = Math.Max(0, savedPractice), total = 0;
            int level = currentLevel;
            while (batches > 0 && level < maximum)
            {
                double credit = Credit(recipeOutput, recipeOutput, unlockLevel, level, usefulUntil, baseCredit) * multiplier;
                if (credit <= 0 || double.IsNaN(credit) || double.IsInfinity(credit)) return 0;
                double whole = Math.Floor(batches);
                double group = whole >= 1 ? Math.Min(whole, Math.Max(1, Math.Ceiling((Required(level,cost,growth)-practice)/credit))) : batches;
                double amount = group * credit;
                total += amount; practice += amount; batches -= group;
                while (level < maximum && practice >= Required(level,cost,growth))
                {
                    practice -= Required(level,cost,growth); level++;
                }
            }
            return total;
        }

        public static int MoveCount(int sourceCount, int destinationCount, int capacity)
        {
            return Math.Max(0, Math.Min(sourceCount, capacity - destinationCount));
        }
    }
}
