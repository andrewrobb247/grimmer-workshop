# Recipe coverage audit — 0.1.23

632 skill/item practice routes across 25 skills. The non-wildcard vanilla recipe audit has 18 intentional exclusions; there are no unreviewed gaps in that set. Dynamic wildcard scrapping remains excluded too.

| Item | Reason |
| --- | --- |
| resourceClayLump | Raw forge refund |
| resourceRockSmall | Raw forge refund |
| resourceScrapBrass | Raw forge refund |
| resourceScrapIron | Raw forge refund |
| resourceScrapLead | Raw forge refund |
| resourceRockSmallBundle | Resource packing |
| resourceWoodBundle | Resource packing |
| resourceScrapIronBundle | Resource packing |
| resourceOilShaleBundle | Resource packing |
| resourcePotassiumNitratePowderBundle | Resource packing |
| resourceLeadBundle | Resource packing |
| resourceScrapBrassBundle | Resource packing |
| resourceCoalBundle | Resource packing |
| foodRawMeatBundle | Meat packing |
| plantedtreeGrassSeed1 | Grass conversion |
| terrDestroyedStone | Terrain conversion |
| terrDirt | Terrain conversion |
| terrTopSoil | Terrain conversion |

Raw refunds, resource packing, meat packaging and terrain/grass conversions do not add substantive manufacturing practice in this pass. Do not award practice on opening bundles or picking up/redeploying objects.

Ammo and lockpick bundles are different: they are manufactured from components. Their awards are normalized to their actual contents, and opening them gives no second craft award.

Manufactured materials use small per-unit awards, so 10 paper sheets count as 10 sheets at 0.02 each rather than ten equipment-sized recipe awards. Completed vehicles receive an assembly award in addition to the existing work involved in their component fabrication.

Live checks remain necessary for forge claims, fixtures, components, full vehicle assembly and save persistence.
