# Weapon and attachment stage

First step: optional equipment choices through two crafted, removable melee grips. The existing weapon families retain their baseline stats.

| Grip | Benefit | Cost |
| --- | --- | --- |
| Workshop Light Grip | -15% attack stamina modifier | +20% durability loss per use |
| Workshop Power Grip | +10% entity damage modifier | +15% attack stamina modifier |

Fits the six native melee weapon perk families: clubs, sledges, spears, blades, knuckles, batons. Mutual exclusion uses the native shared modifier tag grimmerGrip. Existing vanilla modifiers can coexist subject to their own restrictions and available slots. Stats are additive modifiers; normal attachment bonuses, perks and other equipment still affect final values.

Light recipe: 4 leather, 6 scrap polymers, 2 duct tape; 20 base seconds at a workbench. Power recipe: 8 forged iron, 2 springs, 2 duct tape; 30 base seconds at a workbench. Both always unlocked; no schematic dependency or loot injection. Perks and sandbox settings can change actual ingredient/time costs.

Definitions and English localization are generated at launch from Update-Core.ps1. Native icons are reused; no external assets or animation changes. The update delivers only existing allowed paths, so users do not need a manual install. Two generated definition files remain on rollback to avoid deleting existing item definitions.

Validation: 51 XML, inherited compatibility-tag, effect-name, recipe and localization checks against installed V3.4 b10 data. This does not prove actual equip/damage/stamina/durability behaviour; live checks remain in PLAYTEST-CHECKLIST.md.
