# Engine restoration - 0.1.26 testing candidate

Abandoned-vehicle inspections can now recover a **Damaged Engine Assembly**. It is a crafting component, not a functional engine, and cannot power generators or vehicles. Its name and description explain the workbench rebuild.

At a workbench, craft one native Engine (`smallEngine`) using:

- 1 Damaged Engine Assembly
- 10 forged iron
- 12 mechanical parts
- 4 oil
- 2 duct tape

Base craft time is 120 seconds. The recipe requires no schematic or magazine. Completion gives 12 base Vehicles practice through level 40, then the existing diminishing practice through the skill cap. Normal craft settings and workstation completion claiming still apply. Merely inspecting, picking up or scrapping the damaged component gives no engine-crafting reward. Inspection retains its existing small Vehicles/Salvage Tools award.

## Recovery balance

The existing working-component chances are unchanged: intact vehicles give 4% engine, 6% battery and 8% wheel chances. A separate 18% outcome gives a damaged assembly instead. The outcomes never overlap. Damaged sedans halve all component chances; stripped wrecks cannot yield an assembly or working component. Mechanical/electrical small-parts recovery remains unchanged.

The existing per-world, per-parent-position inspection ledger remains authoritative. Previously inspected vehicles do not reset or roll for an extra assembly. Normal vehicle loot, salvage drops, native battery/wheel recipes and driveable vehicles remain unchanged. There is no ordinary crafting recipe for the damaged assembly, preventing an assembly/material conversion loop.

## Save and rollback

The launch helper generates `ZZZ_GrimmerVehicleParts`, containing the new item definition and localization. It uses the native engine icon with a muted tint and inherits a resource item, not the functional engine. The companion definition remains available when an older launch helper is run, preserving saved item identity after a partial rollback. The older release will not have the rebuild recipe. No third-party assets or save migration.

## Verification

Production game build and all regression checks pass. Tests sweep all component rolls/conditions, reject overlap, check existing 632 routes and recipes, validate exact rebuild ingredients/station/time, localization and resource identity, and verify the older launch helper leaves the companion definition intact.

Run the configuration test with game directory, current main mod directory, previous 0.1.25 main mod directory and generated fixture root:

`python Tests/VehicleRestorationTests.py GAME CURRENT_MOD PREVIOUS_MOD FIXTURE`

Live inspection receipt, assembly tooltip/icon, actual consumption, native engine usability and completion practice remain pending in PLAYTEST-CHECKLIST.md. Restore the inspection ledger with the rest of the world; the crash-window limitations documented in VEHICLE-INSPECTION.md still apply.
