# Vehicle inspection - 0.1.24 testing candidate

Hold the normal use key on an abandoned sedan, police car, bus or ambulance and choose **Inspect vehicle parts**. Normal Search and wrench salvage remain available. Unlock locked vehicles first. Player-placed containers and driveable player vehicles are excluded.

Each eligible vehicle yields 1-4 mechanical parts (1-2 on damaged sedans) and 1-2 electrical parts. An intact vehicle has a 4% engine, 6% battery and 8% wheel chance, with at most one usable component. Damaged sedans halve these chances; stripped wrecks yield no usable component and require an existing native storage feature to be inspectable. Batteries use quality 1-3. Inspection grants 1 Vehicles and 0.5 Salvage Tools base activity practice once, subject to the existing learning settings and activity budget. Overflow uses native item drops at the player.

## Persistence and limits

`GrimmerVehicleInspections.xml` is stored beside the world's save files. It records the normalized parent position and exact parts result before delivery. Atomic replacement and fail-closed loading prevent repeat payouts after reload, block downgrades or malformed ledgers. A failed write gives no reward. A crash between the committed receipt and delivery can lose that inspection's reward; this deliberately favours preventing duplicates. The sidecar and native player save are not a shared transaction.

Depletion is conservative: quest/POI resets, loot respawns and replacement vehicles at that coordinate do not reset it. Back up and restore this file with the rest of the world. Removing it manually resets inspection history. No edits to vanilla loot, salvage drops, vehicle recipes or recipe practice routes. Multiplayer inspection is disabled through the existing solo guard.

## Installed-game API evidence

V3.4 b10 cars use BlockCompositeTileEntity and TEFeatureStorage. Native parent resolution handles multi-block children. The radial menu dispatches BlockActivationCommand.text to OnBlockActivated; eventName is reserved for separate custom game-event commands. The added command is appended to a copied result array, leaving the shared native command cache untouched. TEFeatureLockable.IsLocked is checked both for the menu and actual activation. Native PlayerInventory.AddItem mutates the remaining stack count; only that remainder is dropped.

Automated checks cover persistence, write failure, corrupt saves, independent worlds, eligibility, reward rates, native-search pass-through, copied menus, locks, occupied/placed containers, range, duplicate child activation, reload and full inventory. Compilation uses the installed game assemblies. Radial presentation, actual item receipt, overflow pickup and native salvage still need live play verification.
