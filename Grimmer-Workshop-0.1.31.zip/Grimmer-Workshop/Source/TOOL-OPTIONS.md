# Tool choices — 0.1.23

Two original, fixed-effect mods expand early workbench choices. They are optional crafts, not added to loot or traders. Existing vanilla modifiers and the original melee grips are unchanged.

| Mod | Benefit | Tradeoff | Workbench recipe |
| --- | --- | --- | --- |
| Light Tool Grip Mod | -10% attack stamina cost | +15% durability loss per use | 4 leather, 8 scrap polymers, 2 duct tape |
| Reinforced Tool Frame Mod | -25% durability loss per use | +10% attack stamina cost | 8 forged iron, 2 mechanical parts, 2 duct tape |

Both are removable and need a free mod slot. They fit non-motor harvesting and salvage tools: stone axes, axes, picks, shovels, wrenches, ratchets and impact drivers. Chainsaws, augers, repair hammers, nailguns, admin tools and weapons are excluded. The pair share one modifier tag, so only one Workshop tool choice can be installed at a time. Other native mods remain available according to their normal restrictions.

Both recipes are available at a workbench without a schematic. Crafting gives Workstations base 4 practice until level 25, matching the earlier Workshop melee grips. Existing 630 routes are unchanged. Installing/removing mods gives no crafting practice.

Display values use the same native percentage-floor compensation as the melee grips; gameplay effects remain exactly the stated percentages. Other perks and modifiers still affect final tool statistics. Icons reuse vanilla art with different tints; no third-party assets.

Definitions are generated at launch in a late-loading companion modlet, ZZZ_GrimmerToolOptions. Older releases do not overwrite that folder when regenerating their own melee definitions. Existing tool mods therefore retain definitions across a partial rollback; the recipes and practice routes depend on the installed Workshop release. This persistence was tested by generating the new definitions then running the older 0.1.22 generator against the same fixture.

Validation: original melee definitions preserved, accepted/rejected tool families checked against native inherited tags, recipes and localization validated, both percentages checked under native float flooring, and all 630 previous practice rules retained. Live equipped effects, slot rejection and mutual exclusion still need testing.
