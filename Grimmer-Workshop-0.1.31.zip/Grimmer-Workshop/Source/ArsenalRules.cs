using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace GrimmerWorkshop
{
    // Reads the user's separately installed pack. Never writes to, patches or
    // republishes its files, models, sounds, animations or balancing data.
    public static class ArsenalRules
    {
        static readonly Dictionary<string,string> tags = new Dictionary<string,string> {
            {"handgunSkill","craftingHandguns"},{"shotgunSkill","craftingShotguns"},
            {"rifleSkill","craftingRifles"},{"machinegunSkill","craftingMachineGuns"},
            {"knuckleSkill","craftingKnuckles"},{"bladeSkill","craftingBlades"},
            {"clubSkill","craftingClubs"},{"sledgeSkill","craftingSledgehammers"},
            {"spearSkill","craftingSpears"},{"roboticsSkill","craftingRobotics"}
        };
        public static List<PracticeRule> Read(string pack)
        {
            if (!Directory.Exists(pack)) return new List<PracticeRule>();
            var info = XDocument.Load(Path.Combine(pack,"ModInfo.xml"));
            if ((string)info.Root.Element("Name").Attribute("value") != "DSD_Arsenal" ||
                (string)info.Root.Element("Version").Attribute("value") != "1.2.1")
                throw new InvalidDataException("Arsenal practice supports inspected DSD_Arsenal 1.2.1 only.");
            var items = XDocument.Load(Path.Combine(pack,"Config","items.xml"));
            var recipes = XDocument.Load(Path.Combine(pack,"Config","recipes.xml"));
            var progression = XDocument.Load(Path.Combine(pack,"Config","progression.xml"));
            var result = new List<PracticeRule>();
            foreach (var item in items.Descendants("item")) {
                string name = (string)item.Attribute("name");
                var tagProperty = item.Elements("property").FirstOrDefault(p => (string)p.Attribute("name") == "Tags");
                var itemTags = new HashSet<string>(((string)(tagProperty == null ? null : tagProperty.Attribute("value")) ?? "").Split(','));
                if (!itemTags.Contains("weapon")) continue;
                if (name == null || !name.StartsWith("dsdArs",StringComparison.Ordinal)) throw new InvalidDataException("Unexpected Arsenal weapon name.");
                var matches = tags.Where(t => itemTags.Contains(t.Key)).Select(t => t.Value).Distinct().ToArray();
                if (matches.Length != 1) throw new InvalidDataException("Ambiguous Arsenal weapon skill: "+name);
                string skill = matches[0];
                var outputs = recipes.Descendants("recipe").Where(r => (string)r.Attribute("name") == name).ToArray();
                if (outputs.Length != 1 || (int?)outputs[0].Attribute("count") != 1) throw new InvalidDataException("Unsupported Arsenal weapon output: "+name);
                var levels = new List<int>();
                foreach (var operation in progression.Root.Elements()) {
                    string xpath = (string)operation.Attribute("xpath") ?? "";
                    if (!xpath.Contains("crafting_skill[@name='"+skill+"']")) continue;
                    foreach (var effect in operation.Descendants("passive_effect")) {
                        if ((string)effect.Attribute("name") != "RecipeTagUnlocked" ||
                            !((string)effect.Attribute("tags") ?? "").Split(',').Contains(name)) continue;
                        int level;
                        if (!int.TryParse(((string)effect.Attribute("level") ?? "").Split(',')[0],out level) || level < 1)
                            throw new InvalidDataException("Invalid Arsenal unlock: "+name);
                        levels.Add(level);
                    }
                }
                if (levels.Count != 1) throw new InvalidDataException("Missing/ambiguous Arsenal unlock: "+name);
                int cap = skill == "craftingHandguns" || skill == "craftingShotguns" || skill == "craftingRifles" || skill == "craftingMachineGuns" || skill == "craftingRobotics" ? 100 : 75;
                result.Add(new PracticeRule {Item=name,Skill=skill,Output=1,Unlock=levels[0],Until=cap,Cap=cap,Credit=10});
            }
            if (result.Count != 53 || result.Select(r=>r.Item).Distinct().Count()!=53)
                throw new InvalidDataException("Expected all 53 inspected Arsenal weapons.");
            foreach (var rule in result) {
                int next = result.Where(r=>r.Skill==rule.Skill && r.Unlock>rule.Unlock).Select(r=>r.Unlock).DefaultIfEmpty(rule.Cap+1).Min();
                rule.Until = Math.Min(rule.Cap,next+3);
            }
            var cells=recipes.Descendants("recipe").Where(r=>(string)r.Attribute("name")=="dsdArsEnergyCell").ToArray();
            if(cells.Length!=2 || cells.Any(r=>(int?)r.Attribute("count")!=1)) throw new InvalidDataException("Energy-cell recipe changed.");
            result.Add(new PracticeRule{Item="dsdArsEnergyCell",Skill="craftingElectrician",Output=1,Unlock=1,Until=20,Cap=100,Credit=.02});
            return result;
        }
        public static int Register(string root, Dictionary<string,List<PracticeRule>> rules, HashSet<string> skills)
        {
            var additions = Read(Path.Combine(Path.GetDirectoryName(root.TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar)),"DSD_Arsenal"));
            if (additions.Any(r=>rules.ContainsKey(r.Item))) throw new InvalidDataException("Arsenal practice output already registered.");
            foreach (var rule in additions) { rules.Add(rule.Item,new List<PracticeRule>{rule});skills.Add(rule.Skill); }
            return additions.Count;
        }
    }
}
