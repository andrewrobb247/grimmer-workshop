using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace GrimmerWorkshop
{
    public sealed class SkillMilestone
    {
        public int Level, Quality;
        public string Name;
    }
    public static class SkillScreenText
    {
        public static double Ratio(int level, int maximum, double practice, double cost, double growth)
        {
            if (level >= maximum) return 1;
            if (double.IsNaN(practice) || double.IsInfinity(practice)) return 0;
            return Math.Max(0, Math.Min(1, practice / PracticeMath.Required(level, cost, growth)));
        }
        public static string Progress(int level, int maximum, double practice, double cost, double growth)
        {
            if (level >= maximum) return "MAXIMUM LEVEL | " + maximum;
            if (double.IsNaN(practice) || double.IsInfinity(practice)) practice = 0;
            return "PRACTICE " + Math.Max(0,practice).ToString("0.#", CultureInfo.InvariantCulture) + " / " + PracticeMath.Required(level,cost,growth).ToString("0.#", CultureInfo.InvariantCulture) + "  |  LEVEL " + level + " / " + maximum;
        }
        public static string Next(int level, int maximum, IEnumerable<SkillMilestone> milestones)
        {
            if (level >= maximum) return "Next: maximum crafting level reached.";
            var future = milestones.Where(m => m.Level > level && m.Level <= maximum && !String.IsNullOrEmpty(m.Name)).ToList();
            if (future.Count == 0) return "Next: all recipe and quality milestones unlocked.";
            int next = future.Min(m => m.Level);
            var names = future.Where(m => m.Level == next).Select(m => m.Name + (m.Quality > 0 ? " Q" + m.Quality : "")).Distinct().ToArray();
            return "Next at level " + next + ": " + String.Join(", ", names);
        }
        public static string Shorten(string text, int length)
        {
            return text.Length <= length ? text : text.Substring(0,Math.Max(0,length-3)).TrimEnd() + "...";
        }
        public static string Training(string skill, int level, bool activities)
        {
            string craft, action = "";
            switch (skill) {
                case "craftingHarvestingTools": craft="Craft tools/tool mods; scrap quality tools."; action="Chop wood and mine with harvesting tools."; break;
                case "craftingRepairTools": craft="Craft repair kits (to level 4), then hammers/nailguns."; action="Repair equipment and upgrade blocks."; break;
                case "craftingSalvageTools": craft="Assemble mechanical parts (to level 4), then craft salvage tools."; action="Dismantle using salvage tools."; break;
                case "craftingKnuckles": craft="Craft knuckles; scrap quality knuckles."; action="Deal damage with knuckle weapons."; break;
                case "craftingBlades": craft="Craft knives/blades; scrap quality blades."; action="Deal blade damage and harvest with blades."; break;
                case "craftingClubs": craft="Craft clubs/club mods; scrap quality clubs."; action="Deal damage with clubs."; break;
                case "craftingSledgehammers": craft="Craft sledges; scrap quality sledges."; action="Deal damage with sledgehammers."; break;
                case "craftingBows": craft="Craft bows, bow mods and arrows/bolts; scrap quality bows."; action="Deal damage with bows/crossbows."; break;
                case "craftingSpears": craft="Craft spears; scrap quality spears."; action="Deal damage with spears."; break;
                case "craftingHandguns": craft="Craft handguns/ammo; scrap quality handguns."; action="Deal damage with handguns."; break;
                case "craftingShotguns": craft="Craft shotguns, shotgun mods and ammo; scrap quality guns."; action="Deal damage with shotguns."; break;
                case "craftingRifles": craft="Craft rifles and 7.62mm ammo; scrap quality rifles."; action="Deal damage with rifles."; break;
                case "craftingMachineGuns": craft="Craft machine guns and 7.62mm ammo; scrap quality guns."; action="Deal damage with machine guns."; break;
                case "craftingExplosives": craft="Craft gunpowder (to level 2), then explosives."; break;
                case "craftingRobotics": craft="Craft pipe batons (to 11), robotic gear/mods and turret ammo."; action="Deal damage with mapped batons/robotic weapons."; break;
                case "craftingArmor": craft="Craft armour and armour mods; scrap quality armour."; break;
                case "craftingBackpack": craft="Craft cloth (to 5), backpacks and pocket mods."; break;
                case "craftingMedical": craft="Prepare aloe cream/splints; craft bandages (to 5) and advanced medicine."; action="Use medical items and drugs."; break;
                case "craftingFood": craft="Prepare ingredients, feed, drinks and meals. Advanced recipes teach more."; break;
                case "craftingSeeds": craft="Craft farm plots (to level 2), then seeds."; action="Harvest mature crops."; break;
                case "craftingElectrician": craft="Assemble electrical parts (to 25), powered devices and electronic mods."; action="Salvage electrical parts."; break;
                case "craftingTraps": craft="Craft wooden spikes (to 25), traps/turrets and iron darts."; break;
                case "craftingConstruction": craft="Craft building materials, shapes, doors, storage and furniture."; action="Upgrade blocks."; break;
                case "craftingWorkstations": craft=level < 10 ? "Build campfires, prepare food/water or craft components. Forge at 4; workbench at 10." : "Craft unlocked workstations, components and workshop gear."; action="Upgrade blocks."; break;
                case "craftingVehicles": craft="Craft duct tape (to 5), vehicle parts, vehicles, mods and fuel."; break;
                default: craft="Complete crafts in this category."; break;
            }
            return "Train: " + craft + (activities && action.Length > 0 ? " " + action : "");
        }
    }
}
