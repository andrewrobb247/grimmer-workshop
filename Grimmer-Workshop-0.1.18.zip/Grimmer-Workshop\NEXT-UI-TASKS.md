# Next tasks

- Live-check Construction registration on existing characters, practice awards, persistence and craft-time bonus.
- Live-check corrected grip percentage display. Names, stat panel and description confirmed working.
- Continue relevant small practice coverage for uncovered non-building recipes; avoid reversible conversion loops.
- Continue the main weapon/gameplay roadmap after live checks.
