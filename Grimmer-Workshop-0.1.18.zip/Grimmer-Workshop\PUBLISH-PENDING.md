# Publication status

0.1.17 published to testing on 19 November 2026. All 20 runtime files match their staged SHA-256 hashes; full source ZIP matches exactly. Old 0.1.10 updater verified through Windows PowerShell 5.1.

Validation: 2,614 production regression checks; 34 layout checks; 51 attachment checks plus native display-chain checks; all 311 previous practice routes audited, with 37 bounded secondary routes added.

Live checks: grip display, recipe icon and tooltip/cap hiding, water/food and workbench equipment practice. See PLAYTEST-CHECKLIST.md.
