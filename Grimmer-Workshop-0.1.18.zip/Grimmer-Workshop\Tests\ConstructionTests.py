import sys,csv,math,struct,re,xml.etree.ElementTree as E
from pathlib import Path
game,mod,fixture,baseline=map(Path,sys.argv[1:])
vanilla=E.parse(game/'Data/Config/recipes.xml').getroot()
rules={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(mod/'PracticeRules.xml').getroot()}
old={(r.get('item'),r.get('skill')):dict(r.attrib) for r in E.parse(baseline/'PracticeRules.xml').getroot()}
assert all(rules[key]==value for key,value in old.items()),'Existing route changed'
new={k:v for k,v in rules.items() if k not in old}
assert len(new)==82 and all(skill=='craftingConstruction' for _,skill in new)
assert all(r['cap']=='100' and 0<float(r['credit'])<=12 for r in new.values())
for name in ['frameShapes:VariantHelper','woodShapes:VariantHelper','concreteShapes:VariantHelper','steelShapes:VariantHelper','resourceConcreteMix','bedrollBlockVariantHelper','cntWoodWritableCrate','ironDoorBlockVariantHelper','ladderWood','barbedFence','woodHatch']:
 assert (name,'craftingConstruction') in new,name
assert not any('Bundle' in item or item.startswith(('gun','ammo','food')) for item,_ in new)
patch=E.parse(mod/'Config/recipes.xml').getroot()
count=0
for op in patch.findall('setattribute'):
 path=op.get('xpath')
 assert path.startswith("/recipes/recipe[@name='") and "[not(wildcard_forge_category)]" in path
 name=path.split("'")[1];index=int(path.rsplit('[',1)[1][:-1])-1
 targets=[r for r in vanilla.findall('recipe') if r.get('name')==name and r.find('wildcard_forge_category') is None]
 assert index<len(targets)
 tags=targets[index].get('tags','').split(',');updated=op.text.split(',')
 assert all(tag in updated for tag in tags if tag)
 assert updated.count('grimmerConstruction')==1
 assert targets[index].find('wildcard_forge_category') is None
 count+=1
assert count>=82
skill=E.parse(fixture/'Profile/Mods/GrimmerWorkshop/Config/progression.xml').find('.//crafting_skill')
assert skill.get('name')=='craftingConstruction' and skill.get('min_level')=='1' and skill.get('max_level')=='100' and skill.get('parent')=='attCrafting'
effect=skill.find('.//passive_effect')
assert effect.attrib==dict(name='CraftingTime',operation='perc_add',level='1,100',value='0,-0.15',tags='grimmerConstruction')
assert skill.find('.//passive_effect[@name="RecipeTagUnlocked"]') is None
with (fixture/'Profile/Mods/GrimmerWorkshop/Config/Localization.csv').open(encoding='utf8') as f:loc={r['Key']:r['english'] for r in csv.DictReader(f)}
assert all(skill.get(key) in loc for key in ('name_key','desc_key','long_desc_key'))
assert loc[skill.get('name_key')]=='Construction'
# Simulate native float conversion and flooring in percent display.
def f32(x):return struct.unpack('f',struct.pack('f',x))[0]
mods=E.parse(fixture/'Profile/Mods/GrimmerWorkshop/Config/item_modifiers.xml')
for modifier in mods.findall('.//item_modifier'):
 expected={'dStaminaLoss':-15,'dDegradationPerUse':20} if modifier.get('name')=='grimmerLightGrip' else {'dEntityDamage':10,'dStaminaLoss':15}
 for value in modifier.findall('.//display_value'):
  v=f32(f32(1+f32(float(value.get('value'))))-1)
  assert math.floor(f32(v*100))==expected[value.get('name')]
assert 'Write-WorkshopConstruction $PSScriptRoot $GameDirectory' in (mod.parents[2]/'Launch-Workshop.ps1').read_text(encoding='utf8')
print(f'Passed Construction audit: {len(old)} routes unchanged; {len(new)} building routes; {count} variant-safe recipe tags; skill registration, unlock preservation and grip rounding checked.')
