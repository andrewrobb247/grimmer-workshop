# Publication complete

0.1.12 published 18 November 2026. All 20 hosted runtime files match hashes and sizes; full archive matches exactly; testing channel matches the prepared manifest. No publication steps remain.
