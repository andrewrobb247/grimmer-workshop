# Recipe balance audit

18 November 2026. Static vanilla V3.4 b10 recipes plus Workshop assembly recipes.

Checked 311 practice routes and 321 recipe variants across 24 skills. Full comparisons are in BALANCE-DATA.csv.

Ingredient values resolve inherited EconomicValue and EconomicBundleSize independently. This avoids treating one wood as the value of a whole trading bundle. These are comparison proxies, not actual buy/sell prices, resource rarity or gathering time. Counts are the recipe XML baseline; perks, quality scaling, sandbox settings and zero-count placeholders can change actual costs. Missing craft times remain unknown. Reported practice is quality 1 at the recipe unlock level, before falloff, using actual output-to-rule batch normalisation.

## Confirmed outlier and targeted change

| Recipe | Ingredients | Old practice | New practice | Declared base time |
| --- | --- | --- | --- | --- |
| Two fuel | One oil shale | 17.6 | 0.176 | 0.125 seconds |
| Bicycle chassis | 5 forged iron, 2 mechanical parts, 2 tape, 2 leather, 2 springs | 11.6 | 11.6 | 30 seconds |

At Vehicle skill 20 both routes still have full recipe relevance. The old fuel batch exceeded the chassis reward despite its minimal inputs and fast refining time. Fuel base credit changes from 10 to 0.1, retaining output normalisation, unlock scaling and later falloff. No other route or global learning rate changes.

Simulation, starting Vehicle level 20 with zero practice, 1,000 refining batches (2,000 fuel, 1,000 shale). Separate claims reevaluate relevance as levels increase; one grouped station claim evaluates relevance at its starting level:
- Old rules: level/practice/credited total (89, 44.544, 4633.044).
- New rules, separate claims: level/practice/credited total (23, 26.0, 176.0).
- Old rules, one grouped claim: (100, 12060.0, 17600.0).
- New rules, one grouped claim: (23, 26.0, 176.0).

## Observations retained for playtesting

- Backpacks: later packs have expensive sewing/steel/legendary inputs. Quality multipliers already increase reward; ordinary-play craft frequency remains unmeasured. No speculative increase yet.
- Armour: primitive crafts are cheap, but their relevance falls after later unlocks. Advanced armour needs crafting kits. Keep rates while observing actual use.
- Electronics: relays/tripwires cost much less than powered doors, yet both require useful base construction. Their unlock relevance and real build frequency matter; avoid automatic price-proportional rewards.
- Traps: starter spikes train only to skill 25, directing progress to later traps. Confirm regular defence construction can support progression.
- Bulk gunpowder bundles and expensive foods have low practice per listed ingredient value. Bulk processing is supplementary; do not multiply rewards by the bundle contents without checking exploit and pacing effects.

## Validation and limits

Compare BALANCE-CHANGES.json with the baseline to ensure only the fuel credit changed. Regenerate all progression routes; unchanged caps/unlocks must still cover every level. Live checks: refine a small fuel batch at Vehicle 20+, compare practice before/after, then reopen the station and check no duplicate credit. No full economy playthrough has been claimed.

Further issue to investigate separately: recipe relevance is evaluated at the level when a completion record is claimed. Very large grouped claims can bypass some within-batch falloff. Do not silently change all crafting rewards in this targeted pass; compare sequential and grouped completion behaviour before a separate correction.
