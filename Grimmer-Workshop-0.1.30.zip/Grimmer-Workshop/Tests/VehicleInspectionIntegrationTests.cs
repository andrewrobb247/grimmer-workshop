using System;
using System.Collections.Generic;
using System.IO;
using GrimmerWorkshop;
using UnityEngine;
namespace HarmonyLib { public class HarmonyPatch : Attribute { public HarmonyPatch(Type type, string method) {} public HarmonyPatch(Type type, string method, Type[] args) {} } }
namespace UnityEngine {
    public struct Vector3 {
        public float x,y,z;
        public Vector3(float a,float b,float c) { x=a;y=b;z=c; }
        public static Vector3 zero { get { return new Vector3(); } }
        public static Vector3 operator -(Vector3 a,Vector3 b) { return new Vector3(a.x-b.x,a.y-b.y,a.z-b.z); }
        public float sqrMagnitude { get { return x*x+y*y+z*z; } }
    }
}
public struct Vector3i { public int x,y,z; public Vector3i(int a,int b,int c) { x=a;y=b;z=c; } }
public class WorldBase {
    public BlockValue value; public TileEntityComposite tile;
    public BlockValue GetBlock(Vector3i p){return value;}
    public TileEntityComposite GetTileEntity(Vector3i p){return tile;}
}
public class EntityPlayerLocal { public Vector3 position; public LocalUI PlayerUI=new LocalUI(); public int entityId; }
public class LocalUI { public XUI xui=new XUI(); }
public class XUI { public PlayerInventory PlayerInventory=new PlayerInventory(); }
public class PlayerInventory {
    public int received; public bool full;
    public bool AddItem(ItemStack item,bool sound) { if(full)return false; received+=item.count;item.count=0;return true; }
}
public class ItemStack { public ItemValue itemValue;public int count; public ItemStack(ItemValue value,int n) { itemValue=value;count=n; } }
public class ItemValue { public bool HasQuality;public ushort Quality;public ItemClass ItemClass;public bool IsEmpty(){return ItemClass==null;} }
public class ItemClass {
    string name; public static ItemValue GetItem(string name,bool unused) { return new ItemValue { ItemClass=new ItemClass { name=name }, HasQuality=name=="carBattery" }; }
    public string GetItemName(){return name;}
}
public class Block {
    public string name="cntCar03SedanDamage0v01";public string GetBlockName(){return name;}
    public static int timers;
    public static void TakeItemWithTimer(Vector3i p,BlockValue v,EntityPlayerLocal player,float delay,Func<Vector3i,EntityPlayerLocal,bool> callback){if(callback(p,player))timers++;}
}
public struct BlockValue { public Block Block;public int damage; }
public class TimerEventData { public object Data; }
public class TEFeatureStorage { public bool empty=true;public bool IsEmpty(){return empty;} }
public class TEFeatureLockable { public bool locked; public bool IsLocked(){return locked;} }
public class TileEntityComposite {
    public bool PlayerPlaced,accessing,LocalPlayerIsOwner; public TEFeatureStorage storage=new TEFeatureStorage();public TEFeatureLockable lockable;
    public bool IsUserAccessing(){return accessing;}
    public T GetFeature<T>() where T:class { return typeof(T)==typeof(TEFeatureStorage)?storage as T:lockable as T; }
}
public class BlockCompositeTileEntity {
    public TileEntityComposite tile=new TileEntityComposite();public bool child;
    public bool TryGetParentBlockAndTileEntity(ref Vector3i p,ref BlockValue v,out TileEntityComposite t){if(child)p.x=0;t=tile;return t!=null;}
}
public struct BlockActivationCommand {
    public string text; public bool enabled;public static BlockActivationCommand[] Empty=new BlockActivationCommand[0];
    public BlockActivationCommand(string t,string icon,bool e,bool h,string evt){text=t;enabled=e;}
}
public class GameManager {
    public static GameManager Instance=new GameManager();public int drops;public WorldBase World;
    public static void ShowTooltip(EntityPlayerLocal p,string text,bool a,bool b,int seconds){}
    public void ItemDropServer(ItemStack s,Vector3 p,Vector3 v,int id,float time,bool unused){drops+=s.count;}
}
public static class GameIO { public static string directory; public static string GetSaveGameDir(){return directory;} }
public static class Log { public static void Error(string message){throw new Exception(message);} }
namespace GrimmerWorkshop {
    public static class Workshop { public static EntityPlayerLocal player=new EntityPlayerLocal();public static EntityPlayerLocal Player(){return player;} }
    public static class Activities { public static int awards;public static void Award(string s,double n){awards++;} }
}
class VehicleInspectionIntegrationTests {
    static int checks;
    static void Check(bool value,string name){checks++;if(!value)throw new Exception(name);}
    static void Main(string[] args){
        GameIO.directory=Path.Combine(args[0],"vehicle-integration-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(GameIO.directory);
        var world=new WorldBase();var block=new BlockCompositeTileEntity();var value=new BlockValue{Block=new Block()};var p=new Vector3i(0,0,0);
        var original=new[]{new BlockActivationCommand("Search","search",true,false,null)};var menu=original;
        VehicleInspectionCommandsPatch.Postfix(block,world,value,p,ref menu);
        Check(menu.Length==2&&original.Length==1&&original[0].text=="Search","Search preserved; shared cache untouched");
        Check(menu[1].text==VehicleInspection.Command&&menu[1].enabled,"Native text dispatch matches handler");
        bool handled=false;
        Check(VehicleInspectionActivatePatch.Prefix(block,"Search",world,p,value,Workshop.player,ref handled),"Native Search passes through");
        block.tile.lockable=new TEFeatureLockable{locked=true};
        VehicleInspection.Inspect(world,block,p,value,Workshop.player);
        Check(Workshop.player.PlayerUI.xui.PlayerInventory.received==0&&Activities.awards==0,"Locked car gives nothing");
        block.tile.lockable.locked=false;block.tile.PlayerPlaced=true;
        VehicleInspection.Inspect(world,block,p,value,Workshop.player);
        Check(Activities.awards==0,"Placed car excluded");block.tile.PlayerPlaced=false;
        block.tile.accessing=true;VehicleInspection.Inspect(world,block,p,value,Workshop.player);
        Check(Activities.awards==0,"Open car excluded");block.tile.accessing=false;
        Workshop.player.position=new Vector3(100,0,0);VehicleInspection.Inspect(world,block,p,value,Workshop.player);
        Check(Activities.awards==0,"Out-of-range activation rejected");Workshop.player.position=Vector3.zero;
        Check(!VehicleInspectionActivatePatch.Prefix(block,VehicleInspection.Command,world,p,value,Workshop.player,ref handled)&&handled,"Inspection consumes only its command");
        int received=Workshop.player.PlayerUI.xui.PlayerInventory.received;
        Check(received>=2&&Activities.awards==2,"Parts and both skills awarded");
        Check(File.Exists(Path.Combine(GameIO.directory,"GrimmerVehicleInspections.xml")),"Depletion persisted");
        block.child=true;p.x=1;VehicleInspection.Inspect(world,block,p,value,Workshop.player);
        Check(received==Workshop.player.PlayerUI.xui.PlayerInventory.received&&Activities.awards==2,"Other vehicle child cannot repeat payout");
        world=new WorldBase();VehicleInspection.Inspect(world,block,p,value,Workshop.player);
        Check(Activities.awards==2,"New world object reloads saved depletion");
        block.child=false;p.x=2;Workshop.player.PlayerUI.xui.PlayerInventory.full=true;
        VehicleInspection.Inspect(world,block,p,value,Workshop.player);
        Check(GameManager.Instance.drops>=2&&Activities.awards==4,"Full inventory drops recovered parts");
        Console.WriteLine("PASS: "+checks+" vehicle interaction checks.");
    }
}
