# Publication status

0.1.30 recipe display fix prepared. Hides only redundant Workshop specialist rows when the matching original is present, preferring specialist at its own station. Saved items, actual recipes and author pack unchanged. Production build, existing regressions, 17 focused display tests and native field/list/station checks pass. Live checks pending. Latest published release 0.1.29; upload/verify payloads/archive before enabling testing channel.
