# Next tasks

- 0.1.29 practice bridge for all 53 DSD Arsenal weapons published. Author pack locally staged but NOT installed because this session cannot write the installed profile.
- User must run ../work/Install-Arsenal.cmd with game closed. Preflight and save backup complete. It installs all weapons and own bridge together, with no additional download.
- Then check game log, actual models/animations/sounds, crafting quality/gates, combat/scrap practice and save/reload using PLAYTEST-CHECKLIST.md. No player-confirmed integration yet.
- New priority remains actual custom weapons; do not substitute native-model sidegrades. No experimental Field Knife/Mace/Spear code was published.
- Broader farming/compost work deferred until weapon integration is tested.