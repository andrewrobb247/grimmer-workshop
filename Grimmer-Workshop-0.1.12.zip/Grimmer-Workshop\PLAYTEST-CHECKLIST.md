# Workshop playtest checklist

Updated 18 November 2026. Current release candidate: 0.1.12. Published before this candidate: 0.1.11.
Keep using the current world. Pending means not yet confirmed in live play.

## Confirmed by player

- [x] Completed crafting awards practice.
- [x] Quality 3 stone axe gives 15 practice; scrapping that crafted axe gives 1.5.
- [x] Harvesting gives Harvesting Tools practice.
- [x] Club damage gives Clubs practice.
- [x] Equipment repair gives Repair Tools practice.
- [x] Storage ingredients appear in recipe ingredient counts.
- [x] Crafting screen shows saved practice, bars and training hints (0.1.6).
- [x] Vanilla inventory locks work. The reported broken lock belonged to War3zuk.

## Check on the next normal restart

- [ ] Practice totals and skill levels survive save, quit and reload. Compare a screenshot before/after without performing another activity.
- [ ] In 0.1.7 the skill description has no magazine sentence.
- [ ] Workstations next unlock says Forge at level 4, then Chicken Coop at level 6. Check against the native unlock table.
- [ ] Display settings preview changes as values change. Save a smaller bar, launch, and compare against an enemy.
- [ ] With names off and health numbers on, the enemy bar has numbers but no name.
- [ ] With names on, the selected name size appears after restarting. Restore the preferred setting afterwards.

## Check when materials become available

- [ ] Cooking: complete charred meat at a campfire. No cooking pot is needed for this recipe. Expect Food practice while below its level-2 training cap, and Workstations practice while below level 10.
- [ ] Farming: harvesting a mature crop awards Seeds practice; hitting an immature crop must not give the same harvest reward.
- [ ] Electrical salvage: salvage an object that actually yields electrical parts. Expect Electrician practice as well as any applicable salvage practice.
- [ ] Block upgrades award Repair Tools and a smaller amount of Workstations practice.
- [ ] Workstation craft: collect completed output and confirm practice is credited once, including after leaving and returning.
- [ ] Cancelling an unfinished craft or scrap awards no completion practice.
- [ ] Storage counts update when entering/leaving chest range and resources are consumed once.
- [ ] Newly generated loot/trader stock respects book toggles. Existing items can remain.

## Balance observations to collect

- [ ] Does reaching the forge feel natural through cooking/building, rather than repeatedly making campfires?
- [ ] Does the next tool technology become available before the previous tool stops feeling useful?
- [ ] Do quality upgrades feel worth their material cost?
- [ ] Can each category progress at a reasonable pace during ordinary play? Pay particular attention to armour, backpacks, traps and vehicles, whose routes rely on crafting.

## Development follow-up

- Review the balance findings in Source/BALANCE-REVIEW.md before changing rates.
- Nearby deposit/refill buttons implemented in 0.1.8; pending live checks listed below.
- Test a clean friend installation and document multiplayer requirements before presenting the pack as multiplayer-ready.

## 0.1.8 storage button checks

- [ ] Two arrow icons appear beside Inventory without covering the native controls.
- [ ] Deposit nearby moves matching unlocked items once and protects locked backpack slots.
- [ ] Refill tops up occupied locked slots and leaves empty locked slots alone.
- [ ] Out-of-range, open and unowned chests are excluded; protected chest slots stay untouched.
- [ ] Reopening inventory does not duplicate click handlers. Compare item totals before/after both transfers.
- [ ] No-op transfers explain what is missing. Right-clicking does not transfer.



## 0.1.9 quest reward checks

- [ ] With all crafting magazines disabled, newly generated magazine-bundle reward rolls offer 3 repair kits instead.
- [ ] Crafting-magazine challenge reward pools also give repair kits.
- [ ] Disabled direct book/schematic rewards become 3 repair kits; other choices, XP and Dukes stay unchanged.
- [ ] Re-enabling magazines restores the original reward pools on newly generated choices.
- [ ] Old saved choices/bundles can remain; do not treat those as newly generated rewards.


## 0.1.10 deposit/refill correction

- [ ] Left-click each button: it should now transfer items or display an explanation.
- [ ] Check locked backpack slots remain protected during deposit and refill tops up occupied locked slots.
- [ ] Recheck item totals and repeat after reopening inventory.


## 0.1.11 equipment deposit

- [ ] Deposit a baton into a chest containing the same baton type at another quality. Check separate slots, quality, condition and attached mods.
- [ ] Locked backpack items and protected chest slots stay untouched; a full chest leaves equipment in the backpack.
- [ ] Refill does not combine incompatible qualities. Different base item types do not seed the same deposit destination.

## 0.1.12 workstation quality credit

- [ ] Queue the same equipment at two different qualities, let both finish with the station closed, then open it. Confirm each quality receives its own practice reward.
- [ ] Reopen the station: practice must not be awarded again.
- [ ] Finish cooking with the campfire closed; open it to claim. Save/reload before claiming another batch and confirm it remains claimable once.
- [ ] Older completion records already merged before this update cannot be used to check the new quality separation. Use freshly queued crafts.
