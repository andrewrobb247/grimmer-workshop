# Crafting progression audit

Generated from installed V3.4 b10 data. All crafting-level transitions have a magazine-free recipe route. Ingredients, loot luck and workstation construction still need real play balancing.

| Crafting skill | Maximum | Starting recipe | Starting station | Levels checked |
| --- | --- | --- | --- | --- |
| Armor | 100 | armorPrimitiveBoots | backpack | 1–99 |
| Backpack | 100 | resourceCloth | backpack | 1–99 |
| Blades | 75 | meleeWpnBladeT0BoneKnife | backpack | 1–74 |
| Bows | 75 | gunBowT0PrimitiveBow | backpack | 1–74 |
| Clubs | 75 | meleeWpnClubT0WoodenClub | backpack | 1–74 |
| Electrician | 100 | resourceElectricParts | backpack | 1–99 |
| Explosives | 100 | resourceGunPowder | backpack, chemistryStation | 1–99 |
| Food | 100 | foodCharredMeat | campfire | 1–99 |
| Handguns | 100 | gunHandgunT0PipePistol | backpack | 1–99 |
| HarvestingTools | 100 | meleeToolRepairT0StoneAxe | backpack | 1–99 |
| Knuckles | 75 | meleeWpnKnucklesT0LeatherKnuckles | backpack | 1–74 |
| MachineGuns | 100 | gunMGT0PipeMachineGun | backpack | 1–99 |
| Medical | 75 | medicalBandage | backpack | 1–74 |
| RepairTools | 50 | resourceRepairKit | backpack | 1–49 |
| Rifles | 100 | gunRifleT0PipeRifle | backpack | 1–99 |
| Robotics | 100 | meleeWpnBatonT0PipeBaton | backpack | 1–99 |
| SalvageTools | 75 | resourceMechanicalParts | backpack | 1–74 |
| Seeds | 20 | farmPlotBlockVariantHelper | backpack | 1–19 |
| Shotguns | 100 | gunShotgunT0PipeShotgun | backpack | 1–99 |
| Sledgehammers | 75 | meleeWpnSledgeT0StoneSledgehammer | backpack | 1–74 |
| Spears | 75 | meleeWpnSpearT0StoneSpear | backpack | 1–74 |
| Traps | 100 | trapSpikesWoodDmg0 | backpack | 1–99 |
| Vehicles | 100 | resourceDuctTape | backpack | 1–99 |
| Workstations | 75 | campfire | backpack | 1–74 |

Checked 2021 level transitions across 24 crafting skills. No progression-gap failures.

Early workstation path: campfires to Workstations 4 unlock the forge; food preparation trains Workstations to 10 for the workbench; boiled water gives modest practice, and workbench equipment crafting continues beyond 10. Mechanical parts assembly requires forged iron from that forge. Electrical parts assembly requires scrap iron and polymers. Both assembly recipes are always unlocked.
