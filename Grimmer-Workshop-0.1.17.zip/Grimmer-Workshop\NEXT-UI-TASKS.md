# Next tasks

- Live-check 0.1.16 grip names, descriptions, stat panels and equipped effects.
- Live-check 0.1.17 recipe training icon/hover, cap hiding and food/water/workbench secondary practice.
- Review progression pacing from normal play; retain early unlocks at Forge 4 and workbench 10.
- Return to weapon choices and the main roadmap after these live checks.
