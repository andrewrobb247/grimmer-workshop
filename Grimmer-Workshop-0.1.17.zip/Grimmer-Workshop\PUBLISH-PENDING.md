# Publication status

0.1.16 published to testing on 19 November 2026. All 20 hosted runtime payloads match staged SHA-256 hashes; full source ZIP matches exactly. Grip display fixture, 28 skill-screen layout checks and 2,605 regression checks passed. In-game display check pending.
