using System;

namespace GrimmerWorkshop
{
    public static class PracticeMath
    {
        public static double QualityMultiplier(int quality)
        {
            switch (quality) {
                case 2: return 1.25;
                case 3: return 1.5;
                case 4: return 1.75;
                case 5: return 2;
                case 6: return 2.5;
                default: return 1;
            }
        }

        public static double Required(int level, double baseCost, double growth)
        {
            return Math.Max(1, baseCost + Math.Max(0, level - 1) * growth);
        }

        public static double Credit(int outputCount, int recipeOutput, int unlockLevel, int currentLevel, int usefulUntil, double baseCredit)
        {
            if (outputCount <= 0 || recipeOutput <= 0) return 0;
            double relevance = currentLevel <= usefulUntil ? 1 : Math.Max(0.1, 1.0 / (1 + (currentLevel - usefulUntil) / 5.0));
            return outputCount / (double)recipeOutput * baseCredit * (1 + Math.Max(0, unlockLevel - 1) / 25.0) * relevance;
        }

        public static int MoveCount(int sourceCount, int destinationCount, int capacity)
        {
            return Math.Max(0, Math.Min(sourceCount, capacity - destinationCount));
        }
    }
}
