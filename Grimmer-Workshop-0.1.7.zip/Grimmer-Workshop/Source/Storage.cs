using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace GrimmerWorkshop
{
    public sealed class Container
    {
        public TileEntityComposite Tile;
        public ItemStackGrid Grid;
    }

    public sealed class GridChange
    {
        public ItemStackGrid Grid;
        public ItemStack[] Before, After;
        public TileEntity Tile;
        public GridChange(ItemStackGrid grid, TileEntity tile)
        {
            Grid = grid; Tile = tile; Before = grid.CloneItems(); After = grid.CloneItems();
        }
    }

    public static class Storage
    {
        public static List<Container> Nearby()
        {
            var result = new List<Container>();
            var player = Workshop.Player();
            if (player == null) return result;
            int radius = Workshop.Range;
            int minX = ((int)Math.Floor(player.position.x) - radius) >> 4;
            int maxX = ((int)Math.Floor(player.position.x) + radius) >> 4;
            int minZ = ((int)Math.Floor(player.position.z) - radius) >> 4;
            int maxZ = ((int)Math.Floor(player.position.z) + radius) >> 4;
            for (int x = minX; x <= maxX; x++)
            for (int z = minZ; z <= maxZ; z++)
            {
                var chunk = player.world.GetChunkFromWorldPos(x << 4, z << 4) as Chunk;
                if (chunk == null) continue;
                foreach (var entity in chunk.GetTileEntities().list)
                {
                    var tile = entity as TileEntityComposite;
                    if (tile == null || !tile.PlayerPlaced || !tile.LocalPlayerIsOwner || tile.IsUserAccessing()) continue;
                    var position = tile.ToWorldPos();
                    var center = new Vector3(position.x + 0.5f, position.y + 0.5f, position.z + 0.5f);
                    if ((center - player.position).sqrMagnitude > radius * radius) continue;
                    var storage = tile.GetFeature<TEFeatureStorage>();
                    if (storage == null || storage.ItemGrid == null) continue;
                    result.Add(new Container { Tile = tile, Grid = storage.ItemGrid });
                }
            }
            return result.OrderBy(c => {
                var p = c.Tile.ToWorldPos();
                return (new Vector3(p.x, p.y, p.z) - player.position).sqrMagnitude;
            }).ToList();
        }

        public static int Count(ItemStackGrid grid, ItemValue value)
        {
            int count = 0;
            for (int i = 0; i < grid.Length; i++)
                if (!grid.IsSlotLocked(i) && MatchesIngredient(grid[i], value)) count += grid[i].count;
            return count;
        }

        private static bool MatchesIngredient(ItemStack stack, ItemValue value)
        {
            // Pull only plain stackable ingredients. Quality-bearing equipment is left
            // to vanilla's item-selection path so attached mods and condition are preserved.
            return stack != null && !stack.IsEmpty() && stack.itemValue.type == value.type && !stack.itemValue.HasQuality;
        }

        public static bool Gather(IList<ItemStack> ingredients, int multiplier, out string failure)
        {
            failure = "";
            if (multiplier < 1 || multiplier > 100000) { failure = "Invalid crafting quantity."; return false; }
            var player = Workshop.Player();
            var sources = Nearby();
            if (sources.Count == 0) return true;
            var bag = new GridChange(player.bag.ItemGrid, null);
            var changes = sources.Select(c => new GridChange(c.Grid, c.Tile)).ToList();
            var needed = new Dictionary<int, long>();
            foreach (var ingredient in ingredients)
            {
                long old;
                needed.TryGetValue(ingredient.itemValue.type, out old);
                needed[ingredient.itemValue.type] = old + (long)ingredient.count * multiplier;
            }
            foreach (var pair in needed)
            {
                var value = new ItemValue(pair.Key, false);
                long held = player.bag.GetItemCount(value, -1, -1, true) + player.inventory.GetItemCount(value, false, -1, -1, true);
                long shortage = pair.Value - held;
                if (shortage <= 0) continue;
                if (value.HasQuality) continue;
                foreach (var source in changes)
                {
                    for (int slot = 0; slot < source.After.Length && shortage > 0; slot++)
                    {
                        var stack = source.After[slot];
                        if (source.Grid.IsSlotLocked(slot) || !MatchesIngredient(stack, value)) continue;
                        int request = (int)Math.Min(shortage, stack.count);
                        int moved = Put(bag.After, bag.Grid, stack, request, false);
                        stack.count -= moved;
                        shortage -= moved;
                        if (stack.count == 0) source.After[slot] = ItemStack.Empty.Clone();
                    }
                }
                if (shortage > 0)
                {
                    failure = "Need more ingredients or free backpack space. Nearby storage was left untouched.";
                    return false;
                }
            }
            changes.Add(bag);
            Commit(changes);
            return true;
        }

        public static int Transfer(bool refill)
        {
            var player = Workshop.Player();
            if (player == null) throw new InvalidOperationException("Load a solo world first.");
            var bag = new GridChange(player.bag.ItemGrid, null);
            var changes = Nearby().Select(c => new GridChange(c.Grid, c.Tile)).ToList();
            int moved = 0;
            if (refill)
            {
                for (int i = 0; i < bag.After.Length; i++)
                {
                    var target = bag.After[i];
                    if (!bag.Grid.IsSlotLocked(i) || target.IsEmpty()) continue;
                    foreach (var source in changes)
                    for (int j = 0; j < source.After.Length; j++)
                    {
                        var stack = source.After[j];
                        if (source.Grid.IsSlotLocked(j) || stack.IsEmpty() || !target.CanStackWith(stack, false)) continue;
                        int amount = PracticeMath.MoveCount(stack.count, target.count, target.itemValue.ItemClass.Stacknumber.Value);
                        target.count += amount; stack.count -= amount; moved += amount;
                        if (stack.count == 0) source.After[j] = ItemStack.Empty.Clone();
                    }
                }
            }
            else
            {
                for (int i = 0; i < bag.After.Length; i++)
                {
                    var stack = bag.After[i];
                    if (stack.IsEmpty() || bag.Grid.IsSlotLocked(i)) continue;
                    foreach (var destination in changes)
                    {
                        // A chest must already contain the item to receive it.
                        bool matching = destination.After.Any(s => !s.IsEmpty() && s.CanStackWith(stack, false));
                        if (!matching) continue;
                        int amount = Put(destination.After, destination.Grid, stack, stack.count, false);
                        stack.count -= amount; moved += amount;
                        if (stack.count == 0) break;
                    }
                    if (stack.count == 0) bag.After[i] = ItemStack.Empty.Clone();
                }
            }
            changes.Add(bag);
            Commit(changes);
            return moved;
        }

        private static int Put(ItemStack[] slots, ItemStackGrid grid, ItemStack template, int requested, bool allowLocked)
        {
            int remaining = requested;
            for (int pass = 0; pass < 2 && remaining > 0; pass++)
            for (int i = 0; i < slots.Length && remaining > 0; i++)
            {
                if (!allowLocked && grid.IsSlotLocked(i)) continue;
                var target = slots[i];
                if (pass == 0 && (target.IsEmpty() || !target.CanStackWith(template, false))) continue;
                if (pass == 1 && !target.IsEmpty()) continue;
                int amount = PracticeMath.MoveCount(remaining, target.IsEmpty() ? 0 : target.count, template.itemValue.ItemClass.Stacknumber.Value);
                if (target.IsEmpty()) { target = template.Clone(); target.count = 0; slots[i] = target; }
                target.count += amount;
                remaining -= amount;
            }
            return requested - remaining;
        }

        private static void Commit(List<GridChange> changes)
        {
            try
            {
                foreach (var change in changes) { change.Grid.SetItems(change.After, true); if (change.Tile != null) change.Tile.setModified(); }
            }
            catch
            {
                foreach (var change in changes) { change.Grid.SetItems(change.Before, true); if (change.Tile != null) change.Tile.setModified(); }
                throw;
            }
        }
    }

}
