param([string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '..\Update-Core.ps1')
$root=Join-Path $PSScriptRoot ('..\..\work\skill-screen-test-'+[guid]::NewGuid().ToString('N'))
Write-WorkshopSkillScreen $root $GameDirectory
$checks=0
foreach($name in @('windows.xml','templates.xml')) {
    [xml]$baseline=Get-Content -LiteralPath (Join-Path $GameDirectory ('Data\Config\XUi_InGame\'+$name)) -Raw
    [xml]$patch=Get-Content -LiteralPath (Join-Path $root ('Profile\Mods\GrimmerWorkshop\Config\XUi_InGame\'+$name)) -Raw
    foreach($operation in $patch.DocumentElement.ChildNodes) {
        if($operation.NodeType -ne 'Element') { continue }
        $targets=$baseline.SelectNodes($operation.GetAttribute('xpath'))
        if(-not $targets.Count) { throw ('Missing XUi target: '+$operation.GetAttribute('xpath')) }
        $checks++
        foreach($target in $targets) {
            if($operation.Name -eq 'set') { $target.Value=$operation.InnerText }
            elseif($operation.Name -eq 'append') { foreach($child in $operation.ChildNodes) { if($child.NodeType -eq 'Element') { $null=$target.AppendChild($baseline.ImportNode($child,$true)) } } }
            else { throw 'Unknown patch operation' }
        }
    }
    if($name -eq 'windows.xml') {
        $window=$baseline.SelectSingleNode("/windows/window[@name='windowSkillCraftingInfo']")
        for($i=1;$i -le 14;$i++) { if(-not $window.SelectSingleNode(".//*[@name='itemIcon$i']")) { throw 'Native unlock icon was removed.' }; $checks++ }
        if($window.SelectNodes(".//*[@name='grimmerPracticePanel']").Count -ne 1) { throw 'Missing/duplicate practice panel.' }
        $table=$window.SelectSingleNode(".//rect[@name='tableBox']")
        if($table.GetAttribute('pos') -ne '0,-380' -or $table.grid.GetAttribute('rows') -ne '3') { throw 'Table does not make room for practice panel.' }
        if($window.GetAttribute('hidden_entries_with_paging') -ne '1' -or -not $window.SelectSingleNode(".//pager[@name='pager']")) { throw 'Native paging was removed.' }
        $panel=$window.SelectSingleNode(".//rect[@name='grimmerPracticePanel']")
        if($panel.GetAttribute('height') -ne '100' -or $panel.SelectNodes('label').Count -ne 3) { throw 'Practice panel content incomplete.' }
        $checks+=4
    }
}
Write-Host "Passed $checks skill screen layout checks: every target exists, native unlock icons/paging retained, progress panel and list bars added."
