param([string]$GameDirectory='C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot '..\Update-Core.ps1')
$catalog=@(Get-WorkshopBookCatalog $GameDirectory)
if (@($catalog | Where-Object Category -eq 'craftingMagazines').Count -ne 24) { throw 'Expected 24 crafting magazine types.' }
if (@($catalog | Where-Object Category -eq 'perkBooks').Count -lt 100 -or @($catalog | Where-Object Category -eq 'schematics').Count -lt 50) { throw 'Book categories incomplete.' }
[xml]$settings='<workshop />'
$disabled=@(Get-WorkshopDisabledBooks $settings $catalog)
if ($disabled.Count -ne 24) { throw 'Default policy should disable only crafting magazines.' }
[xml]$settings='<workshop><books craftingMagazines="true" perkBooks="false" schematics="true"><allow item="bookFiremansAlmanacHeat"/><deny item="modGunBipodSchematic"/></books></workshop>'
$disabled=@(Get-WorkshopDisabledBooks $settings $catalog)
if ($disabled -contains 'harvestingToolsSkillMagazine' -or $disabled -contains 'bookFiremansAlmanacHeat' -or $disabled -notcontains 'modGunBipodSchematic') { throw 'Individual book overrides failed.' }
$root=Join-Path $PSScriptRoot ('..\..\work\book-policy-test-' + [guid]::NewGuid().ToString('N'))
$mod=Join-Path $root 'Profile\Mods\GrimmerWorkshop'
New-Item -ItemType Directory -Path $mod -Force | Out-Null
'<workshop />' | Set-Content -LiteralPath (Join-Path $mod 'WorkshopSettings.xml') -Encoding UTF8
$count=Write-WorkshopBookPolicy $root $GameDirectory
if ($count -ne 24) { throw 'Wrong default disabled count.' }
$changes=0
foreach($file in @('loot.xml','traders.xml')) {
    [xml]$original=Get-Content -LiteralPath (Join-Path $GameDirectory ('Data\Config\'+$file)) -Raw
    [xml]$patch=Get-Content -LiteralPath (Join-Path $mod ('Config\'+$file)) -Raw
    foreach($operation in $patch.configs.set) {
        $matches=$original.SelectNodes($operation.GetAttribute('xpath'))
        if (-not $matches.Count -or $operation.InnerText -ne 'resourcePaper') { throw 'Invalid book replacement target.' }
        foreach($match in $matches) { $match.Value=$operation.InnerText; $changes++ }
    }
    foreach($name in @(Get-WorkshopDisabledBooks ([xml]'<workshop />') $catalog)) {
        if ($original.SelectNodes("//item[@name='$name']").Count) { throw "Disabled book still generated: $name" }
    }
}
# Re-enable every category and confirm generated files are emptied, not accumulated.
'<workshop><books craftingMagazines="true" perkBooks="true" schematics="true" /></workshop>' | Set-Content -LiteralPath (Join-Path $mod 'WorkshopSettings.xml') -Encoding UTF8
if ((Write-WorkshopBookPolicy $root $GameDirectory) -ne 0) { throw 'Re-enable books failed.' }
foreach($file in @('loot.xml','traders.xml')) { [xml]$patch=Get-Content -LiteralPath (Join-Path $mod ('Config\'+$file)) -Raw; if ($patch.SelectNodes('/configs/*').Count) { throw 'Stale disabled rules remained.' } }
Write-Host "Book policy passed: $($catalog.Count) selectable books, 24 magazines, $changes loot/trader references checked, individual overrides and full re-enable."
