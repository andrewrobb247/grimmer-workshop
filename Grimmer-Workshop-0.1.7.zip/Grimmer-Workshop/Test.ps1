$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$testDirectory = Join-Path $PSScriptRoot '..\work\workshop-tests'
New-Item -ItemType Directory -Path $testDirectory -Force | Out-Null
$testExecutable = Join-Path $testDirectory 'RegressionTests.exe'
& $compiler /nologo /target:exe ("/out:" + $testExecutable) (Join-Path $PSScriptRoot 'Source\Storage.cs') (Join-Path $PSScriptRoot 'Source\PracticeMath.cs') (Join-Path $PSScriptRoot 'Source\ActivityBudget.cs') (Join-Path $PSScriptRoot 'Source\SkillScreenText.cs') (Join-Path $PSScriptRoot 'Source\SkillScreen.cs') (Join-Path $PSScriptRoot 'Source\CraftingUi.cs') (Join-Path $PSScriptRoot 'Tests\FakeGame.cs') (Join-Path $PSScriptRoot 'Tests\RegressionTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Regression test compilation failed.' }
& $testExecutable
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed.' }



