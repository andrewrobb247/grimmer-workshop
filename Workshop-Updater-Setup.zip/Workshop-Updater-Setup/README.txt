Workshop updater setup (0.1.3 testing preview)

This is the final manual setup package for your existing Workshop installation.
Save and quit 7 Days to Die. Extract this ZIP and run Install-Updater.cmd.
Then open your usual Launch-Workshop.cmd: it now opens the Workshop launcher.
It includes Play, Check for updates, Install update, Display settings,
Game folder and Roll back update, with stable/testing channel selection.

It installs only the pack's files and keeps worlds, practice and settings.
A previous-file backup is kept in Profile\Updates for rollback.
Includes the 0.1.2 quality and scrap practice changes.

Online updates use the public GitHub repository
andrewrobb247/grimmer-workshop and its testing channel.
The first release is testing only. Stable will follow live testing.

Local updater tests pass; online downloads and the first visible launcher
run still need checking after publication. Requires your own V3.4 b10 game.
Solo only. No game binaries, credentials, logs or saved worlds are included.


