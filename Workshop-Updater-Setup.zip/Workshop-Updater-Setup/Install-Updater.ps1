param(
    [string]$InstallDirectory = (Join-Path $env:USERPROFILE 'Downloads\Grimmer-Workshop-0.1\Grimmer-Workshop'),
    [string]$GameDirectory = 'C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die',
    [switch]$NoPause
)
$ErrorActionPreference = 'Stop'
try {
    if (-not (Test-Path -LiteralPath (Join-Path $InstallDirectory 'Profile\Mods\GrimmerWorkshop\GrimmerWorkshop.dll'))) {
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object Windows.Forms.FolderBrowserDialog
        $picker.Description = 'Select your existing Grimmer-Workshop folder containing Launch-Workshop.cmd'
        if ($picker.ShowDialog() -ne 'OK') { return }
        $InstallDirectory = $picker.SelectedPath
    }
    if (-not (Test-Path -LiteralPath (Join-Path $InstallDirectory 'Profile\Mods\GrimmerWorkshop\GrimmerWorkshop.dll'))) { throw 'Select the existing Workshop installation, not its Profile folder.' }
    . (Join-Path $PSScriptRoot 'Payload\Update-Core.ps1')
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'Preview-Release.json') -Raw | ConvertFrom-Json
    $payloadRoot = Join-Path $PSScriptRoot 'Payload'
    $fetch = {
        param($url,$destination)
        $prefix = "https://raw.githubusercontent.com/andrewrobb247/grimmer-workshop/main/versions/$($manifest.version)/"
        if (-not $url.StartsWith($prefix,[StringComparison]::Ordinal)) { throw 'Invalid setup payload address.' }
        $relative = $url.Substring($prefix.Length)
        Copy-Item -LiteralPath (Resolve-WorkshopFile $payloadRoot $relative) -Destination $destination
    }.GetNewClosure()
    Write-Host (Install-WorkshopRelease $InstallDirectory $manifest $GameDirectory $fetch) -ForegroundColor Green
    Write-Host 'Open Launch-Workshop.cmd to use the new launcher. Online updates begin after GitHub publication.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if ($NoPause) { throw }
} finally { if (-not $NoPause) { Read-Host 'Press Enter to close' | Out-Null } }

