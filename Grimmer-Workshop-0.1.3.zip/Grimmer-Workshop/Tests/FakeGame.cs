// A small test harness for the original storage algorithm. Production builds
// reference the real game assemblies instead of these in-memory fixtures.
using System;
using System.Collections.Generic;
using System.Linq;

namespace UnityEngine
{
    public static class Time { public static float realtimeSinceStartup; }
    public struct Vector3
    {
        public float x, y, z;
        public Vector3(float a, float b, float c) { x = a; y = b; z = c; }
        public static Vector3 operator -(Vector3 a, Vector3 b) { return new Vector3(a.x-b.x, a.y-b.y, a.z-b.z); }
        public float sqrMagnitude { get { return x*x + y*y + z*z; } }
    }
}
public struct Vector3i { public int x, y, z; }
public class DataItem { public int Value = 100; }
public class ItemClass { public DataItem Stacknumber = new DataItem(); }
public class ItemValue
{
    public int type;
    public bool HasQuality;
    public string Variant = "";
    public ItemClass ItemClass = new ItemClass();
    public ItemValue(int id, bool ignored) { type = id; }
    public ItemValue Clone() { return new ItemValue(type, false) { HasQuality = HasQuality, Variant = Variant, ItemClass = ItemClass }; }
}
public class ItemStack
{
    public ItemValue itemValue;
    public int count;
    public static ItemStack Empty { get { return new ItemStack(new ItemValue(0, false), 0); } }
    public ItemStack(ItemValue value, int amount) { itemValue=value; count=amount; }
    public bool IsEmpty() { return count <= 0 || itemValue.type == 0; }
    public ItemStack Clone() { return new ItemStack(itemValue.Clone(), count); }
    public bool CanStackWith(ItemStack other, bool ignored) { return itemValue.type == other.itemValue.type && itemValue.Variant == other.itemValue.Variant; }
}
public class ItemStackGrid
{
    public ItemStack[] Slots;
    public HashSet<int> Locks = new HashSet<int>();
    public bool FailNextWrite;
    public ItemStackGrid(int count) { Slots=Enumerable.Range(0,count).Select(i=>ItemStack.Empty).ToArray(); }
    public int Length { get { return Slots.Length; } }
    public ItemStack this[int i] { get { return Slots[i]; } }
    public bool IsSlotLocked(int i) { return Locks.Contains(i); }
    public ItemStack[] CloneItems() { return Slots.Select(s=>s.Clone()).ToArray(); }
    public void SetItems(ItemStack[] items, bool ignored)
    {
        if (FailNextWrite) { FailNextWrite=false; throw new Exception("Injected write failure"); }
        Slots=items.Select(s=>s.Clone()).ToArray();
    }
}
public class Bag
{
    public ItemStackGrid ItemGrid;
    public Bag(int size) { ItemGrid=new ItemStackGrid(size); }
    public int GetItemCount(ItemValue value, int a, int b, bool c) { return ItemGrid.Slots.Where(s=>s.itemValue.type==value.type).Sum(s=>s.count); }
}
public class Inventory
{
    public int GetItemCount(ItemValue value, bool a, int b, int c, bool d) { return 0; }
}
public class TileEntity { public virtual void setModified() {} }
public class TEFeatureStorage { public ItemStackGrid ItemGrid; }
public class TileEntityComposite : TileEntity
{
    public bool PlayerPlaced=true, LocalPlayerIsOwner=true, Accessing;
    public TEFeatureStorage Storage;
    public Vector3i Position;
    public bool IsUserAccessing() { return Accessing; }
    public Vector3i ToWorldPos() { return Position; }
    public T GetFeature<T>() where T:class { return Storage as T; }
}
public class TileList { public List<TileEntity> list=new List<TileEntity>(); }
public class Chunk { public TileList Tiles=new TileList(); public TileList GetTileEntities() { return Tiles; } }
public class World
{
    public Chunk Chunk=new Chunk();
    public object GetChunkFromWorldPos(int x,int z) { return x == 0 && z == 0 ? Chunk : null; }
}
public class EntityPlayerLocal
{
    public UnityEngine.Vector3 position=new UnityEngine.Vector3(1,1,1);
    public Bag bag;
    public Inventory inventory=new Inventory();
    public World world=new World();
}
namespace GrimmerWorkshop
{
    public static class Workshop
    {
        public static int Range=20;
        public static bool NearbyCrafting=true;
        public static EntityPlayerLocal Current;
        public static EntityPlayerLocal Player() { return Current; }
    }
}
namespace HarmonyLib
{
    public class HarmonyPatch : Attribute { public HarmonyPatch(Type type,string name) {} }
}
public class XUiWindowGroup { public bool isShowing=true; public XUiController Controller; }
public class XUiController
{
    public XUiWindowGroup WindowGroup;
    public bool IsDirty;
    public XUiC_WorkstationInputGrid Input;
    public T GetChildByType<T>() where T:class { return Input as T; }
}
public class XUiC_RecipeList : XUiController {}
public class XUiC_IngredientEntry : XUiController {}
public class XUiC_RecipeCraftCount : XUiController
{
    public int RefreshCalls;
    public void RefreshCounts() { RefreshCalls++; }
}
public class XUiC_WorkstationInputGrid : XUiController {}
public class XUiC_WorkstationMaterialInputGrid : XUiC_WorkstationInputGrid {}
public static class XUiM_Recipes { public static bool DisableSmelter; }
