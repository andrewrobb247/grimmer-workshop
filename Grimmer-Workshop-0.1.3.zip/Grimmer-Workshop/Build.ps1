param([string]$GameDirectory = 'C:\Program Files (x86)\Steam\steamapps\common\7 Days To Die')
$ErrorActionPreference = 'Stop'
$managed = Join-Path $GameDirectory '7DaysToDie_Data\Managed'
$modDirectory = Join-Path $PSScriptRoot 'Profile\Mods\GrimmerWorkshop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$referenceNames = @('mscorlib.dll', 'System.dll', 'System.Core.dll', 'System.Xml.dll', 'System.Xml.Linq.dll', 'netstandard.dll', 'Assembly-CSharp.dll', 'Assembly-CSharp-firstpass.dll', 'UnityEngine.CoreModule.dll', 'LogLibrary.dll')
$references = $referenceNames | ForEach-Object { '/reference:' + (Join-Path $managed $_) }
$harmony = Join-Path $GameDirectory 'Mods\0_TFP_Harmony\0Harmony.dll'
New-Item -ItemType Directory -Path $modDirectory -Force | Out-Null
& $compiler /nologo /noconfig /target:library /nostdlib /optimize+ ("/out:" + (Join-Path $modDirectory 'GrimmerWorkshop.dll')) $references ("/reference:" + $harmony) (Join-Path $PSScriptRoot 'Source\Workshop.cs') (Join-Path $PSScriptRoot 'Source\Storage.cs') (Join-Path $PSScriptRoot 'Source\PracticeMath.cs') (Join-Path $PSScriptRoot 'Source\CraftingUi.cs')
if ($LASTEXITCODE -ne 0) { throw 'Game mod compilation failed.' }
python (Join-Path $PSScriptRoot 'Source\generate_config.py') $GameDirectory $modDirectory
if ($LASTEXITCODE -ne 0) { throw 'Configuration generation failed.' }
