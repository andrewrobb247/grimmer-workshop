using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using GrimmerWorkshop;
namespace GrimmerWorkshop { public sealed class PracticeRule {public string Item,Skill; public int Output,Unlock,Until,Cap;public int Units=1;public double Credit;} }
class VehiclePackRulesTests
{
    static int checks;
    static void Check(bool value,string name){checks++;if(!value)throw new Exception(name);}
    static void Main(string[] args)
    {
        var baseline=new Dictionary<string,List<PracticeRule>>();
        foreach(var node in XDocument.Load(args[1]).Root.Elements("rule")) {
            string name=(string)node.Attribute("item");
            if(!baseline.ContainsKey(name))baseline[name]=new List<PracticeRule>();
            baseline[name].Add(new PracticeRule{Item=name,Unlock=(int)node.Attribute("unlock")});
        }
        var rules=VehiclePackRules.Read(args[0],baseline);
        Check(rules.Count==106 && rules.Select(r=>r.Item).Distinct().Count()==106,"One route for every inspected output");
        var recipes=XDocument.Load(Path.Combine(args[0],"Config","recipes.xml"));
        foreach(var rule in rules){
            Check(rule.Skill=="craftingVehicles" && rule.Output==1 && rule.Units==1,"Single vehicle award");
            Check(rule.Unlock>=1 && rule.Unlock<=100 && rule.Until>=rule.Unlock && rule.Cap==100,"Valid author/ingredient-derived gate");
            var recipe=recipes.Descendants("recipe").Single(r=>(string)r.Attribute("name")==rule.Item);
            Check((int)recipe.Attribute("count")==rule.Output,"Output normalization matches original");
            foreach(var ingredient in recipe.Elements("ingredient")) {
                var local=rules.FirstOrDefault(r=>r.Item==(string)ingredient.Attribute("name"));
                if(local!=null)Check(rule.Unlock>=local.Unlock,"Assembly relevance includes its component gates");
            }
        }
        Check(rules.Single(r=>r.Item=="vehicleDirtBikeChassis").Unlock==45,"Dirt bike retains author level 45");
        Check(rules.Single(r=>r.Item=="vehiclePickupplaceable").Unlock==70,"Pickup follows author parts level 70");
        Check(rules.Single(r=>r.Item=="vehicleBoxTruckPlainplaceable").Unlock==70,"Cargo truck follows level 70");
        Check(rules.Single(r=>r.Item=="vehicleUH60placeable").Unlock==100,"Late helicopter remains level 100");
        Check(rules.Single(r=>r.Item=="modVehicleHumveeDoors").Credit==2,"Small attachment award");
        Check(rules.Where(r=>r.Item.EndsWith("placeable",StringComparison.OrdinalIgnoreCase)).All(r=>r.Credit==15),"Completed assemblies award 15 base practice");
        Check(VehiclePackRules.Read(Path.Combine(args[0],"missing"),baseline).Count==0,"Absent optional pack leaves vanilla intact");
        int original=baseline.Count;
        var skills=new HashSet<string>();
        Check(VehiclePackRules.Register(Path.Combine(Path.GetDirectoryName(args[0]),"GrimmerWorkshop"),baseline,skills)==106,"Runtime registration discovers separate folder");
        Check(baseline.Count==original+106,"Existing rules preserved");
        bool rejected=false;try{VehiclePackRules.Register(Path.Combine(Path.GetDirectoryName(args[0]),"GrimmerWorkshop"),baseline,skills);}catch(InvalidDataException){rejected=true;}
        Check(rejected&&baseline.Count==original+106,"Duplicate registration fails atomically");
        Console.WriteLine("PASS: "+checks+" Bdub metadata/recipe/practice checks; "+rules.Count+" outputs.");
    }
}
