using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using GrimmerWorkshop;
namespace GrimmerWorkshop {public sealed class PracticeRule{public string Item,Skill;public int Output,Unlock,Until,Cap;public int Units=1;public double Credit;}}
class DecorRulesTests
{
    static int checks;
    static void Check(bool value,string label){checks++;if(!value)throw new Exception(label);}
    static void Main(string[] args)
    {
        var rows=DecorRules.Read(args[0]);
        Check(rows.Count==15 && rows.Select(r=>r.Item).Distinct().Count()==15,"15 unique outputs from 16 genuine recipes");
        foreach(var row in rows){
            Check(row.Skill=="craftingConstruction" && row.Output==1 && row.Units==1,"One Construction route per output");
            Check(row.Unlock==1 && row.Until>=10 && row.Until<=60 && row.Cap==100,"Normal relevance and Construction cap");
        }
        Check(rows.Single(r=>r.Item=="HoistVariantHelper").Credit==.1,"One-iron hoist cannot give a large practice award");
        Check(rows.Single(r=>r.Item=="JailVariantHelper").Credit==8,"Costly steel door gets higher award");
        Check(rows.Count(r=>r.Item=="barrierMilitary")==1,"Two material alternatives do not duplicate credit");
        Check(DecorRules.Read(Path.Combine(args[0],"absent")).Count==0,"Optional pack absent");
        var rules=new Dictionary<string,List<PracticeRule>>{{"native",new List<PracticeRule>()}};
        var skills=new HashSet<string>();
        Check(DecorRules.Register(Path.Combine(Path.GetDirectoryName(args[0]),"GrimmerWorkshop"),rules,skills)==15,"Separate original folder discovered");
        Check(rules.Count==16&&rules.ContainsKey("native"),"Native routes retained");
        bool rejected=false;try{DecorRules.Register(Path.Combine(Path.GetDirectoryName(args[0]),"GrimmerWorkshop"),rules,skills);}catch(InvalidDataException){rejected=true;}
        Check(rejected&&rules.Count==16,"Duplicate registration fails atomically");
        Check(DecorRules.HasConstructionRoute("HoistVariantHelper",rules),"Registered decor receives Construction time bonus");
        Check(!DecorRules.HasConstructionRoute("native",rules),"Native recipes keep their existing bonus path");
        Check(!DecorRules.HasConstructionRoute("HoistVariantHelper",new Dictionary<string,List<PracticeRule>>()),"Absent pack cannot grant decor bonus");
        Check(DecorRules.TimeMultiplier(1)==1f&&Math.Abs(DecorRules.TimeMultiplier(100)-.85f)<.00001,"Same 0 to 15 percent Construction bonus endpoints");
        Check(DecorRules.TimeMultiplier(0)==1f&&Math.Abs(DecorRules.TimeMultiplier(150)-.85f)<.00001,"Skill range clamped");
        Console.WriteLine("PASS: "+checks+" Beautiful Bases recipe/practice checks.");
    }
}
