using System;
using System.Collections.Generic;
using GrimmerWorkshop;
namespace HarmonyLib{public class HarmonyPatch:Attribute{public HarmonyPatch(Type t,string n){}}}
public class XUiM_Recipes{}
public class Recipe{public ItemClass item;public ItemClass GetOutputItemClass(){return item;}}
public class ItemClass{public string name;public string GetItemName(){return name;}}
public class Player{public Progression Progression=new Progression();}
public class Progression{public Skill skill=new Skill();public Skill GetProgressionValue(string n){return skill;}}
public class Skill{public int Level=1;}
namespace GrimmerWorkshop{public static class Workshop{public static Player player=new Player();public static Player Player(){return player;}public static Dictionary<string,List<PracticeRule>> Rules=new Dictionary<string,List<PracticeRule>>();}}
class DecorTimeTests
{
    static int checks;
    static void Check(bool v,string n){checks++;if(!v)throw new Exception(n);}
    static void Main(){
        var recipe=new Recipe{item=new ItemClass{name="HoistVariantHelper"}};
        float time=60;DecorTime.Postfix(recipe,ref time);Check(time==60,"Unregistered recipe unchanged");
        Workshop.Rules[recipe.item.name]=new List<PracticeRule>{new PracticeRule{Skill="craftingConstruction"}};
        time=60;DecorTime.Postfix(recipe,ref time);Check(time==60,"Construction one has no speed advantage");
        Workshop.player.Progression.skill.Level=100;time=60;DecorTime.Postfix(recipe,ref time);Check(Math.Abs(time-51)<.0001,"Construction 100 changes actual recipe time by 15 percent");
        recipe.item.name="workbench";time=60;DecorTime.Postfix(recipe,ref time);Check(time==60,"Ordinary recipe keeps native perk timing");
        recipe.item.name="HoistVariantHelper";Workshop.player=null;time=60;DecorTime.Postfix(recipe,ref time);Check(time==60,"Solo-only scope preserved");
        time=60;DecorTime.Postfix(null,ref time);Check(time==60,"Null recipe safe");
        Console.WriteLine("PASS: "+checks+" decor craft-time integration checks.");
    }
}
