"""Apply native + author's original group appends + our companion and check limits."""
import copy
import math
import re
import sys
from pathlib import Path
import xml.etree.ElementTree as E
native_dir, pack, generated = map(Path,sys.argv[1:])
native=E.parse(native_dir/'entitygroups.xml').getroot()
source=E.parse(pack/'Config/entitygroups.xml').getroot()
patch=E.parse(generated/'Config/entitygroups.xml').getroot()
groups={g.get('name'):copy.deepcopy(g) for g in native}
originals={g.get('name'):copy.deepcopy(g) for g in native}
custom={c.get('name') for c in E.parse(pack/'Config/entityclasses.xml').getroot().findall('append/entity_class')}
classes={c.get('name') for c in E.parse(native_dir/'entityclasses.xml').getroot()}
checks=0
def check(v,m):
 global checks
 checks+=1
 assert v,m
for c in E.parse(pack/'Config/entityclasses.xml').getroot().findall('append/entity_class'):
 check(c.get('extends') in classes|custom,'Missing native/custom parent')
for append in source:
 name=re.fullmatch(r"/entitygroups/entitygroup\[@name='([^']+)'\]",append.get('xpath')).group(1)
 check(name in groups,'Missing native group')
 for entry in append.findall('e'):
  check(entry.get('n') in classes|custom,'Missing spawned entity')
  groups[name].append(copy.deepcopy(entry))
excluded=set()
for op in patch:
 if op.tag=='remove':
  entity=re.fullmatch(r"/entitygroups/entitygroup/e\[@n='([^']+)'\]",op.get('xpath')).group(1)
  check(entity in custom,'Never remove native zombies')
  excluded.add(entity)
  for group in groups.values():
   for entry in list(group):
    if entry.get('n')==entity:group.remove(entry)
 elif op.tag=='setattribute':
  name,condition=re.fullmatch(r"/entitygroups/entitygroup\[@name='([^']+)'\]/e\[(.+)\]",op.get('xpath')).groups()
  entities=re.findall(r"@n='([^']+)'",condition)
  check(entities and all(entity in custom and entity not in excluded for entity in entities),'Only selected custom weights change')
  check(op.get('name')=='p' and math.isfinite(float(op.text)) and float(op.text)>=0,'Valid non-negative probability weight')
  matches=[x for x in groups[name] if x.get('n') in entities]
  check(bool(matches),'Weight selector matches author entries')
  for e in matches:e.set('p',op.text)
 else:raise AssertionError('Unexpected patch operation')
selected=custom-excluded
check(len(selected)==21,'21 grounded appearances selected')
check({'zombieBabyBoomer','zombieMeaty','zombieBiomechanicalWight'}.issubset(excluded),'Special roster excluded from natural spawns')
for name,group in groups.items():
 before=originals[name]
 check([e.attrib for e in group if e.get('n') not in custom]==[e.attrib for e in before],'Native group entries unchanged')
 added=[e for e in group if e.get('n') in custom]
 check(all(e.get('n') in selected for e in added),'Unselected entities absent from natural spawns')
 base=sum(max(0,float(e.get('p','1'))) for e in before)
 added_weight=sum(float(e.get('p','1')) for e in added)
 check(added_weight<=base*.25+1e-5,'Custom group share capped at 20% with native+Guppy only')
print(f'PASS: {checks} original-pack/native-reference/companion spawn checks; 21 of {len(custom)} entity declarations selected.')
