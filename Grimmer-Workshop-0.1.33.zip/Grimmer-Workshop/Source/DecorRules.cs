using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace GrimmerWorkshop
{
    // Read-only practice mapping; the separately installed author files stay intact.
    public static class DecorRules
    {
        public static float TimeMultiplier(int level)
        {
            return 1f-.15f*Math.Max(0,Math.Min(99,level-1))/99f;
        }
        public static bool HasConstructionRoute(string item,Dictionary<string,List<PracticeRule>> rules)
        {
            List<PracticeRule> routes;
            return item!=null && credits.ContainsKey(item) && rules.TryGetValue(item,out routes) &&
                routes.Any(r=>r.Skill=="craftingConstruction");
        }
        static readonly Dictionary<string,double> credits=new Dictionary<string,double> {
            {"flagBlockVariantHelper",2},{"JailVariantHelper",8},{"barbedWireSpindleVariantHelper",1},
            {"HoistVariantHelper",.1},{"barrierMilitary",.5},{"CorrugatedMetalSheetVariantHelper",1},
            {"BanditPlatformVariantHelper",1},{"flagPoleWhiteRiver",4},{"flagPoleTrader",4},
            {"flagPoleAmerican",4},{"GNS_Wall_Sign_Round",3},{"GNS_Sign_Logo",3},
            {"GNS_Sign_Logo_Backplate",3},{"GNS_Sign_Initials",3},{"capChimneyLargeSmoke",1}
        };
        public static List<PracticeRule> Read(string pack)
        {
            if(!Directory.Exists(pack))return new List<PracticeRule>();
            var info=XDocument.Load(Path.Combine(pack,"ModInfo.xml"));
            if((string)info.Root.Element("Name").Attribute("value")!="GNS_BeautifulBases" ||
               (string)info.Root.Element("Version").Attribute("value")!="2.0")
                throw new InvalidDataException("Decor practice supports the inspected Beautiful Bases archive (metadata 2.0) only.");
            var recipes=XDocument.Load(Path.Combine(pack,"Config","recipes.xml")).Root.Elements("append").Elements("recipe").ToArray();
            if(recipes.Length!=16 || recipes.Any(r=>(int?)r.Attribute("count")!=1 || !credits.ContainsKey((string)r.Attribute("name")??"")))
                throw new InvalidDataException("Beautiful Bases recipe outputs changed.");
            var result=new List<PracticeRule>();
            foreach(var pair in credits) {
                var matches=recipes.Where(r=>(string)r.Attribute("name")==pair.Key).ToArray();
                if(matches.Length!=(pair.Key=="barrierMilitary"?2:1))throw new InvalidDataException("Missing/duplicate decor output: "+pair.Key);
                int until=pair.Value>=8?60:pair.Value>=3?40:pair.Value>=1?25:pair.Value>=.5?20:10;
                result.Add(new PracticeRule{Item=pair.Key,Skill="craftingConstruction",Output=1,Unlock=1,Until=until,Cap=100,Credit=pair.Value});
            }
            return result;
        }
        public static int Register(string root,Dictionary<string,List<PracticeRule>> rules,HashSet<string> skills)
        {
            var additions=Read(Path.Combine(Path.GetDirectoryName(root.TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar)),"GNS_BeautifulBases"));
            if(additions.Any(r=>rules.ContainsKey(r.Item)))throw new InvalidDataException("Decor output already has a practice route; existing rules preserved.");
            foreach(var rule in additions)rules.Add(rule.Item,new List<PracticeRule>{rule});
            if(additions.Count>0)skills.Add("craftingConstruction");
            return additions.Count;
        }
    }
}
