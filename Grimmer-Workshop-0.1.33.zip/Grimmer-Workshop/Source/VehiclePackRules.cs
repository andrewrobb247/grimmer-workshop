using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

namespace GrimmerWorkshop
{
    // Read-only integration for the independently installed author pack.
    public static class VehiclePackRules
    {
        static int Unlock(string name, Dictionary<string,XElement> recipes, Dictionary<string,int> levels,
            Dictionary<string,List<PracticeRule>> baseline, HashSet<string> visiting)
        {
            int level;
            if (levels.TryGetValue(name,out level)) return level;
            XElement recipe;
            if (!recipes.TryGetValue(name,out recipe)) {
                List<PracticeRule> native;
                return baseline.TryGetValue(name,out native) && native.Count>0 ? native.Min(r=>r.Unlock) : 1;
            }
            if (!visiting.Add(name)) throw new InvalidDataException("Vehicle recipe cycle: "+name);
            if (((string)recipe.Attribute("tags")??"").Split(',').Contains("learnable"))
                throw new InvalidDataException("Vehicle recipe has an unrecognised unlock: "+name);
            level=1;
            foreach(var ingredient in recipe.Elements("ingredient"))
                level=Math.Max(level,Unlock((string)ingredient.Attribute("name"),recipes,levels,baseline,visiting));
            visiting.Remove(name);levels[name]=level;return level;
        }
        public static List<PracticeRule> Read(string pack, Dictionary<string,List<PracticeRule>> baseline)
        {
            if (!Directory.Exists(pack)) return new List<PracticeRule>();
            var info=XDocument.Load(Path.Combine(pack,"ModInfo.xml"));
            if ((string)info.Root.Element("Name").Attribute("value")!="Bdubs_Vehicles" ||
                (string)info.Root.Element("Version").Attribute("value")!="3.4.0.2")
                throw new InvalidDataException("Vehicle practice supports inspected Bdubs_Vehicles 3.4.0.2 only.");
            var document=XDocument.Load(Path.Combine(pack,"Config","recipes.xml"));
            var recipes=new Dictionary<string,XElement>();
            foreach(var recipe in document.Root.Elements("append").Elements("recipe")) {
                string name=(string)recipe.Attribute("name");
                if (name==null || (!name.StartsWith("vehicle",StringComparison.Ordinal) && name!="modVehicleHumveeDoors") ||
                    recipes.ContainsKey(name) || (int?)recipe.Attribute("count")!=1)
                    throw new InvalidDataException("Unsupported vehicle output: "+name);
                recipes.Add(name,recipe);
            }
            if(recipes.Count!=106) throw new InvalidDataException("Expected 106 inspected vehicle recipes.");
            var progression=XDocument.Load(Path.Combine(pack,"Config","progression.xml"));
            var levels=new Dictionary<string,int>();
            foreach(var append in progression.Root.Elements("append")) {
                if(!((string)append.Attribute("xpath")??"").Contains("crafting_skill[@name='craftingVehicles']/effect_group"))continue;
                foreach(var effect in append.Elements("passive_effect")) {
                    if((string)effect.Attribute("name")!="RecipeTagUnlocked")continue;
                    int level;
                    if(!int.TryParse(((string)effect.Attribute("level")??"").Split(',')[0],out level) || level<1 || level>100)
                        throw new InvalidDataException("Invalid author vehicle gate.");
                    foreach(string name in ((string)effect.Attribute("tags")??"").Split(',')) {
                        if(!recipes.ContainsKey(name) || levels.ContainsKey(name))throw new InvalidDataException("Unknown/duplicate vehicle unlock: "+name);
                        levels.Add(name,level);
                    }
                }
            }
            var result=new List<PracticeRule>();
            foreach(var pair in recipes) {
                int level=Unlock(pair.Key,recipes,levels,baseline,new HashSet<string>());
                bool assembly=pair.Key.EndsWith("placeable",StringComparison.OrdinalIgnoreCase);
                result.Add(new PracticeRule {Item=pair.Key,Skill="craftingVehicles",Unlock=level,Until=Math.Min(100,level+20),
                    Cap=100,Output=1,Credit=assembly?15:pair.Key=="modVehicleHumveeDoors"?2:8});
            }
            return result;
        }
        public static int Register(string root,Dictionary<string,List<PracticeRule>> rules,HashSet<string> skills)
        {
            var additions=Read(Path.Combine(Path.GetDirectoryName(root.TrimEnd(Path.DirectorySeparatorChar,Path.AltDirectorySeparatorChar)),"BdubsVehicles"),rules);
            if(additions.Any(r=>rules.ContainsKey(r.Item)))throw new InvalidDataException("Vehicle practice output already registered.");
            foreach(var rule in additions)rules.Add(rule.Item,new List<PracticeRule>{rule});
            if(additions.Count>0)skills.Add("craftingVehicles");
            return additions.Count;
        }
    }
}
