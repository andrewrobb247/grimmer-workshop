using HarmonyLib;

namespace GrimmerWorkshop
{
    [HarmonyPatch(typeof(XUiM_Recipes),"GetRecipeCraftTime")]
    public static class DecorTime
    {
        public static void Postfix(Recipe __1,ref float __result)
        {
            var player=Workshop.Player();
            if(player==null || __1==null)return;
            var output=__1.GetOutputItemClass();
            if(output==null || !DecorRules.HasConstructionRoute(output.GetItemName(),Workshop.Rules))return;
            var skill=player.Progression.GetProgressionValue("craftingConstruction");
            if(skill!=null)__result*=DecorRules.TimeMultiplier(skill.Level);
        }
    }
}
