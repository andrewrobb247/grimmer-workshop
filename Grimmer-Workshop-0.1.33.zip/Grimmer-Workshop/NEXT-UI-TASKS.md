# Next tasks

- User authorised four areas: new zombies/wildlife, farming/compost, workstation improvements, new drivable vehicles.
- 0.1.32 composting/restored stations and optional Guppy/Bdub support published; original files staged and installer preflight passes. Actual local installation/live checks pending.
- Guppy 3.0.3.0 downloaded/reviewed; original staged, own 21-entity spawn companion implemented. Local installation and live checks pending.
- Bdub 3.4.0.2 downloaded/reviewed; original staged, read-only practice for 106 outputs implemented. Local installation/driving checks pending. No inspection/recovery integration.
- Wildlife: KGX Wildlife held due to reported AI movement failure; no wildlife DLL installed or species/models claimed.
- Powered stations remain future work; current workstation addition is material-saving restoration, not electrical power integration.
- Vehicle inspection and component recovery are PARKED at user's request. Ordinary-car menu still reported broken on 0.1.31; locked police-car menu works. Do not spend time on it or imply fixed. Leave existing published feature untouched unless asked to disable it.
- Continue live Arsenal, Cooking Stove, Gunsmith, storage pickup and recipe display checks when convenient.

- Extras reviewed: Beautiful Bases and Looted look suitable for testing; Elisk adds major optional difficulty. No extras installed. See Source/DOWNLOAD-COMPATIBILITY.md.

- User selected Beautiful Bases and Looted: 0.1.33 mapping/installer prepared; live checks pending. Elisk stays uninstalled.
