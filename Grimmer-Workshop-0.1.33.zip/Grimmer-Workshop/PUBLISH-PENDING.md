# Publication status

0.1.33 decor/map candidate prepared; publication verification pending. Optional originals staged unchanged, not yet installed. Prior Guppy/Bdub folders confirmed present.
