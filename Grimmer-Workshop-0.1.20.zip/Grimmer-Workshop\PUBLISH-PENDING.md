# 0.1.20 release candidate

57 new ammunition practice routes; all 446 previous routes and recipe XML unchanged. Native bundle opening methods do not fire CraftedItem. 2,627 regressions, 34 layout checks, ammunition route/bundle audit and game compilation pass. Live ammo checks pending.
