# Remaining recipe coverage audit — 19 November 2026

Read-only audit against installed V3.4 b10 and Workshop 0.1.18. No practice rules or release versions changed. Categories are proposals, not verified final skill assignments.

228 unmapped recipe variants (208 distinct output names).

| Review category | Recipe variants |
| --- | ---: |
| ammunition manufacture | 52 |
| attachments | 75 |
| base fixtures | 10 |
| food packaging | 1 |
| food preparation | 11 |
| manual review | 28 |
| material processing | 36 |
| medical / survival | 6 |
| packing | 9 |

## Findings

- Cornmeal, aloe cream and splints are real preparation gaps.
- Some ammo bundles consume raw bullet tips, powder and casings. They are manufacturing recipes, not reversible packaging. Award against their contents, without a second opening award.
- Resource bundles package existing materials. Review item opening actions and exclude repeatable pack/unpack awards.
- Raw meat bundles consume meat plus paper/fibres; assess a small preparation award separately from ingredient recovery.
- Forge refund recipes explicitly have zero vanilla XP and can return smelted resources. Do not add a blanket skill award.
- Different recipe variants can produce different output quantities for the same item; the current item-based minimum-output rule needs review before broad coverage expansion.

## Implementation order

1. Add a small explicit set of food/medical preparation routes with tests for skill, output and caps.
2. Normalize mixed-output recipe variants before adding ammo/bulk processing awards.
3. Map attachments and remaining fixtures; preserve schematic and biome gates.
4. Audit reverse conversions and publish only after route-diff and batch-credit tests pass.
