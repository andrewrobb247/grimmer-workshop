# Publication complete

0.1.14 published 18 November 2026. All 20 runtime files and full archive verified. Windows PowerShell old-updater compatibility checked against live channel. No publication steps remain.
