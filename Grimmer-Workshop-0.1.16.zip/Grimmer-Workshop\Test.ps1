$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$testDirectory = Join-Path $PSScriptRoot '..\work\workshop-tests'
New-Item -ItemType Directory -Path $testDirectory -Force | Out-Null
$testExecutable = Join-Path $testDirectory 'RegressionTests.exe'
& $compiler /nologo /target:exe ("/out:" + $testExecutable) (Join-Path $PSScriptRoot 'Source\Storage.cs') (Join-Path $PSScriptRoot 'Source\PracticeMath.cs') (Join-Path $PSScriptRoot 'Source\ActivityBudget.cs') (Join-Path $PSScriptRoot 'Source\SkillScreenText.cs') (Join-Path $PSScriptRoot 'Source\SkillScreen.cs') (Join-Path $PSScriptRoot 'Source\CraftingUi.cs') (Join-Path $PSScriptRoot 'Tests\FakeGame.cs') (Join-Path $PSScriptRoot 'Tests\RegressionTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Regression test compilation failed.' }
& $testExecutable
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed.' }
$buttonTests = Join-Path $testDirectory 'StorageButtonTests.exe'
& $compiler /nologo /target:exe ("/out:" + $buttonTests) (Join-Path $PSScriptRoot 'Source\StorageButtons.cs') (Join-Path $PSScriptRoot 'Tests\StorageButtonTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Storage button test compilation failed.' }
& $buttonTests
if ($LASTEXITCODE -ne 0) { throw 'Storage button tests failed.' }




$creditTests = Join-Path $testDirectory 'WorkstationCreditTests.exe'
& $compiler /nologo /target:exe ("/out:" + $creditTests) (Join-Path $PSScriptRoot 'Source\WorkstationCredit.cs') (Join-Path $PSScriptRoot 'Tests\WorkstationCreditTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Workstation credit test compilation failed.' }
& $creditTests
if ($LASTEXITCODE -ne 0) { throw 'Workstation credit tests failed.' }
