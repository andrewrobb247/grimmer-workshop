# Publication complete

0.1.15 published 18 November 2026. All 20 runtime files and full archive verified. Windows PowerShell live updater compatibility passed. Grips still require live equip/effect testing.
