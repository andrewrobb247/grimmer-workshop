# Current state and next tasks

- 0.1.28 Cooking Stove prepared: Food 20, 49 fuel-burning cooking variants, 25% less craft time. Total 635 practice routes. Includes all cumulative 0.1.27 features.
- Publish and verify candidate through the now-authorised owner connection; live checks in PLAYTEST-CHECKLIST.md.
- Next original gameplay project: farming improvements with meaningful Seeds practice and a compost/resource loop.
- External weapon/enemy/vehicle models remain candidates in Source/NEXUS-CONTENT-IDEAS.md; permissions and isolated testing required before integration.
