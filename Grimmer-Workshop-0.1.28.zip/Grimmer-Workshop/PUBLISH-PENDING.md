# Publication status

Latest published: 0.1.27 testing. Cooking Stove 0.1.28 is prepared for publication after payload verification. It includes all previous cumulative features. Current staging ../Workshop-Publish-0128. GitHub owner installation 183715770 is now authorised and uploads worked for 0.1.27.

Upload all version payloads and source ZIP first; verify hosted bytes/hashes; publish channels/testing.json LAST; check unchanged 0.1.10 updater afterwards. Do not change version payloads after enabling the channel.

Cooking Stove: Food 20 gate, native wood-burning stove model and cooking UI, 49 source-preserving campfire recipe variants, 25% shorter native computed time, native tools/fuel/queue/completion behaviour retained. One new construction practice route, total 635. All 634 prior routes/custom recipes unchanged. No external assets.

Production build and all regressions pass; 17 specialist timing checks; configuration comparisons for all 49 variants and previous route/recipe preservation; previous launch helper retains stove companion identity; native timing/queue/claim layout checks pass. Live checks in PLAYTEST-CHECKLIST.md remain pending.