using System;
using HarmonyLib;

namespace GrimmerWorkshop
{
    [HarmonyPatch(typeof(XUiC_BackpackWindow), "Init")]
    public static class StorageButtons
    {
        public static void Postfix(XUiC_BackpackWindow __instance)
        {
            var deposit = __instance.GetChildById("grimmerDepositNearby");
            var refill = __instance.GetChildById("grimmerRefillNearby");
            // Remove before adding so repeated initialization cannot double-transfer.
            if (deposit != null) { deposit.OnPress -= Deposit; deposit.OnPress += Deposit; }
            if (refill != null) { refill.OnPress -= Refill; refill.OnPress += Refill; }
        }

        private static void Deposit(XUiController sender, int mouseButton) { Transfer(false, mouseButton); }
        private static void Refill(XUiController sender, int mouseButton) { Transfer(true, mouseButton); }

        private static void Transfer(bool refill, int mouseButton)
        {
            if (mouseButton != 0) return;
            var player = Workshop.Player();
            if (player == null) return;
            try
            {
                int count = Storage.Transfer(refill);
                string message = count > 0
                    ? (refill ? "Refilled " : "Deposited ") + count + " items using nearby storage."
                    : refill ? "Nothing refilled. Lock an occupied backpack slot and keep matching supplies in nearby closed storage."
                    : "Nothing deposited. Nearby closed storage must already contain matching items. Locked backpack slots stay protected.";
                GameManager.ShowTooltip(player, message, false, false, 3);
            }
            catch (Exception error)
            {
                Log.Error("[Grimmer Workshop] Storage button: " + error);
                GameManager.ShowTooltip(player, "Storage transfer failed. Check the Workshop game log.", false, false, 3);
            }
        }
    }
}
