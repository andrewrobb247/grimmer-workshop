# 0.1.21 release candidate

503 existing routes unchanged; all 75 vanilla attachment recipes get one practice route. Recipes unchanged byte-for-byte; specialist mappings, caps, awards and original Workshop grips checked. 2,627 regressions, 34 layout checks and game assembly compilation pass. Live attachment tests pending.
