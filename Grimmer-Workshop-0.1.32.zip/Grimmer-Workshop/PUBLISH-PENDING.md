# Publication status

0.1.32 composting/restoration candidate; hosted verification pending. New zombie/vehicle packs await original archives and are not installed. Vehicle inspection is parked.
