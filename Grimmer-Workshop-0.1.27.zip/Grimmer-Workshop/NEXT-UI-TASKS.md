# Current state and next tasks

- 0.1.27 Gunsmith Bench built, adding 118 specialist variants and one station route; total 634. Includes engine restoration, inspection and empty owned crate pickup. Not published; see PUBLISH-PENDING.md.
- Live checks in PLAYTEST-CHECKLIST.md; preserve the current world.
- Publish candidate once connector write access works; verify hosted payloads/source and old updater before enabling channel.
- Next original gameplay work: useful cooking stations and farming projects.
- For genuinely new weapon/enemy/vehicle models, evaluate the Nexus shortlist in an isolated profile and resolve author permissions before modifying/bundling. No external packs installed yet.
