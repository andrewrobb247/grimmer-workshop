using HarmonyLib;

namespace GrimmerWorkshop
{
    [HarmonyPatch(typeof(XUiM_Recipes), "GetRecipeCraftTime")]
    public static class GunsmithTime
    {
        public static void Postfix(Recipe __1, ref float __result)
        {
            if (__1 != null && __1.craftingArea == "grimmerGunsmithBench" && Workshop.Player() != null)
                __result *= .85f;
        }
    }
}
