"""Build original practice rules from the installed vanilla progression data."""
import csv
import sys
import xml.etree.ElementTree as ET
from collections import defaultdict
from pathlib import Path

game, destination = map(Path, sys.argv[1:])
config = game / 'Data' / 'Config'
progression = ET.parse(config / 'progression.xml').getroot()
recipes = ET.parse(config / 'recipes.xml').getroot()
skills = progression.findall('.//crafting_skill')
# Original Workshop skill: no magazine or replacement vanilla unlock requirements.
skills.append(ET.Element('crafting_skill', name='craftingConstruction', max_level='100'))
skill_names = {s.get('name') for s in skills}
recipe_by_name = defaultdict(list)
for recipe in recipes.findall('recipe'):
    if recipe.find('wildcard_forge_category') is None:
        recipe_by_name[recipe.get('name')].append(recipe)

rule_root = ET.Element('practiceRules')
rules = {}
coverage = defaultdict(list)

def add_rule(item, skill, unlock=1, until=20, cap=100, credit=10):
    if item not in recipe_by_name:
        raise ValueError(f'Missing recipe {item}')
    output = min(int(r.get('count', '1')) for r in recipe_by_name[item])
    rules[item, skill] = dict(item=item, skill=skill, output=str(output), unlock=str(unlock), until=str(until), cap=str(cap), credit=str(credit))

for skill in skills:
    name = skill.get('name')
    maximum = int(skill.get('max_level'))
    unlocks = {}
    for effect in skill.findall(".//passive_effect[@name='RecipeTagUnlocked']"):
        level = int(effect.get('level').split(',')[0])
        for item in effect.get('tags', '').split(','):
            if item in recipe_by_name:
                unlocks[item] = min(level, unlocks.get(item, level))
    levels = sorted(set(unlocks.values()))
    for item, level in unlocks.items():
        next_level = next((n for n in levels if n > level), maximum + 1)
        add_rule(item, name, level, next_level + 3, maximum)

# Recipes already tagged with a crafting skill include primitive tools that have
# no UnlockedBy property on their item definitions.
for item, item_recipes in recipe_by_name.items():
    tags = set(','.join(r.get('tags', '') for r in item_recipes).split(','))
    for skill in tags & skill_names:
        if not any(existing_item == item for existing_item, _ in rules):
            maximum = int(next(s for s in skills if s.get('name') == skill).get('max_level'))
            add_rule(item, skill, 1, 15, maximum)

# Bootstrap paths use practical consumables and preparation recipes. The cap
# directs players onto the category's unlocked equipment once it becomes available.
bootstrap = [
    ('resourceCloth', 'craftingBackpack', 5, 5),
    ('resourceGunPowder', 'craftingExplosives', 2, 2),
    ('foodCharredMeat', 'craftingFood', 2, 10),
    ('medicalBandage', 'craftingMedical', 5, 8),
    ('resourceDuctTape', 'craftingVehicles', 5, 6),
    ('resourceRepairKit', 'craftingRepairTools', 4, 10),
    ('resourceMechanicalParts', 'craftingSalvageTools', 4, 8),
    ('resourceElectricParts', 'craftingElectrician', 25, 8),
    ('trapSpikesWoodDmg0', 'craftingTraps', 25, 5),
    ('farmPlotBlockVariantHelper', 'craftingSeeds', 2, 10),
    ('meleeWpnBatonT0PipeBaton', 'craftingRobotics', 11, 10),
    ('campfire', 'craftingWorkstations', 4, 10),
]

# Add workshop assembly recipes for mechanical and electrical components.
recipe_patch = ET.Element('configs')
append = ET.SubElement(recipe_patch, 'append', xpath='/recipes')
for item, ingredients in [
    ('resourceMechanicalParts', [('resourceForgedIron', 2), ('resourceScrapPolymers', 2)]),
    ('resourceElectricParts', [('resourceScrapIron', 5), ('resourceScrapPolymers', 3)])
]:
    recipe = ET.SubElement(append, 'recipe', name=item, count='1', craft_time='12', tags='grimmerWorkshopAssembly', always_unlocked='true')
    for ingredient, count in ingredients:
        ET.SubElement(recipe, 'ingredient', name=ingredient, count=str(count))
    recipe_by_name[item].append(recipe)

# Fixed-effect melee grips: craftable at a workbench without a schematic.
for item, seconds, ingredients in [
    ('grimmerLightGrip', 20, [('resourceLeather', 4), ('resourceScrapPolymers', 6), ('resourceDuctTape', 2)]),
    ('grimmerPowerGrip', 30, [('resourceForgedIron', 8), ('resourceSpring', 2), ('resourceDuctTape', 2)]),
    ('grimmerLightToolGrip', 20, [('resourceLeather', 4), ('resourceScrapPolymers', 8), ('resourceDuctTape', 2)]),
    ('grimmerReinforcedToolFrame', 30, [('resourceForgedIron', 8), ('resourceMechanicalParts', 2), ('resourceDuctTape', 2)])
]:
    recipe = ET.SubElement(append, 'recipe', name=item, count='1', craft_time=str(seconds), craft_area='workbench', tags='grimmerWorkshopAttachments', always_unlocked='true')
    for ingredient, count in ingredients:
        ET.SubElement(recipe, 'ingredient', name=ingredient, count=str(count))

for item, skill, cap, credit in bootstrap:
    if skill in skill_names:
        add_rule(item, skill, 1, cap, cap, credit)

# Fuel is a rapid two-unit refining batch, not an equipment assembly.
# Keep it useful for practice without making one shale outperform a chassis.
if ('ammoGasCan', 'craftingVehicles') in rules:
    rules['ammoGasCan', 'craftingVehicles']['credit'] = '0.1'

# Normal cooking also teaches workstation fundamentals up to the workbench.
for item, skill in list(rules):
    if skill == 'craftingFood':
        add_rule(item, 'craftingWorkstations', 1, 10, 10, 12)

# Small preparation awards remain useful at higher levels, with relevance decay.
# These are manufacturing/preparation recipes, not resource packing or refunds.
preparation = [
    ('foodCornMeal', 'craftingFood', 1, 10),
    ('foodEggBoiled', 'craftingFood', 4, 10),
    ('drinkJarPureMineralWater', 'craftingFood', 6, 25),
    ('drinkJarBlackStrapCoffee', 'craftingFood', 8, 40),
    ('foodCanSham', 'craftingFood', 8, 40),
    ('foodBurntSmoothie', 'craftingFood', 8, 40),
    ('foodOasisSmoothie', 'craftingFood', 8, 40),
    ('foodFrostbiteSmoothie', 'craftingFood', 8, 40),
    ('foodAtomicSmoothie', 'craftingFood', 8, 40),
    ('resourceChickenFeed', 'craftingFood', 2, 10),
    ('medicalAloeCream', 'craftingMedical', 2, 10),
    ('medicalSplint', 'craftingMedical', 4, 20),
]
for item, skill, credit, useful_until in preparation:
    if (item, skill) in rules:
        raise ValueError('Preparation route already exists: ' + item)
    add_rule(item, skill, 1, useful_until, 75 if skill == 'craftingMedical' else 100, credit)
    # Actual cooking teaches early station use; backpack milling/feed does not.
    if skill == 'craftingFood' and any(r.get('craft_area') == 'campfire' for r in recipe_by_name[item]):
        add_rule(item, 'craftingWorkstations', 1, 10, 10, 12)

# Water preparation is an accessible, modest early route; it is not equipment assembly.
add_rule('drinkJarBoiledWater', 'craftingWorkstations', 1, 10, 10, 2)

# Normal workbench equipment crafting continues station practice beyond the
# early food cap. Avoid ammunition, fuel and raw-material conversion loops.
for item, item_recipes in recipe_by_name.items():
    if not item.startswith(('meleeWpn', 'meleeTool', 'gun', 'apparel')):
        continue
    if not any(r.get('craft_area') == 'workbench' for r in item_recipes):
        continue
    if (item, 'craftingWorkstations') not in rules and any(i == item for i, _ in rules):
        add_rule(item, 'craftingWorkstations', 1, 20, 75, 2)

# Workshop grips are useful early workbench projects rather than disposable stations.
for item in ('grimmerLightGrip', 'grimmerPowerGrip', 'grimmerLightToolGrip', 'grimmerReinforcedToolFrame'):
    rules[item, 'craftingWorkstations'] = dict(item=item, skill='craftingWorkstations', output='1', unlock='1', until='25', cap='25', credit='4')

# Construction covers base pieces, furnishing and building material processing.
# Explicit families avoid accidental weapon/ammunition and pack/unpack routes.
construction_fixed = {
 'resourceCobblestones': .1, 'resourceCement': .15, 'resourceConcreteMix': .25,
 'resourceCrushedSand': .05, 'resourcePaint': .2,
 'terrGravel': .1, 'terrAsphalt': .25, 'terrStone': .1,
 'frameShapes:VariantHelper': 1, 'woodShapes:VariantHelper': 2,
 'cobblestoneShapes:VariantHelper': 3, 'concreteShapes:VariantHelper': 4,
 'steelShapes:VariantHelper': 5, 'campfire': 3, 'barbedFence': 3,
 'burningBarrelPlayer': 4, 'farmPlotBlockVariantHelper': 4,
 'cntWoodWritableCrate': 4, 'cntIronWritableCrate': 7, 'cntSteelWritableCrate': 10,
 'ironBars': 3, 'ironBarsCentered': 3, 'ironBarsCNR': 3,
 'ladderWood': 2, 'ladderMetal': 4, 'ladderSteel': 6,
 'woodHatch': 3, 'woodLogPillar100': 2,
 'oldWoodDoor': 3, 'oldWoodDoorDouble': 4,
 'vaultDoor01': 10, 'vaultDoor01Double': 12, 'vaultHatch01': 8,
 'metalReinforcedWoodDrawBridge': 12,
 'appliancesVariantHelper': 4, 'wallClockWorking': 3,
 'candle': 1, 'candleTableLightPlayer': 1.5,
 'cntWallSafe_Player': 6, 'cntDeskSafe_Player': 6, 'cntSteelWallCabinetSecure': 6,
 'endTableLamp': 4, 'hayBaleSquare': 1, 'keystoneBlock': 1,
 'decoPumpkinJackOLantern': 2, 'meleeToolPaintTool': 3, 'meleeToolTorch': 1.5,
 'resourceNail': .005,
}
construction_families = ('bed', 'cellarDoor', 'shutters', 'cntCooler', 'cntGunSafe',
 'metalFurniture', 'cntMailBox', 'cntWoodFurniture', 'curtain', 'woodSign',
 'sinksToilets', 'toilets', 'lanternDecorLight', 'lanternOld', 'flagThick',
 'ironGarageDoor', 'rollUpDoor', 'glassBulletproof', 'glassBlock', 'ironDoor',
 'metalTrussing', 'officeChair', 'oldChair', 'ironHatch', 'sandbag',
 'sectional', 'couch', 'plantPotted', 'tvBlock', 'metalFenceRailing',
 'calendarVariant', 'pictureVariant')
construction_names = set(construction_fixed)
construction_names.update(item for item in recipe_by_name if item.startswith(construction_families))
for item in sorted(construction_names):
    if item not in recipe_by_name:
        raise ValueError('Missing construction recipe: ' + item)
    # Powered fixtures retain their engineering route and current requirements.
    credit = construction_fixed.get(item, 6 if any(r.get('craft_area') == 'workbench' for r in recipe_by_name[item]) else 4)
    add_rule(item, 'craftingConstruction', 1, 20, 100, credit)
    if item == 'resourceNail': rules[item, 'craftingConstruction']['output']='1'
    for index, recipe in enumerate(recipe_by_name[item], 1):
        tags = [t for t in recipe.get('tags', '').split(',') if t]
        if 'grimmerConstruction' not in tags: tags.append('grimmerConstruction')
        ET.SubElement(recipe_patch, 'setattribute', xpath="/recipes/recipe[@name='%s'][not(wildcard_forge_category)][%d]" % (item, index), name='tags').text = ','.join(tags)

# Ammunition awards are per actual round/projectile, including bundle contents.
# Normalizing contents before level calculations preserves relevance decay
# across boundaries even when one completed item is a large ammo bundle.
ammo_items = {x.get('name'): x for x in ET.parse(config / 'items.xml').getroot().findall('item')}
def inherited_ammo_property(name, key, action=False, seen=()):
    if name in seen or name not in ammo_items:
        raise ValueError('Invalid ammo inheritance: ' + name)
    item=ammo_items[name]
    path=("property[@class='Action0']/" if action else '')+"property[@name='%s']" % key
    value=item.find(path)
    if value is not None: return value.get('value')
    parent=item.find("property[@name='Extends']")
    return inherited_ammo_property(parent.get('value'),key,action,seen+(name,)) if parent is not None else None

def ammo_training(item):
    if item.startswith(('ammo9mmBullet','ammo44MagnumBullet')):
        rate=.04 if item.endswith('AP') else .03 if item.endswith('HP') else .02
        return [('craftingHandguns',rate,30 if rate>.02 else 20,100)]
    if item.startswith('ammo762mmBullet'):
        rate=.04 if item.endswith('AP') else .03 if item.endswith('HP') else .02
        return [(skill,rate/2,30 if rate>.02 else 20,100) for skill in ('craftingRifles','craftingMachineGuns')]
    if item.startswith('ammoShotgun'):
        return [('craftingShotguns',.04 if 'Slug' in item else .03,30,100)]
    if item.startswith('ammoJunkTurret'):
        return [('craftingRobotics',.02 if item.endswith(('AP','Shell')) else .01,25,100)]
    if item.startswith(('ammoArrow','ammoCrossbowBolt')):
        rate=.2 if item.endswith('Exploding') else .15 if item.endswith('Flaming') else .1 if 'Steel' in item else .075 if 'Iron' in item else .05
        return [('craftingBows',rate,30 if rate>=.1 else 15,75)]
    if item=='ammoDartIron': return [('craftingTraps',.01,20,100)]
    return []

for item in sorted(recipe_by_name):
    bundle=item.startswith('ammoBundle')
    if bundle:
        if inherited_ammo_property(item,'Class',True)!='OpenBundle': raise ValueError('Ammo bundle action changed: '+item)
        output=inherited_ammo_property(item,'Create_item',True)
        units=int(inherited_ammo_property(item,'Create_item_count',True))
        if not 1<=units<=10000: raise ValueError('Invalid bundle size: '+item)
        # Only manufacture from components is eligible. Packing already-made
        # ammunition into another container must never gain this credit.
        if any(i.get('name')==output for r in recipe_by_name[item] for i in r.findall('ingredient')):
            raise ValueError('Reversible ammo packaging requires review: '+item)
    else: output,units=item,1
    for skill,rate,useful_until,cap in ammo_training(output):
        if (item,skill) in rules: raise ValueError('Ammo route already exists: '+item)
        add_rule(item,skill,1,useful_until,cap,rate)
        rules[item,skill]['output']='1'
        if units!=1: rules[item,skill]['units']=str(units)

# Attachment fabrication teaches one relevant skill. Universal fittings teach
# Workstations rather than granting the full award to every compatible weapon.
attachment_modifiers = {m.get('name'): m for m in ET.parse(config / 'item_modifiers.xml').getroot().findall('item_modifier')}
attachment_specialists = {
 'craftingBows': {'modGunBowArrowRest', 'modGunBowPolymerString'},
 'craftingShotguns': {'modGunChoke', 'modGunDuckbill', 'modGunShotgunTubeExtenderMagazine', 'modShotgunSawedOffBarrel'},
 'craftingClubs': {'modMeleeClubBarbedWire', 'modMeleeClubMetalSpikes', 'modMeleeClubMetalChain'},
 'craftingHarvestingTools': {'modFuelTankSmall', 'modFuelTankLarge', 'modMeleeFiremansAxeMod', 'modMeleeGraveDigger', 'modMeleeIronBreaker', 'modMeleeWoodSplitter'},
 'craftingElectrician': {'modArmorHelmetLight', 'modGunFlashlight', 'modGunLaserSight', 'modGunReflexSight'},
 'craftingRobotics': {'modMeleeStunBatonRepulsor'},
}
attachment_caps={s.get('name'):int(s.get('max_level')) for s in skills}
for item,item_recipes in sorted(recipe_by_name.items()):
    if not item.startswith('mod'): continue
    if item not in attachment_modifiers: raise ValueError('Missing attachment definition: '+item)
    if any(int(r.get('count','1'))!=1 for r in item_recipes): raise ValueError('Review attachment output quantity: '+item)
    if any(i==item for i,_ in rules): raise ValueError('Attachment already has practice: '+item)
    matches=[skill for skill,names in attachment_specialists.items() if item in names]
    if len(matches)>1: raise ValueError('Ambiguous attachment skill: '+item)
    if matches: skill=matches[0]
    elif item.startswith('modRoboticDrone'): skill='craftingRobotics'
    elif item.startswith('modVehicle'): skill='craftingVehicles'
    elif item.startswith('modArmor') and 'StoragePocket' in item: skill='craftingBackpack'
    elif item=='modArmorCigar': skill='craftingWorkstations'
    elif item.startswith('modArmor'): skill='craftingArmor'
    elif item.startswith(('modGun','modMelee')): skill='craftingWorkstations'
    else: raise ValueError('Review attachment skill: '+item)
    ingredients={i.get('name'):int(i.get('count')) for r in item_recipes for i in r.findall('ingredient')}
    credit=12 if 'resourceLegendaryParts' in ingredients else 8 if ingredients.get('resourceForgedSteel',0)>=10 or item in {'modArmorAdvancedMuffledConnectors','modArmorStealthBoots'} else 6
    if item in {'modArmorStoragePocket','modArmorPlatingBasic'}: credit=4
    if item=='modArmorCigar': credit=2
    add_rule(item,skill,1,40 if credit>=8 else 25,attachment_caps[skill],credit)

# Remaining practical manufacturing: per actual output item, with small
# material-processing rates. Raw forge refunds, terrain conversions and simple
# resource packing are intentionally not manufacturing practice routes.
manufacturing = [
 ('bucketEmpty','craftingWorkstations',3,25),
 ('combineStation','craftingWorkstations',6,25),
 ('drinkJarEmpty','craftingWorkstations',.1,20),
 ('meleeToolFlashlight02','craftingElectrician',4,25),
 ('meleeToolWireTool','craftingElectrician',6,30),
 ('looseBoardsTrapBlock1x1','craftingTraps',3,25),
 ('looseBoardsTrapBlock3x3','craftingTraps',6,30),
 ('looseBoardsTrapPlate1x1','craftingTraps',2,25),
 ('mineCandyTin','craftingTraps',5,25),
 ('trapGlassBusinessCTRSheet1x1','craftingTraps',2,25),
 ('trapGlassBusinessSheet1x1','craftingTraps',2,25),
 ('trapSpikesIronDmg0','craftingTraps',5,30),
 ('thrownAmmoMolotovCocktail','craftingExplosives',2,25),
 ('plantedGraceCorn1','craftingSeeds',6,20),
 ('resourceArrowHeadIron','craftingWorkstations',.01,20),
 ('resourceArrowHeadSteelAP','craftingWorkstations',.02,25),
 ('resourceBuckshot','craftingWorkstations',.005,20),
 ('resourceBulletCasing','craftingWorkstations',.005,20),
 ('resourceBulletTip','craftingWorkstations',.005,20),
 ('resourceForgedIron','craftingWorkstations',.05,20),
 ('resourceForgedSteel','craftingWorkstations',.1,30),
 ('resourceGlue','craftingWorkstations',.5,25),
 ('resourceMetalPipe','craftingWorkstations',.05,20),
 ('resourcePaper','craftingWorkstations',.02,20),
 ('resourceArmorCraftingKit','craftingArmor',2,25),
 ('resourceScopeLens','craftingWorkstations',.5,25),
 ('toolCookingPot','craftingWorkstations',6,25),
 ('toolCookingGrill','craftingWorkstations',6,25),
 ('vehicleBicyclePlaceable','craftingVehicles',12,25),
 ('vehicleMinibikePlaceable','craftingVehicles',20,35),
 ('vehicleMotorcyclePlaceable','craftingVehicles',30,50),
 ('vehicleTruck4x4Placeable','craftingVehicles',40,65),
 ('vehicleGyrocopterPlaceable','craftingVehicles',50,80),
]
# These are crafted protective biome badges, not medicine. Their challenge
# requirements and effects remain vanilla.
for tier in range(1,5):
    manufacturing.append(('biomeWeatherItem'+str(tier),'craftingArmor',4+2*tier,40))
for item,skill,credit,useful_until in manufacturing:
    if (item,skill) in rules: raise ValueError('Manufacturing route already exists: '+item)
    add_rule(item,skill,1,useful_until,attachment_caps[skill],credit)
    rules[item,skill]['output']='1'

# The lockpick bundle manufactures 50 picks from raw components. Normalize
# before level calculations exactly like ammunition, without an opening award.
lockpick=rules['resourceLockPick','craftingWorkstations']
lockpick_bundle=dict(lockpick,item='resourceLockPickBundle',output='1',units='50')
if inherited_ammo_property('resourceLockPickBundle','Class',True)!='OpenBundle' or inherited_ammo_property('resourceLockPickBundle','Create_item',True)!='resourceLockPick' or inherited_ammo_property('resourceLockPickBundle','Create_item_count',True)!='50':
    raise ValueError('Lockpick bundle contents changed')
if any(i.get('name')=='resourceLockPick' for r in recipe_by_name['resourceLockPickBundle'] for i in r.findall('ingredient')):
    raise ValueError('Reversible lockpick packing needs review')
rules['resourceLockPickBundle','craftingWorkstations']=lockpick_bundle

# Restoration requires a depleted inspection find; ordinary materials alone
# cannot manufacture an unlimited supply of engines.
engine_recipe = ET.SubElement(append, 'recipe', name='smallEngine', count='1',
    craft_time='120', craft_area='workbench', tags='grimmerVehicleRestoration,workbenchCrafting', always_unlocked='true')
for material, count in [('grimmerRecoveredEngine', 1), ('resourceForgedIron', 10),
                        ('resourceMechanicalParts', 12), ('resourceOil', 4), ('resourceDuctTape', 2)]:
    ET.SubElement(engine_recipe, 'ingredient', name=material, count=str(count))
recipe_by_name['smallEngine'].append(engine_recipe)
add_rule('smallEngine', 'craftingVehicles', 1, 40, 100, 12)

bench_recipe = ET.SubElement(append, 'recipe', name='grimmerGunsmithBench', count='1',
    craft_time='90', craft_area='workbench', tags='learnable,workbenchCrafting')
for material, count in [('workbench', 1), ('resourceForgedIron', 10),
                        ('resourceMechanicalParts', 10), ('resourceDuctTape', 4)]:
    ET.SubElement(bench_recipe, 'ingredient', name=material, count=str(count))
recipe_by_name['grimmerGunsmithBench'].append(bench_recipe)
add_rule('grimmerGunsmithBench', 'craftingWorkstations', 20, 40, 75, 12)

for key in sorted(rules):
    rule = rules[key]
    ET.SubElement(rule_root, 'rule', **rule)
    coverage[rule['skill']].append(rule)

def write_xml(path, root):
    path.parent.mkdir(parents=True, exist_ok=True)
    ET.indent(root, space='  ')
    ET.ElementTree(root).write(path, encoding='utf-8', xml_declaration=True)

write_xml(destination / 'PracticeRules.xml', rule_root)
write_xml(destination / 'Config' / 'recipes.xml', recipe_patch)

# Keep magazines as loot and merchant goods. Their skill gain is suppressed in
# the explicit skill-magazine items, including their duplicate-point proc.
items = ET.parse(config / 'items.xml').getroot()
item_patch = ET.Element('configs')
magazines = []
for item in items.findall('item'):
    unlock = item.find("property[@name='Unlocks']")
    if not item.get('name', '').endswith('SkillMagazine') or unlock is None or unlock.get('value') not in skill_names:
        continue
    magazines.append(item.get('name'))
    ET.SubElement(item_patch, 'remove', xpath="/items/item[@name='%s']//triggered_effect[@action='AddProgressionLevel']" % item.get('name'))
write_xml(destination / 'Config' / 'items.xml', item_patch)

missing = skill_names - coverage.keys()
if missing:
    raise ValueError(f'Skills without any practice route: {missing}')
unstarted = [s for s in skill_names if not any(int(r['unlock']) == 1 for r in coverage[s])]
if unstarted:
    raise ValueError(f'Skills without a level-one practice route: {unstarted}')

# Check every transition, not just the existence of a level-one recipe. A route
# must be hand-unlocked or explicitly unlocked by the relevant crafting skill.
audit = ['# Crafting progression audit', '',
         'Generated from installed V3.4 b10 data. All crafting-level transitions have a magazine-free recipe route. Ingredients, loot luck and workstation construction still need real play balancing.', '',
         '| Crafting skill | Maximum | Starting recipe | Starting station | Levels checked |',
         '| --- | --- | --- | --- | --- |']
checked = 0
for skill in sorted(skills, key=lambda s: s.get('name')):
    name, maximum = skill.get('name'), int(skill.get('max_level'))
    explicit = {tag: int(effect.get('level').split(',')[0])
                for effect in skill.findall(".//passive_effect[@name='RecipeTagUnlocked']")
                for tag in effect.get('tags', '').split(',')}
    available = []
    for level in range(1, maximum):
        available = [r for r in coverage[name]
                     if int(r['unlock']) <= level < int(r['cap'])
                     and (explicit.get(r['item'], maximum + 1) <= level
                          or any(x.get('always_unlocked') == 'true' or 'learnable' not in x.get('tags', '').split(',')
                                 for x in recipe_by_name[r['item']]))]
        if not available:
            raise ValueError(f'No magazine-free recipe route for {name} at level {level}')
        if level == 1:
            start = min(available, key=lambda r: (int(r['cap']), r['item']))
            stations = sorted({x.get('craft_area', 'backpack') for x in recipe_by_name[start['item']]})
        checked += 1
    audit.append(f"| {name[8:]} | {maximum} | {start['item']} | {', '.join(stations)} | 1–{maximum - 1} |")
audit += ['', f'Checked {checked} level transitions across {len(skills)} crafting skills. No progression-gap failures.', '',
          'Early workstation path: campfires to Workstations 4 unlock the forge; food preparation trains Workstations to 10 for the workbench; boiled water gives modest practice, and workbench equipment crafting continues beyond 10. Mechanical parts assembly requires forged iron from that forge. Electrical parts assembly requires scrap iron and polymers. Both assembly recipes are always unlocked.']
(Path(__file__).parent / 'PROGRESSION-AUDIT.md').write_text('\n'.join(audit) + '\n', encoding='utf-8')

with (destination / 'CRAFTING-ROUTES.csv').open('w', newline='', encoding='utf-8') as file:
    writer = csv.writer(file)
    writer.writerow(['Skill', 'Item', 'Unlock level', 'Full credit through level', 'Training cap', 'Base practice per output group', 'Output group size', 'Units per crafted item'])
    for skill in sorted(coverage):
        for rule in coverage[skill]:
            writer.writerow([skill, rule['item'], rule['unlock'], rule['until'], rule['cap'], rule['credit'], rule['output'], rule.get('units', '1')])
print(f'Generated {len(rules)} practice routes across {len(coverage)} crafting skills and {len(magazines)} magazine patches.')
