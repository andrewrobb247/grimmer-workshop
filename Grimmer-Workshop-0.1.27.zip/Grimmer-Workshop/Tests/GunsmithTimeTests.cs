using System;
using GrimmerWorkshop;
namespace HarmonyLib { public class HarmonyPatch:Attribute { public HarmonyPatch(Type type,string name){} } }
public class XUiM_Recipes {}
public class Recipe { public string craftingArea; }
namespace GrimmerWorkshop { public static class Workshop { public static object player=new object(); public static object Player(){return player;} } }
class GunsmithTimeTests {
    static int checks;
    static void Check(bool pass,string name){checks++;if(!pass)throw new Exception(name);}
    static void Main(){
        foreach(float original in new[]{0f,.1f,2.4f,60f,1000f}){
            float result=original;GunsmithTime.Postfix(new Recipe{craftingArea="grimmerGunsmithBench"},ref result);
            Check(Math.Abs(result-original*.85f)<.0001f,"Specialist bonus on native computed time");
        }
        foreach(string area in new[]{"workbench","chemistryStation","player",null}){
            float result=60;GunsmithTime.Postfix(new Recipe{craftingArea=area},ref result);Check(result==60,"Other stations unaffected");
        }
        float untouched=60;GunsmithTime.Postfix(null,ref untouched);Check(untouched==60,"Null recipe safe");
        Workshop.player=null;GunsmithTime.Postfix(new Recipe{craftingArea="grimmerGunsmithBench"},ref untouched);Check(untouched==60,"Solo guard retained");
        Console.WriteLine("PASS: "+checks+" gunsmith time checks.");
    }
}
