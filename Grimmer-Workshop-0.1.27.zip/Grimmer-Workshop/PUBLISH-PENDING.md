# Publication status

Latest published: 0.1.23 testing. Candidate 0.1.27 is built locally, not published. It includes 0.1.24 inspection, 0.1.25 empty owned crate pickup, 0.1.26 engine restoration and the new Gunsmith Bench.

Current staging: ../Workshop-Publish-0127. Build and verify all payloads/source ZIP before publication. Upload all payloads and archive first, verify hosted bytes/hashes, then channels/testing.json LAST. Recheck the unchanged 0.1.10 updater against the hosted manifest. Older staged candidates remain available.

GitHub owner link: link_6aff085f7d5c8191a878a53f72ed0f73. Last actual upload attempt after the user's permission change returned HTTP 403 Resource not accessible by integration. Repository account metadata reports push:true, but connector uploads have failed. No channel writes succeeded. No new permission change in the gunsmith task, so no repeated upload attempt. Desktop/browser controls unavailable; Windows denied credential enumeration. Do not request tokens or passwords in chat.

0.1.27 Gunsmith Bench: Workstations 20; native model/UI; 118 source-preserving weapon/ammo/attachment recipe variants; 15% shorter native computed craft times. One new station rule, total 634. All 633 old rules and original recipes retained. Companion identity survives previous-launcher regeneration.

Validation: production build; 2,627 regressions, 10 storage button, 14 workstation credit, 620 inspection state/reward, 13 vehicle interaction, 23 pickup and 11 gunsmith timing checks. 118 recipe comparisons plus station/unlock/localization checks; four installed-game gunsmith IL/UI checks; rollback identity check. Live checks remain in PLAYTEST-CHECKLIST.md. No new gun models integrated; Nexus shortlist and permissions in Source/NEXUS-CONTENT-IDEAS.md.