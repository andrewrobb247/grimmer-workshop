# Publication status

0.1.29 optional full Arsenal practice prepared. Base route count remains 635; separately installed DSD Arsenal 1.2.1 adds 54 runtime routes for all 53 weapons and Energy Cells. No external pack files included in public payloads/source archive. Build, prior regressions and 128 metadata adapter checks pass. Static DLL check resolves 49 native API member references. Live checks remain in PLAYTEST-CHECKLIST.md.

Stage ../Workshop-Publish-0129. Upload all own payloads/archive, verify hosted bytes, then testing channel last. Verify original updater afterwards. Local author-pack installation must preserve original bytes and existing worlds/settings.
