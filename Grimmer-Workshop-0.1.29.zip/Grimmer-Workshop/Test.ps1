param([string]$ArsenalDirectory)
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$testDirectory = Join-Path $PSScriptRoot '..\work\workshop-tests'
New-Item -ItemType Directory -Path $testDirectory -Force | Out-Null
$testExecutable = Join-Path $testDirectory 'RegressionTests.exe'
& $compiler /nologo /target:exe ("/out:" + $testExecutable) (Join-Path $PSScriptRoot 'Source\Storage.cs') (Join-Path $PSScriptRoot 'Source\PracticeMath.cs') (Join-Path $PSScriptRoot 'Source\ActivityBudget.cs') (Join-Path $PSScriptRoot 'Source\SkillScreenText.cs') (Join-Path $PSScriptRoot 'Source\SkillScreen.cs') (Join-Path $PSScriptRoot 'Source\CraftingUi.cs') (Join-Path $PSScriptRoot 'Source\RecipeTraining.cs') (Join-Path $PSScriptRoot 'Tests\FakeGame.cs') (Join-Path $PSScriptRoot 'Tests\RegressionTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Regression test compilation failed.' }
& $testExecutable
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed.' }
$buttonTests = Join-Path $testDirectory 'StorageButtonTests.exe'
& $compiler /nologo /target:exe ("/out:" + $buttonTests) (Join-Path $PSScriptRoot 'Source\StorageButtons.cs') (Join-Path $PSScriptRoot 'Tests\StorageButtonTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Storage button test compilation failed.' }
& $buttonTests
if ($LASTEXITCODE -ne 0) { throw 'Storage button tests failed.' }




$creditTests = Join-Path $testDirectory 'WorkstationCreditTests.exe'
& $compiler /nologo /target:exe ("/out:" + $creditTests) (Join-Path $PSScriptRoot 'Source\WorkstationCredit.cs') (Join-Path $PSScriptRoot 'Tests\WorkstationCreditTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Workstation credit test compilation failed.' }
& $creditTests
if ($LASTEXITCODE -ne 0) { throw 'Workstation credit tests failed.' }
$vehicleTests = Join-Path $testDirectory 'VehicleInspectionTests.exe'
& $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:" + $vehicleTests) (Join-Path $PSScriptRoot 'Source\VehicleInspectionState.cs') (Join-Path $PSScriptRoot 'Tests\VehicleInspectionTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Vehicle inspection test compilation failed.' }
& $vehicleTests $testDirectory
if ($LASTEXITCODE -ne 0) { throw 'Vehicle inspection tests failed.' }
$vehicleIntegration = Join-Path $testDirectory 'VehicleInspectionIntegrationTests.exe'
& $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:" + $vehicleIntegration) (Join-Path $PSScriptRoot 'Source\VehicleInspectionState.cs') (Join-Path $PSScriptRoot 'Source\VehicleInspection.cs') (Join-Path $PSScriptRoot 'Tests\VehicleInspectionIntegrationTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Vehicle interaction test compilation failed.' }
& $vehicleIntegration $testDirectory
if ($LASTEXITCODE -ne 0) { throw 'Vehicle interaction tests failed.' }
$pickupTests = Join-Path $testDirectory 'StoragePickupTests.exe'
& $compiler /nologo /target:exe /main:StoragePickupTests /reference:System.Xml.Linq.dll ("/out:" + $pickupTests) (Join-Path $PSScriptRoot 'Source\VehicleInspectionState.cs') (Join-Path $PSScriptRoot 'Source\VehicleInspection.cs') (Join-Path $PSScriptRoot 'Source\StoragePickup.cs') (Join-Path $PSScriptRoot 'Tests\VehicleInspectionIntegrationTests.cs') (Join-Path $PSScriptRoot 'Tests\StoragePickupTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Storage pickup test compilation failed.' }
& $pickupTests
if ($LASTEXITCODE -ne 0) { throw 'Storage pickup tests failed.' }
$gunsmithTests = Join-Path $testDirectory 'GunsmithTimeTests.exe'
& $compiler /nologo /target:exe ("/out:" + $gunsmithTests) (Join-Path $PSScriptRoot 'Source\Gunsmith.cs') (Join-Path $PSScriptRoot 'Tests\GunsmithTimeTests.cs')
if ($LASTEXITCODE -ne 0) { throw 'Gunsmith timing test compilation failed.' }
& $gunsmithTests
if ($LASTEXITCODE -ne 0) { throw 'Gunsmith timing tests failed.' }
if ($ArsenalDirectory) {
    $arsenalTests = Join-Path $testDirectory 'ArsenalRulesTests.exe'
    & $compiler /nologo /target:exe /reference:System.Xml.Linq.dll ("/out:" + $arsenalTests) (Join-Path $PSScriptRoot 'Source\ArsenalRules.cs') (Join-Path $PSScriptRoot 'Tests\ArsenalRulesTests.cs')
    if ($LASTEXITCODE -ne 0) { throw 'Arsenal test compilation failed.' }
    & $arsenalTests $ArsenalDirectory
    if ($LASTEXITCODE -ne 0) { throw 'Arsenal practice tests failed.' }
}
